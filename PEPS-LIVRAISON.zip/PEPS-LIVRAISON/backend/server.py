from dotenv import load_dotenv
from pathlib import Path

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

import os
import io
import re
import csv
import json
import hmac
import hashlib
import uuid
import logging
import secrets
import asyncio
from datetime import datetime, timezone, timedelta
from typing import List, Optional, Literal, Any

import xml.etree.ElementTree as ET

import bcrypt
import jwt
import httpx
import resend
from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Depends, Query, UploadFile, File, Body
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo.errors import DuplicateKeyError
from pydantic import BaseModel, Field, EmailStr, ConfigDict, field_validator
from reportlab.lib.pagesizes import LETTER
from reportlab.lib import colors as rl_colors
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas as rl_canvas


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
MONGO_URL = os.environ["MONGO_URL"]
DB_NAME = os.environ["DB_NAME"]
JWT_SECRET = os.environ["JWT_SECRET"]
JWT_ALGORITHM = "HS256"
ACCESS_TOKEN_MINUTES = 60 * 24 * 7  # 7 days for ecommerce UX
ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL", "admin@fironova.com")
# Aucun défaut : un mot de passe admin en dur dans le repo est un mot de passe public.
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD")
if not ADMIN_PASSWORD:
    raise RuntimeError(
        "ADMIN_PASSWORD est obligatoire. Définissez-le dans l'environnement "
        "avant de démarrer le serveur."
    )
INTERAC_EMAIL = os.environ.get("INTERAC_EMAIL", "orders@fironova.com")

# Code d'accès facultatif demandé AVANT même l'écran de login admin, côté SPA
# publique. Ne remplace pas l'auth (JWT + rôle restent la vraie barrière sur
# /api/admin/*) — sert seulement à ce qu'un visiteur qui tombe sur l'URL admin
# obscure par hasard ne voie même pas d'écran de login. Si non défini, la
# passerelle est désactivée (aucun blocage).
ADMIN_GATE_CODE = os.environ.get("ADMIN_GATE_CODE")
INTERAC_PASSWORD_HINT = os.environ.get("INTERAC_PASSWORD_HINT", "FIRONOVA")
NOWPAYMENTS_API_KEY = os.environ.get("NOWPAYMENTS_API_KEY", "")
NOWPAYMENTS_IPN_SECRET = os.environ.get("NOWPAYMENTS_IPN_SECRET", "")
PUBLIC_BASE_URL = os.environ.get("PUBLIC_BASE_URL", "").rstrip("/")
NOWPAYMENTS_BASE_URL = "https://api.nowpayments.io/v1"
RESEND_API_KEY = os.environ.get("RESEND_API_KEY", "")
SENDER_EMAIL = os.environ.get("SENDER_EMAIL", "orders@fironova.com")
MAGIC_SENDER_EMAIL = os.environ.get("MAGIC_SENDER_EMAIL", "")
ADMIN_NOTIFICATION_EMAIL = os.environ.get("ADMIN_NOTIFICATION_EMAIL", "admin@fironova.com")
STRIPE_API_KEY = os.environ.get("STRIPE_API_KEY", "")
SHIPPING_FLAT_CAD = float(os.environ.get("SHIPPING_FLAT_CAD", "20.00"))
FREE_SHIPPING_THRESHOLD_CAD = float(os.environ.get("FREE_SHIPPING_THRESHOLD_CAD", "200.00"))
UNPAID_ORDER_TTL_HOURS = float(os.environ.get("UNPAID_ORDER_TTL_HOURS", "24"))
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "true").strip().lower() == "true"
COOKIE_SAMESITE = os.environ.get("COOKIE_SAMESITE", "none").strip().lower()
if COOKIE_SAMESITE not in {"lax", "strict", "none"}:
    COOKIE_SAMESITE = "none"
# Browsers reject SameSite=None when Secure=false. Fallback keeps local HTTP usable.
if not COOKIE_SECURE and COOKIE_SAMESITE == "none":
    COOKIE_SAMESITE = "lax"

# Feature flags — toggle without deploying new code, just flip the env var and restart.
COA_PAGE_ENABLED = os.environ.get("COA_PAGE_ENABLED", "false").strip().lower() == "true"

# --- Prélancement (BLOC 3) --------------------------------------------------
# Défaut sûr : la boutique reste OUVERTE si la variable est absente.
PRELAUNCH_ENABLED = os.environ.get("PRELAUNCH_ENABLED", "false").strip().lower() == "true"
PRELAUNCH_PREVIEW_TOKEN = os.environ.get("PRELAUNCH_PREVIEW_TOKEN", "")  # ?preview=<token> contourne la porte
LAUNCH_COUPON_CODE = os.environ.get("LAUNCH_COUPON_CODE", "LAUNCH15").strip().upper()

# File uploads (COA PDFs). Served statically at /uploads/coa/<file>.
UPLOAD_DIR = ROOT_DIR / "uploads"
COA_UPLOAD_DIR = UPLOAD_DIR / "coa"
COA_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
MAX_COA_UPLOAD_MB = float(os.environ.get("MAX_COA_UPLOAD_MB", "10"))

# Product images. Served statically at /uploads/images/<file>.
IMAGE_UPLOAD_DIR = UPLOAD_DIR / "images"
IMAGE_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
MAX_IMAGE_UPLOAD_MB = float(os.environ.get("MAX_IMAGE_UPLOAD_MB", "5"))
ALLOWED_IMAGE_TYPES = {"image/png", "image/jpeg", "image/webp", "image/gif"}

# Étiquettes d'expédition Postes Canada — servies à /uploads/labels/<file>.
LABEL_UPLOAD_DIR = UPLOAD_DIR / "labels"
LABEL_UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Postes Canada (Canada Post) rating/tracking API — leave blank to keep using the flat-rate
# shipping_zones/shipping_methods system already in place.
CANADA_POST_API_KEY = os.environ.get("CANADA_POST_API_KEY", "")
CANADA_POST_CUSTOMER_NUMBER = os.environ.get("CANADA_POST_CUSTOMER_NUMBER", "")
CANADA_POST_CONTRACT_ID = os.environ.get("CANADA_POST_CONTRACT_ID", "")
CANADA_POST_ORIGIN_POSTAL_CODE = os.environ.get("CANADA_POST_ORIGIN_POSTAL_CODE", "")
# Expéditeur pour la création d'étiquettes. Emballage neutre : aucune mention
# du contenu ne figure sur l'étiquette (politique d'emballage discret).
CANADA_POST_SENDER_NAME = os.environ.get("CANADA_POST_SENDER_NAME", "FIRONOVA")
CANADA_POST_SENDER_ADDRESS = os.environ.get("CANADA_POST_SENDER_ADDRESS", "")
CANADA_POST_SENDER_CITY = os.environ.get("CANADA_POST_SENDER_CITY", "Montreal")
CANADA_POST_SENDER_PROVINCE = os.environ.get("CANADA_POST_SENDER_PROVINCE", "QC")
CANADA_POST_SENDER_PHONE = os.environ.get("CANADA_POST_SENDER_PHONE", "")
CANADA_POST_ENVIRONMENT = os.environ.get("CANADA_POST_ENVIRONMENT", "dev")  # "dev" (soa-gw) or "prod" (soa-gw prod host)
CANADA_POST_BASE_URL = (
    "https://ct.soa-gw.canadapost.ca" if CANADA_POST_ENVIRONMENT == "dev"
    else "https://soa-gw.canadapost.ca"
)
# New Shipping OpenAPI (OAuth2) support. Modes:
# - legacy: existing XML/basic-auth flow
# - openapi: OAuth2 + JSON flow from the shipping v1 OpenAPI spec
# - auto: openapi if OAuth creds are present, otherwise legacy
CANADA_POST_API_MODE = os.environ.get("CANADA_POST_API_MODE", "auto").strip().lower()
CANADA_POST_OPENAPI_BASE_URL = os.environ.get(
    "CANADA_POST_OPENAPI_BASE_URL",
    "https://api.canadapost-postescanada.ca/prod/devportal-portaildesdeveloppeurs/shipping/v1",
).rstrip("/")
CANADA_POST_OAUTH_TOKEN_URL = os.environ.get(
    "CANADA_POST_OAUTH_TOKEN_URL",
    "https://api.canadapost-postescanada.ca/prod/devportal-portaildesdeveloppeurs/cpc-api-native-oauth-provider/oauth2/token",
).strip()
CANADA_POST_OAUTH_CLIENT_ID = os.environ.get("CANADA_POST_OAUTH_CLIENT_ID", "").strip()
CANADA_POST_OAUTH_CLIENT_SECRET = os.environ.get("CANADA_POST_OAUTH_CLIENT_SECRET", "").strip()
CANADA_POST_PLATFORM_ID = os.environ.get("CANADA_POST_PLATFORM_ID", "").strip()
CANADA_POST_MAILED_BY = os.environ.get("CANADA_POST_MAILED_BY", CANADA_POST_CUSTOMER_NUMBER).strip()
CANADA_POST_MOBO = os.environ.get("CANADA_POST_MOBO", CANADA_POST_CUSTOMER_NUMBER).strip()
CANADA_POST_INTENDED_METHOD = os.environ.get("CANADA_POST_INTENDED_METHOD", "").strip()
CANADA_POST_DEFAULT_SERVICE_CODE = os.environ.get("CANADA_POST_DEFAULT_SERVICE_CODE", "DOM.EP").strip() or "DOM.EP"
CANADA_POST_AUTO_LABEL_INTERVAL_SECONDS = int(os.environ.get("CANADA_POST_AUTO_LABEL_INTERVAL_SECONDS", "60"))
CANADA_POST_AUTO_DELIVERY_SYNC_SECONDS = int(os.environ.get("CANADA_POST_AUTO_DELIVERY_SYNC_SECONDS", "900"))
CANADA_POST_SANDBOX_DELIVERY_FALLBACK = os.environ.get("CANADA_POST_SANDBOX_DELIVERY_FALLBACK", "false").strip().lower() == "true"
CANADA_POST_SANDBOX_DELIVER_AFTER_HOURS = int(os.environ.get("CANADA_POST_SANDBOX_DELIVER_AFTER_HOURS", "24"))

# ---------------------------------------------------------------------------
# Dispatch batch (fenêtre de traitement des commandes)
# Cutoff 13h heure de l'Est, jours ouvrables seulement (week-ends + fériés exclus).
# ---------------------------------------------------------------------------
from zoneinfo import ZoneInfo
try:
    import holidays as _holidays_lib
    _CA_HOLIDAYS = _holidays_lib.Canada()  # fériés fédéraux canadiens
except Exception:  # pragma: no cover - lib absente => aucun férié bloqué
    _CA_HOLIDAYS = set()

ORDER_CUTOFF_HOUR = int(os.environ.get("ORDER_CUTOFF_HOUR", "13"))
ORDER_CUTOFF_TZ = os.environ.get("ORDER_CUTOFF_TZ", "America/Toronto")


def _is_business_day(d) -> bool:
    """False les samedis, dimanches et jours fériés fédéraux canadiens."""
    if d.weekday() >= 5:  # 5 = samedi, 6 = dimanche
        return False
    return d not in _CA_HOLIDAYS


def compute_dispatch_batch(paid_at) -> str:
    """
    Retourne la date du lot d'expédition (prochain jour ouvrable) au format
    'YYYY-MM-DD' en date locale (ORDER_CUTOFF_TZ), à partir d'un horodatage de
    paiement (datetime aware UTC, ou string ISO).
    Règle : payé avant le cutoff un jour ouvrable => jour même, sinon jour
    suivant ; puis on avance jusqu'au prochain jour ouvrable.
    """
    if isinstance(paid_at, str):
        paid_at = datetime.fromisoformat(paid_at.replace("Z", "+00:00"))
    if paid_at.tzinfo is None:
        paid_at = paid_at.replace(tzinfo=timezone.utc)
    local = paid_at.astimezone(ZoneInfo(ORDER_CUTOFF_TZ))
    candidate = local.date()
    if not (local.hour < ORDER_CUTOFF_HOUR and _is_business_day(candidate)):
        candidate = candidate + timedelta(days=1)
    while not _is_business_day(candidate):
        candidate = candidate + timedelta(days=1)
    return candidate.isoformat()

try:
    from emergentintegrations.payments.stripe.checkout import StripeCheckout, CheckoutSessionRequest
    _STRIPE_AVAILABLE = True
except Exception:
    _STRIPE_AVAILABLE = False
    StripeCheckout = None
    CheckoutSessionRequest = None

if RESEND_API_KEY:
    resend.api_key = RESEND_API_KEY

client = AsyncIOMotorClient(MONGO_URL)
db = client[DB_NAME]

app = FastAPI(title="FIRONOVA API", version="1.0.0")
api = APIRouter(prefix="/api")

# Serve uploaded files (COA PDFs, images, etc.) at /uploads/...
app.mount("/uploads", StaticFiles(directory=str(UPLOAD_DIR)), name="uploads")
# Also serve under /api/uploads so assets pass the platform ingress (only /api is
# routed to the backend on Emergent). Product/COA URLs use the /api/uploads form.
app.mount("/api/uploads", StaticFiles(directory=str(UPLOAD_DIR)), name="uploads-api")


# ---------------------------------------------------------------------------
# Helpers: password & JWT
# ---------------------------------------------------------------------------
def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except Exception:
        return False


def create_access_token(user_id: str, email: str, role: str, token_version: int = 0) -> str:
    payload = {
        "sub": user_id,
        "email": email,
        "role": role,
        "tv": token_version,  # doit correspondre à users.token_version — sinon token révoqué
        "exp": datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_MINUTES),
        "type": "access",
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def _cookie_secure_for_request(request: Optional[Request]) -> bool:
    """Keep secure cookies in production, but allow local HTTP development.

    Browsers reject `Secure` cookies on plain HTTP, which breaks local auth
    flows (admin upload endpoints rely on that auth cookie).
    """
    if not COOKIE_SECURE:
        return False
    if request is None:
        return COOKIE_SECURE
    host = (request.headers.get("host") or "").split(":", 1)[0].strip().lower()
    proto = (request.headers.get("x-forwarded-proto") or request.url.scheme or "").lower()
    if proto != "https" and host in {"localhost", "127.0.0.1"}:
        return False
    return COOKIE_SECURE


def set_auth_cookie(response: Response, token: str, request: Optional[Request] = None) -> None:
    secure_flag = _cookie_secure_for_request(request)
    samesite_flag = COOKIE_SAMESITE
    if not secure_flag and samesite_flag == "none":
        samesite_flag = "lax"
    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        secure=secure_flag,
        samesite=samesite_flag,
        max_age=ACCESS_TOKEN_MINUTES * 60,
        path="/",
    )


def clear_auth_cookie(response: Response) -> None:
    response.delete_cookie(key="access_token", path="/")


async def _resolve_user(request: Request) -> Optional[dict]:
    token = request.cookies.get("access_token")
    if not token:
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth[7:]
    if not token:
        return None
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        if payload.get("type") != "access":
            return None
        user = await db.users.find_one({"id": payload["sub"]}, {"_id": 0, "password_hash": 0})
        if not user:
            return None
        # Révocation : si le token_version du JWT ne correspond plus à celui
        # stocké sur l'utilisateur (changement de mot de passe, changement
        # d'email confirmé, déconnexion globale, suppression de compte),
        # le token est considéré invalide même s'il n'a pas expiré.
        if payload.get("tv", 0) != user.get("token_version", 0):
            return None
        user.pop("token_version", None)  # détail interne, pas exposé à l'API
        return user
    except jwt.PyJWTError:
        return None


async def get_current_user(request: Request) -> dict:
    user = await _resolve_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user


async def get_admin_user(request: Request) -> dict:
    user = await get_current_user(request)
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin only")
    return user


# ---------------------------------------------------------------------------
# Rôles & permissions granulaires — inspiré du modèle de règles par entité
# vu sur Base44 (Créateur uniquement / Tous les utilisateurs / etc.), adapté
# à un admin e-commerce : trois rôles (user, staff, admin), et pour les
# comptes "staff", un niveau d'accès par zone fonctionnelle.
#   - "admin"  : accès complet à tout, y compris la gestion des autres
#                membres staff (équivalent "Owner" chez Base44).
#   - "staff"  : accès limité aux zones et niveaux qui lui sont accordés.
#   - "user"   : client normal, aucun accès admin.
# Niveaux par zone : none < view < manage (manage inclut view).
# ---------------------------------------------------------------------------
STAFF_AREAS = ["orders", "products", "coupons", "customers", "subscribers", "shipping", "dashboard"]
_PERMISSION_ORDER = {"none": 0, "view": 1, "manage": 2}


def require_area(area: str, level: str = "view"):
    """Dépendance FastAPI paramétrée : autorise si role == admin (accès total),
    ou si role == staff ET permissions[area] >= level demandé.
    Journalise automatiquement toute action de niveau "manage" (= mutation) —
    couvre les 35 endpoints admin existants sans qu'il faille les modifier
    un par un."""
    async def _dep(request: Request, user: dict = Depends(get_current_user)) -> dict:
        allowed = False
        if user.get("role") == "admin":
            allowed = True
        elif user.get("role") == "staff":
            perms = user.get("permissions") or {}
            have = _PERMISSION_ORDER.get(perms.get(area, "none"), 0)
            need = _PERMISSION_ORDER.get(level, 1)
            allowed = have >= need
        if not allowed:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        if level == "manage":
            asyncio.create_task(_log_action(
                user, action=f"{request.method} {request.url.path}", area=area,
            ))
        return user
    return _dep


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    name: str = Field(min_length=1)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str
    email: str
    name: str
    role: str
    created_at: str


class ProductVariant(BaseModel):
    id: Optional[str] = None  # generated server-side if missing
    name: str  # "5mg", "10mg", "500mcg"
    price: float
    stock: int = 0
    sku: str = ""
    # COA status — single source of truth per variant (replaces the two legacy
    # booleans badge_coa_available / badge_coa_pending which could contradict).
    #   "available" : a COA exists for this lot (coa_url should be set).
    #   "pending"   : COA not ready yet but coming — shown for transparency.
    #                 The variant stays purchasable, with a visible warning.
    #   "none"      : nothing shown.
    coa_status: str = "none"  # "available" | "pending" | "none"
    # Legacy booleans kept for backward-compat / rollback; no longer read for display.
    badge_coa_available: bool = False
    badge_coa_pending: bool = False
    badge_coming_soon: bool = False
    coa_url: str = ""
    sale_price: Optional[float] = None  # special/discount price (must be < price to apply)
    preorder_enabled: bool = False
    preorder_delay_message: str = ""
    preorder_price: Optional[float] = None
    preorder_note: str = ""
    weight_grams: float = 50.0  # used to estimate parcel weight for live Canada Post rating


class ProductIn(BaseModel):
    slug: str
    name_en: str
    name_fr: str
    category: str  # healing | gh-secretagogues | weight-loss | cognitive | longevity
    sequence: Optional[str] = ""
    purity: str = "≥ 99%"
    dosage_mg: float = 0.0  # informational only — variants drive actual pricing/stock
    description_en: str
    description_fr: str
    price_cad: float = 0.0  # legacy/fallback (= price of first variant)
    stock: int = 0  # legacy/fallback (= total across variants)
    low_stock_threshold: int = 10
    image_url: str = ""
    lab_tested: bool = True
    active: bool = True
    featured: bool = False
    preorder_allowed: bool = False  # legacy product-level (variants override)
    coa_url: Optional[str] = ""
    coa_lot: Optional[str] = ""
    coa_date: Optional[str] = ""
    # --- SCIENTIFIC DATA (10 new fields) ---
    molecular_formula: str = ""        # ex. "C62H98N16O22"
    molecular_weight: Optional[float] = None   # ex. 1419.5 (Da)
    cas_number: str = ""               # ex. "137525-51-0"
    sequence_length: Optional[int] = None # ex. 31 (derivable from sequence but explicit here)
    storage: str = ""                  # ex. "-20°C, à l'abri de la lumière"
    solubility: str = ""               # ex. "Soluble dans l'eau, acide acétique 0,1%"
    appearance: str = ""               # ex. "Poudre lyophilisée blanche"
    mechanism: str = ""                # ex. "Potentialise la libération d'hormone de croissance"
    research_areas: List[str] = []     # ex. ["Réparation tissulaire", "Anti-inflammatoire"]
    synonyms: List[str] = []           # ex. ["Sermorelin", "GRF 1-29"]
    meta_title_en: str = ""
    meta_title_fr: str = ""
    meta_description_en: str = ""
    meta_description_fr: str = ""
    og_image_url: str = ""
    variants: List[ProductVariant] = []


class ProductOut(ProductIn):
    id: str
    created_at: str


class CartItem(BaseModel):
    product_id: str
    variant_id: Optional[str] = None
    qty: int = Field(ge=1)


class ShippingAddress(BaseModel):
    full_name: str
    address1: str
    address2: Optional[str] = ""
    city: str
    province: str  # QC, ON, BC, AB, ...
    postal_code: str
    country: str = "CA"
    phone: Optional[str] = ""


class CheckoutIn(BaseModel):
    items: List[CartItem]
    shipping: ShippingAddress
    email: Optional[EmailStr] = None  # guest email; auth user's email is used if logged in
    payment_method: Literal["interac", "nowpayments"]  # stripe désactivé
    pay_currency: Optional[str] = "btc"  # used only for nowpayments
    coupon_code: Optional[str] = None
    origin_url: Optional[str] = None  # used by stripe to build success/cancel URLs
    accept_terms: bool
    confirm_age: bool
    confirm_research_use: bool


class CouponIn(BaseModel):
    code: str
    discount_type: Literal["percent", "fixed"]
    value: float = Field(gt=0)  # percent 1-100 or absolute CAD
    min_subtotal: float = 0.0
    usage_limit: Optional[int] = None  # None = unlimited
    active: bool = True
    expires_at: Optional[str] = None  # ISO string


class OrderNoteIn(BaseModel):
    text: str = Field(min_length=1)
    visible_to_customer: bool = False


class RefundIn(BaseModel):
    amount: float = Field(gt=0)


class ShippingInfoIn(BaseModel):
    carrier: Optional[str] = ""
    tracking_number: Optional[str] = ""
    shipped_at: Optional[str] = None  # ISO; defaults to now() if not provided


class CreateLabelIn(BaseModel):
    service_code: str = Field(min_length=1, max_length=40)  # ex. "DOM.EP"


class StockAdjustIn(BaseModel):
    delta: int  # positive to add, negative to subtract


class StockNotifyIn(BaseModel):
    email: EmailStr
    product_id: str
    variant_id: Optional[str] = None


# --- Catégories (BLOC 1) ----------------------------------------------------
# Les produits référencent une catégorie par SLUG (string), pas par id : aucune
# migration de données sur les produits existants.
_SLUG_RE = re.compile(r"^[a-z0-9-]+$")


class CategoryIn(BaseModel):
    slug: str = Field(min_length=1, max_length=60)
    name_en: str = Field(min_length=1, max_length=120)
    name_fr: str = Field(min_length=1, max_length=120)
    published: bool = True
    display_order: int = 0

    @field_validator("slug")
    @classmethod
    def _check_slug(cls, v: str) -> str:
        v = v.strip().lower()
        if not _SLUG_RE.match(v):
            raise ValueError("slug must match ^[a-z0-9-]+$")
        return v


class CategoryOut(CategoryIn):
    id: str
    created_at: str


# --- Menus (BLOC 2) ---------------------------------------------------------
class MenuItemIn(BaseModel):
    id: Optional[str] = None  # généré côté serveur si absent
    label_en: str = Field(min_length=1, max_length=120)
    label_fr: str = Field(min_length=1, max_length=120)
    url: str = Field(min_length=1, max_length=500)
    published: bool = True
    display_order: int = 0
    open_new_tab: bool = False


class MenuIn(BaseModel):
    slug: str = Field(min_length=1, max_length=60)
    name_en: str = Field(min_length=1, max_length=120)
    name_fr: str = Field(min_length=1, max_length=120)
    location: Literal["header", "footer"]
    published: bool = True
    display_order: int = 0
    items: List[MenuItemIn] = []

    @field_validator("slug")
    @classmethod
    def _check_slug(cls, v: str) -> str:
        v = v.strip().lower()
        if not _SLUG_RE.match(v):
            raise ValueError("slug must match ^[a-z0-9-]+$")
        return v


class MenuOut(MenuIn):
    id: str
    created_at: str


class NewsletterSubscribeIn(BaseModel):
    email: EmailStr
    lang: Optional[Literal["en", "fr"]] = "en"
    source: Optional[str] = "footer"  # d'où vient l'inscription (footer, popup, checkout…)


# --- Mon Compte -------------------------------------------------------------
class ProfileUpdateIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)


class PasswordChangeIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8)


class EmailChangeRequestIn(BaseModel):
    new_email: EmailStr
    current_password: str  # exigé : empêche un token volé de détourner le compte


class SavedAddressIn(BaseModel):
    label: Optional[str] = ""  # "Maison", "Labo", …
    full_name: str
    address1: str
    address2: Optional[str] = ""
    city: str
    province: str
    postal_code: str
    country: str = "CA"
    phone: Optional[str] = ""
    is_default: bool = False


class AccountDeleteIn(BaseModel):
    current_password: str  # confirmation forte avant action irréversible


class ShippingZoneIn(BaseModel):
    name: str
    countries: List[str] = []  # e.g., ["CA"], ["US"], ["INTL"]
    provinces: List[str] = []  # optional sub-region restriction (Canadian provinces)


class ShippingMethodIn(BaseModel):
    zone_id: str
    name: str  # e.g., "Canada Post Xpresspost", "Expedited", "International Tracked"
    cost_cad: float
    eta_days: str = ""  # e.g., "2-3 business days"
    active: bool = True


class ShippingRateRequest(BaseModel):
    postal_code: str
    country: str = "CA"
    items: Optional[List[CartItem]] = None  # used to estimate parcel weight; omit for a default estimate


# ---------------------------------------------------------------------------
# Tax & shipping (no tax — shipping flat-rate)
# ---------------------------------------------------------------------------
PROVINCES_CA = ["AB", "BC", "MB", "NB", "NL", "NS", "NT", "NU", "ON", "PE", "QC", "SK", "YT"]


# ---------------------------------------------------------------------------
# Auth endpoints
# ---------------------------------------------------------------------------
@api.post("/auth/register")
async def register(payload: RegisterIn, response: Response, request: Request):
    _rate_limit("register", _client_ip(request), 5, 3600, "Too many registration attempts. Try again later.")
    email = payload.email.lower().strip()
    if await db.users.find_one({"email": email}):
        raise HTTPException(status_code=409, detail="Email already registered")
    user_doc = {
        "id": str(uuid.uuid4()),
        "email": email,
        "name": payload.name.strip(),
        "password_hash": hash_password(payload.password),
        "role": "user",
        "token_version": 0,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.users.insert_one(user_doc)
    # Un abonné pré-lancement qui crée son compte : on marque la conversion.
    # N'interrompt jamais l'inscription si ça échoue.
    try:
        await db.subscribers.update_one({"email": email}, {"$set": {"converted": True}})
    except Exception as e:  # pragma: no cover
        logging.warning("subscriber conversion flag failed for %s: %s", email, e)
    # --- AUTOMATION: email de bienvenue (n'interrompt jamais l'inscription) ---
    asyncio.create_task(welcome_new_user(email, user_doc.get("name", ""), "fr"))
    token = create_access_token(user_doc["id"], email, "user", token_version=0)
    set_auth_cookie(response, token, request)
    return {
        "id": user_doc["id"],
        "email": email,
        "name": user_doc["name"],
        "role": "user",
        "created_at": user_doc["created_at"],
        # NOTE: le token n'est volontairement PAS renvoyé dans le body —
        # l'auth passe uniquement par le cookie httpOnly, donc une XSS
        # future ne peut pas exfiltrer la session.
    }


# In-memory brute-force protection: max 5 failed attempts per IP+email in a 15-min window
_LOGIN_ATTEMPTS: dict = {}
_LOGIN_MAX_ATTEMPTS = 5
_LOGIN_WINDOW_SECONDS = 900


def _client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for", "")
    return fwd.split(",")[0].strip() if fwd else (request.client.host if request.client else "unknown")


def _login_throttle_check(key: str):
    now = datetime.now(timezone.utc).timestamp()
    attempts = [t for t in _LOGIN_ATTEMPTS.get(key, []) if now - t < _LOGIN_WINDOW_SECONDS]
    _LOGIN_ATTEMPTS[key] = attempts
    if len(attempts) >= _LOGIN_MAX_ATTEMPTS:
        raise HTTPException(status_code=429, detail="Too many login attempts. Try again in 15 minutes.")


# In-memory rate limiting for public write endpoints (same pattern as login throttle).
_RATE_BUCKETS: dict = {}
_RATE_LAST_SWEEP = {"t": 0.0}


def _sweep_rate_buckets(now: float, window_seconds: int) -> None:
    """Purge les clés expirées. Sans ça, chaque IP unique laissait une entrée
    permanente dans le dict → croissance mémoire linéaire au trafic."""
    if now - _RATE_LAST_SWEEP["t"] < 300:
        return
    _RATE_LAST_SWEEP["t"] = now
    for bname, b in list(_RATE_BUCKETS.items()):
        for k, ts in list(b.items()):
            if not [t for t in ts if now - t < window_seconds]:
                b.pop(k, None)
        if not b:
            _RATE_BUCKETS.pop(bname, None)
    for k, ts in list(_LOGIN_ATTEMPTS.items()):
        if not [t for t in ts if now - t < _LOGIN_WINDOW_SECONDS]:
            _LOGIN_ATTEMPTS.pop(k, None)


def _rate_limit(bucket: str, key: str, max_hits: int, window_seconds: int, detail: str):
    now = datetime.now(timezone.utc).timestamp()
    _sweep_rate_buckets(now, window_seconds)
    b = _RATE_BUCKETS.setdefault(bucket, {})
    hits = [t for t in b.get(key, []) if now - t < window_seconds]
    if len(hits) >= max_hits:
        b[key] = hits
        raise HTTPException(status_code=429, detail=detail)
    hits.append(now)
    b[key] = hits


class AdminGateIn(BaseModel):
    code: str


class TrashIdsIn(BaseModel):
    ids: List[str] = Field(min_length=1, max_length=200)


# ---------------------------------------------------------------------------
# Corbeille générique — même principe pour toutes les données supprimables :
# suppression douce (deleted_at posé, rien n'est perdu), restauration en un
# clic, purge automatique après 30 jours (SAUF les commandes — voir note).
#
# ⚠️ Les commandes ne sont PAS purgées automatiquement : une commande payée
# est une pièce comptable. Elle reste en corbeille indéfiniment jusqu'à une
# purge manuelle explicite par un owner. Tous les autres types (produits,
# coupons, zones/méthodes de livraison) suivent la règle des 30 jours.
# ---------------------------------------------------------------------------
TRASH_RESOURCES = {
    "products":         {"collection": "products",         "area": "products",  "has_active": True,  "auto_purge_days": 30},
    "coupons":          {"collection": "coupons",           "area": "coupons",   "has_active": True,  "auto_purge_days": 30},
    "shipping_zones":   {"collection": "shipping_zones",    "area": "shipping",  "has_active": False, "auto_purge_days": 30},
    "shipping_methods": {"collection": "shipping_methods",  "area": "shipping",  "has_active": True,  "auto_purge_days": 30},
    "shipping_boxes":   {"collection": "shipping_boxes",    "area": "shipping",  "has_active": True,  "auto_purge_days": 30},
    "orders":           {"collection": "orders",            "area": "orders",    "has_active": False, "auto_purge_days": None},
}


async def _soft_delete(resource: str, item_id: str, admin: dict) -> dict:
    cfg = TRASH_RESOURCES[resource]
    coll = getattr(db, cfg["collection"])
    doc = await coll.find_one({"id": item_id})
    if not doc:
        raise HTTPException(status_code=404, detail=f"{resource[:-1].capitalize()} not found")
    update = {"deleted_at": datetime.now(timezone.utc).isoformat(), "deleted_by": admin.get("id")}
    if cfg["has_active"]:
        update["_pre_delete_active"] = doc.get("active", True)
        update["active"] = False
    await coll.update_one({"id": item_id}, {"$set": update})
    await _log_action(admin, f"{resource}.delete", area=cfg["area"], detail=f"Moved {resource[:-1]} {item_id} to trash")
    return {"ok": True}


@api.get("/admin/trash/{resource}")
async def admin_list_trash(resource: str, admin: dict = Depends(get_admin_user)):
    if resource not in TRASH_RESOURCES:
        raise HTTPException(status_code=404, detail="Unknown resource")
    coll = getattr(db, TRASH_RESOURCES[resource]["collection"])
    items = await coll.find({"deleted_at": {"$ne": None}}, {"_id": 0}).sort("deleted_at", -1).to_list(500)
    return items


@api.post("/admin/trash/{resource}/restore")
async def admin_restore_trash(resource: str, payload: TrashIdsIn, admin: dict = Depends(get_admin_user)):
    if resource not in TRASH_RESOURCES:
        raise HTTPException(status_code=404, detail="Unknown resource")
    cfg = TRASH_RESOURCES[resource]
    coll = getattr(db, cfg["collection"])
    restored = 0
    for item_id in payload.ids:
        doc = await coll.find_one({"id": item_id, "deleted_at": {"$ne": None}})
        if not doc:
            continue
        update = {}
        if cfg["has_active"]:
            update["active"] = doc.get("_pre_delete_active", True)
        unset = {"deleted_at": "", "deleted_by": "", "_pre_delete_active": ""}
        await coll.update_one({"id": item_id}, {"$set": update, "$unset": unset} if update else {"$unset": unset})
        restored += 1
    await _log_action(admin, f"{resource}.restore", area=cfg["area"], detail=f"Restored {restored} {resource}")
    return {"ok": True, "restored": restored}


@api.post("/admin/trash/{resource}/purge")
async def admin_purge_trash(resource: str, payload: TrashIdsIn, admin: dict = Depends(get_admin_user)):
    """Suppression DÉFINITIVE et immédiate des éléments sélectionnés — action
    irréversible, y compris pour les commandes (purge manuelle uniquement)."""
    if resource not in TRASH_RESOURCES:
        raise HTTPException(status_code=404, detail="Unknown resource")
    cfg = TRASH_RESOURCES[resource]
    coll = getattr(db, cfg["collection"])
    res = await coll.delete_many({"id": {"$in": payload.ids}, "deleted_at": {"$ne": None}})
    await _log_action(admin, f"{resource}.purge", area=cfg["area"],
                      detail=f"Permanently deleted {res.deleted_count} {resource}")
    return {"ok": True, "purged": res.deleted_count}


async def _trash_auto_purge_watchdog():
    """Purge automatiquement après 30 jours — sauf les commandes (auto_purge_days=None).
    Tourne dans le même worker verrouillé que les autres tâches de fond."""
    while True:
        try:
            now = datetime.now(timezone.utc)
            for resource, cfg in TRASH_RESOURCES.items():
                if cfg["auto_purge_days"] is None:
                    continue
                cutoff = (now - timedelta(days=cfg["auto_purge_days"])).isoformat()
                coll = getattr(db, cfg["collection"])
                res = await coll.delete_many({"deleted_at": {"$ne": None, "$lt": cutoff}})
                if res.deleted_count:
                    logging.info("[trash] auto-purged %d %s older than %d days",
                                res.deleted_count, resource, cfg["auto_purge_days"])
        except Exception as e:
            logging.error("[trash] auto-purge watchdog error: %s", e)
        await asyncio.sleep(6 * 3600)  # toutes les 6h


class StaffPermissionsIn(BaseModel):
    orders: Literal["none", "view", "manage"] = "none"
    products: Literal["none", "view", "manage"] = "none"
    coupons: Literal["none", "view", "manage"] = "none"
    customers: Literal["none", "view", "manage"] = "none"
    subscribers: Literal["none", "view", "manage"] = "none"
    shipping: Literal["none", "view", "manage"] = "none"
    dashboard: Literal["none", "view", "manage"] = "none"
    # Zones additionnelles — alignées sur la nav admin frontend pour qu'un
    # compte staff puisse réellement se voir accorder l'accès à chacune.
    categories: Literal["none", "view", "manage"] = "none"
    menus: Literal["none", "view", "manage"] = "none"
    affiliates: Literal["none", "view", "manage"] = "none"
    seo: Literal["none", "view", "manage"] = "none"
    emails: Literal["none", "view", "manage"] = "none"
    audit: Literal["none", "view", "manage"] = "none"
    trash: Literal["none", "view", "manage"] = "none"
    staff: Literal["none", "view", "manage"] = "none"


class StaffInviteIn(BaseModel):
    email: EmailStr
    name: str = Field(min_length=1, max_length=120)
    permissions: StaffPermissionsIn
    as_owner: bool = False  # invite directement comme admin (owner) — accès total


class StaffAcceptIn(BaseModel):
    token: str
    password: str = Field(min_length=8)


@api.post("/admin/gate/verify")
async def admin_gate_verify(payload: AdminGateIn, request: Request):
    """Passerelle avant le login admin — voir ADMIN_GATE_CODE plus haut.
    Rate-limit distinct et plus strict que le login (pas de compte à protéger
    ici, juste dissuader le brute-force du code lui-même)."""
    if not ADMIN_GATE_CODE:
        return {"ok": True}  # passerelle désactivée si aucun code configuré
    _rate_limit("admin_gate", _client_ip(request), 5, 3600, "Too many attempts. Try again later.")
    if not secrets.compare_digest(payload.code, ADMIN_GATE_CODE):
        raise HTTPException(status_code=403, detail="Invalid code")
    return {"ok": True}


@api.post("/auth/login")
async def login(payload: LoginIn, response: Response, request: Request):
    email = payload.email.lower().strip()
    throttle_key = f"{_client_ip(request)}:{email}"
    _login_throttle_check(throttle_key)
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(payload.password, user["password_hash"]):
        _LOGIN_ATTEMPTS.setdefault(throttle_key, []).append(datetime.now(timezone.utc).timestamp())
        raise HTTPException(status_code=401, detail="Invalid email or password")
    _LOGIN_ATTEMPTS.pop(throttle_key, None)
    token = create_access_token(user["id"], user["email"], user["role"], token_version=user.get("token_version", 0))
    set_auth_cookie(response, token, request)
    return {
        "id": user["id"],
        "email": user["email"],
        "name": user["name"],
        "role": user["role"],
        "created_at": user["created_at"],
        # NOTE: auth cookie-only — pas de token dans le body.
    }


@api.post("/auth/logout")
async def logout(response: Response):
    clear_auth_cookie(response)
    return {"ok": True}


@api.post("/auth/logout-all")
async def logout_all_devices(response: Response, user: dict = Depends(get_current_user)):
    """Révoque tous les tokens émis avant cet appel, sur tous les appareils.
    Utile après un changement de mot de passe suspect ou une perte d'appareil."""
    await db.users.update_one({"id": user["id"]}, {"$inc": {"token_version": 1}})
    clear_auth_cookie(response)
    return {"ok": True}


@api.get("/auth/me")
async def me(user: dict = Depends(get_current_user)):
    return user


# ---------------------------------------------------------------------------
# Magic link natif — auth sans mot de passe sur NOTRE backend (pas Supabase).
# Cohabite avec le login/register classique. Cookie httpOnly identique.
# ---------------------------------------------------------------------------
MAGIC_TOKEN_TTL_MINUTES = 15
MAGIC_REQUEST_MAX = 5
MAGIC_REQUEST_WINDOW = 3600


class MagicRequestIn(BaseModel):
    email: EmailStr
    name: Optional[str] = None
    create: bool = False
    lang: str = "fr"


def _hash_magic_token(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


async def _send_magic_email(email: str, link: str, lang: str, is_signup: bool) -> None:
    fr = lang.startswith("fr")
    if fr:
        subject = "Votre lien de connexion Fironova"
        heading = "Bienvenue chez Fironova" if is_signup else "Connexion à Fironova"
        intro = ("Confirmez votre adresse pour activer votre compte."
                 if is_signup else "Cliquez pour vous connecter sans mot de passe.")
        cta = "Activer mon compte" if is_signup else "Me connecter"
        expiry = f"Ce lien expire dans {MAGIC_TOKEN_TTL_MINUTES} minutes et ne sert qu'une fois."
        ignore = "Si vous n'êtes pas à l'origine de cette demande, ignorez cet email."
    else:
        subject = "Your Fironova sign-in link"
        heading = "Welcome to Fironova" if is_signup else "Sign in to Fironova"
        intro = ("Confirm your address to activate your account."
                 if is_signup else "Click to sign in without a password.")
        cta = "Activate my account" if is_signup else "Sign me in"
        expiry = f"This link expires in {MAGIC_TOKEN_TTL_MINUTES} minutes and works only once."
        ignore = "If you didn't request this, you can safely ignore this email."
    html = f"""\
<div style="font-family:Inter,-apple-system,Segoe UI,sans-serif;max-width:520px;margin:0 auto;background:#F7FAFC;padding:40px 24px;">
  <div style="background:#0B2E4F;border-radius:20px 20px 0 0;padding:28px 32px;">
    <span style="font-family:'Space Grotesk',sans-serif;color:#F7FAFC;font-size:20px;font-weight:700;letter-spacing:-0.02em;">FIRONOVA</span>
    <span style="color:#00B8D4;font-size:20px;font-weight:700;"> ·</span>
  </div>
  <div style="background:#ffffff;border-radius:0 0 20px 20px;padding:36px 32px;border:1px solid #E2E8F0;border-top:none;">
    <h1 style="font-family:'Space Grotesk',sans-serif;color:#0B2E4F;font-size:24px;font-weight:700;margin:0 0 12px;">{heading}</h1>
    <p style="color:#334155;font-size:15px;line-height:1.6;margin:0 0 28px;">{intro}</p>
    <a href="{link}" style="display:inline-block;background:#00B8D4;color:#0B2E4F;font-weight:700;text-decoration:none;padding:14px 32px;border-radius:999px;font-size:15px;">{cta} &rarr;</a>
    <p style="color:#64748B;font-size:12px;line-height:1.6;margin:28px 0 0;font-family:'JetBrains Mono',monospace;">{expiry}</p>
    <p style="color:#94A3B8;font-size:12px;line-height:1.6;margin:8px 0 0;">{ignore}</p>
    <hr style="border:none;border-top:1px solid #E2E8F0;margin:24px 0 12px;">
    <p style="color:#94A3B8;font-size:11px;line-height:1.5;margin:0;">Produits destin&eacute;s &agrave; la recherche uniquement (RUO). R&eacute;serv&eacute; aux 18 ans et plus.<br>For Research Use Only. 18+ only.</p>
  </div>
</div>"""
    from_addr = MAGIC_SENDER_EMAIL or SENDER_EMAIL
    await _send_email(email, subject, html, from_email=from_addr)


@api.post("/auth/magic/request")
async def magic_request(payload: MagicRequestIn, request: Request):
    """Émet un lien magique. Réponse uniforme : ne révèle jamais si l'email existe."""
    _rate_limit("magic_request", _client_ip(request), MAGIC_REQUEST_MAX,
                MAGIC_REQUEST_WINDOW, "Trop de demandes. Réessayez plus tard.")
    email = payload.email.lower().strip()
    existing = await db.users.find_one({"email": email})
    is_signup = payload.create and not existing
    # Login demandé sur un email inconnu -> réponse neutre, aucun email (anti-énumération).
    if not payload.create and not existing:
        return {"ok": True}
    raw = secrets.token_urlsafe(32)
    await db.magic_tokens.insert_one({
        "id": str(uuid.uuid4()),
        "email": email,
        "token_hash": _hash_magic_token(raw),
        "is_signup": is_signup,
        "name": (payload.name or "").strip()[:120],
        "created_at": datetime.now(timezone.utc).isoformat(),
        "expires_at": (datetime.now(timezone.utc) + timedelta(minutes=MAGIC_TOKEN_TTL_MINUTES)).isoformat(),
        "used_at": None,
        "ip": _client_ip(request),
    })
    base = PUBLIC_BASE_URL or str(request.base_url).rstrip("/")
    link = f"{base}/auth/callback?token={raw}"
    await _send_magic_email(email, link, payload.lang or "fr", is_signup)
    return {"ok": True}


@api.post("/auth/magic/verify")
async def magic_verify(response: Response, request: Request, token: str = Body(..., embed=True)):
    """Vérifie le token (usage unique + TTL), crée le compte si signup, pose le cookie."""
    token_hash = _hash_magic_token((token or "").strip())
    rec = await db.magic_tokens.find_one({"token_hash": token_hash})
    now = datetime.now(timezone.utc)
    invalid = HTTPException(status_code=400, detail="Lien invalide ou expiré.")
    if not rec or rec.get("used_at"):
        raise invalid
    try:
        if datetime.fromisoformat(rec["expires_at"]) < now:
            raise invalid
    except HTTPException:
        raise
    except Exception:
        raise invalid
    claimed = await db.magic_tokens.update_one(
        {"_id": rec["_id"], "used_at": None},
        {"$set": {"used_at": now.isoformat()}},
    )
    if claimed.modified_count != 1:
        raise invalid
    email = rec["email"]
    user = await db.users.find_one({"email": email})
    if not user:
        user_doc = {
            "id": str(uuid.uuid4()),
            "email": email,
            "name": rec.get("name") or email.split("@")[0],
            "password_hash": hash_password(secrets.token_urlsafe(32)),
            "role": "user",
            "token_version": 0,
            "created_at": now.isoformat(),
            "passwordless": True,
        }
        await db.users.insert_one(user_doc)
        try:
            await db.subscribers.update_one({"email": email}, {"$set": {"converted": True}})
        except Exception as e:  # pragma: no cover
            logging.warning("subscriber conversion flag failed for %s: %s", email, e)
        user = user_doc
    token_jwt = create_access_token(user["id"], user["email"], user["role"],
                                    token_version=user.get("token_version", 0))
    set_auth_cookie(response, token_jwt)
    return {
        "id": user["id"], "email": user["email"], "name": user["name"],
        "role": user["role"], "created_at": user["created_at"],
    }


async def _magic_tokens_cleanup():
    while True:
        try:
            cutoff = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
            res = await db.magic_tokens.delete_many({"expires_at": {"$lt": cutoff}})
            if res.deleted_count:
                logging.info("[magic] purged %d expired tokens", res.deleted_count)
        except Exception as e:
            logging.error("[magic] cleanup error: %s", e)
        await asyncio.sleep(6 * 3600)



# ---------------------------------------------------------------------------
# Mon Compte — profil, mot de passe, changement d'email (double opt-in),
# adresses sauvegardées, suppression de compte avec anonymisation.
# ---------------------------------------------------------------------------
EMAIL_CHANGE_TTL_HOURS = 24


@api.put("/account/profile")
async def account_update_profile(payload: ProfileUpdateIn, user: dict = Depends(get_current_user)):
    name = payload.name.strip()
    await db.users.update_one({"id": user["id"]}, {"$set": {"name": name}})
    return {"ok": True, "name": name}


@api.put("/account/password")
async def account_change_password(payload: PasswordChangeIn, response: Response,
                                  user: dict = Depends(get_current_user)):
    doc = await db.users.find_one({"id": user["id"]})
    if not doc or not verify_password(payload.current_password, doc["password_hash"]):
        raise HTTPException(status_code=403, detail="Current password is incorrect")
    new_tv = doc.get("token_version", 0) + 1
    await db.users.update_one(
        {"id": user["id"]},
        {"$set": {"password_hash": hash_password(payload.new_password), "token_version": new_tv}},
    )
    # On révoque tous les anciens tokens (token_version+1) mais on ré-émet
    # immédiatement un token frais pour CET appareil : l'utilisateur qui vient
    # de changer son mot de passe ne doit pas être déconnecté lui-même.
    token = create_access_token(doc["id"], doc["email"], doc["role"], token_version=new_tv)
    set_auth_cookie(response, token)
    # Le cookie httpOnly frais suffit — pas de token dans le body.
    return {"ok": True}


def _email_change_html(confirm_url: str, lang: str = "fr") -> str:
    if lang == "fr":
        heading = "Confirmez votre nouvelle adresse email"
        body = ("Vous avez demandé à changer l'adresse email de votre compte FIRONOVA. "
                "Cliquez sur le bouton ci-dessous pour confirmer. "
                f"Ce lien expire dans {EMAIL_CHANGE_TTL_HOURS} heures. "
                "Si vous n'êtes pas à l'origine de cette demande, ignorez ce message.")
        btn = "Confirmer mon email"
    else:
        heading = "Confirm your new email address"
        body = ("You requested to change the email on your FIRONOVA account. "
                "Click the button below to confirm. "
                f"This link expires in {EMAIL_CHANGE_TTL_HOURS} hours. "
                "If you didn't request this, you can safely ignore this message.")
        btn = "Confirm my email"
    return f"""
    <div style="font-family:Georgia,serif;max-width:520px;margin:0 auto;padding:32px;color:#3A0A08;background:#FFFAF6">
      <div style="font-size:22px;font-weight:800;letter-spacing:-0.5px">FIRONOVA<span style="color:#00B8D4">.</span></div>
      <h2 style="margin-top:24px">{heading}</h2>
      <p style="line-height:1.6">{body}</p>
      <a href="{confirm_url}" style="display:inline-block;margin-top:16px;background:#3A0A08;color:#fff;
         padding:14px 28px;text-decoration:none;font-family:monospace;font-size:12px;
         letter-spacing:0.2em;text-transform:uppercase">{btn} →</a>
      <p style="margin-top:24px;font-size:12px;color:#6B0504">{confirm_url}</p>
    </div>
    """


@api.post("/account/email/request-change")
async def account_request_email_change(payload: EmailChangeRequestIn, request: Request,
                                       user: dict = Depends(get_current_user)):
    _rate_limit("email_change", user["id"], 3, 3600, "Too many email change requests. Try again later.")
    doc = await db.users.find_one({"id": user["id"]})
    if not doc or not verify_password(payload.current_password, doc["password_hash"]):
        raise HTTPException(status_code=403, detail="Current password is incorrect")
    new_email = payload.new_email.lower().strip()
    if new_email == doc["email"]:
        raise HTTPException(status_code=400, detail="This is already your email address")
    if await db.users.find_one({"email": new_email}):
        raise HTTPException(status_code=409, detail="Email already in use")

    token = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    await db.email_change_requests.insert_one({
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "new_email": new_email,
        "token": token,
        "created_at": now.isoformat(),
        "expires_at": (now + timedelta(hours=EMAIL_CHANGE_TTL_HOURS)).isoformat(),
        "used": False,
    })
    base = PUBLIC_BASE_URL or str(request.base_url).rstrip("/")
    confirm_url = f"{base}/api/account/email/confirm?token={token}"
    lang = "fr"  # les emails transactionnels suivent la langue du site ; FR par défaut au Québec
    asyncio.create_task(_send_email(new_email, "FIRONOVA — Confirmez votre nouvelle adresse email",
                                    _email_change_html(confirm_url, lang)))
    return {"ok": True, "sent_to": new_email}


@api.get("/account/email/confirm")
async def account_confirm_email_change(token: str):
    """Lien cliqué depuis l'email — pas d'authentification (l'utilisateur peut
    ouvrir le lien sur un autre appareil). Le token à usage unique + TTL fait
    office de preuve."""
    now = datetime.now(timezone.utc).isoformat()
    req = await db.email_change_requests.find_one({"token": token, "used": False})
    if not req or req["expires_at"] < now:
        raise HTTPException(status_code=400, detail="Invalid or expired confirmation link")
    # Re-vérifier l'unicité : l'email a pu être pris entre la demande et le clic.
    if await db.users.find_one({"email": req["new_email"]}):
        raise HTTPException(status_code=409, detail="Email already in use")
    user = await db.users.find_one({"id": req["user_id"]})
    if not user:
        raise HTTPException(status_code=404, detail="Account not found")

    await db.users.update_one(
        {"id": req["user_id"]},
        {"$set": {"email": req["new_email"]},
         "$inc": {"token_version": 1}},  # révoque les sessions liées à l'ancien email
    )
    await db.email_change_requests.update_one({"token": token}, {"$set": {"used": True, "used_at": now}})
    # Réponse HTML minimale : le lien est ouvert dans un navigateur, pas via l'app.
    return Response(
        content=f"""<!doctype html><html><body style="font-family:Georgia,serif;background:#FFFAF6;color:#3A0A08;
        display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
        <div style="text-align:center"><div style="font-size:22px;font-weight:800">FIRONOVA<span style="color:#00B8D4">.</span></div>
        <h2>Email confirmé ✓ / Email confirmed ✓</h2>
        <p>Reconnectez-vous avec votre nouvelle adresse.<br/>Please sign in again with your new address.</p>
        </div></body></html>""",
        media_type="text/html",
    )


# --- Adresses sauvegardées ---------------------------------------------------
@api.get("/account/addresses")
async def account_list_addresses(user: dict = Depends(get_current_user)):
    return await db.addresses.find({"user_id": user["id"]}, {"_id": 0}).sort("created_at", -1).to_list(20)


@api.post("/account/addresses")
async def account_add_address(payload: SavedAddressIn, user: dict = Depends(get_current_user)):
    count = await db.addresses.count_documents({"user_id": user["id"]})
    if count >= 10:
        raise HTTPException(status_code=400, detail="Address limit reached (10)")
    doc = payload.model_dump()
    doc.update({
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "created_at": datetime.now(timezone.utc).isoformat(),
    })
    # Première adresse = défaut automatique ; sinon respecter le flag envoyé.
    if count == 0:
        doc["is_default"] = True
    elif doc["is_default"]:
        await db.addresses.update_many({"user_id": user["id"]}, {"$set": {"is_default": False}})
    await db.addresses.insert_one(doc)
    doc.pop("_id", None)
    return doc


@api.put("/account/addresses/{address_id}")
async def account_update_address(address_id: str, payload: SavedAddressIn,
                                 user: dict = Depends(get_current_user)):
    existing = await db.addresses.find_one({"id": address_id, "user_id": user["id"]})
    if not existing:
        raise HTTPException(status_code=404, detail="Address not found")
    doc = payload.model_dump()
    if doc["is_default"]:
        await db.addresses.update_many({"user_id": user["id"]}, {"$set": {"is_default": False}})
    await db.addresses.update_one({"id": address_id, "user_id": user["id"]}, {"$set": doc})
    fresh = await db.addresses.find_one({"id": address_id}, {"_id": 0})
    return fresh


@api.delete("/account/addresses/{address_id}")
async def account_delete_address(address_id: str, user: dict = Depends(get_current_user)):
    res = await db.addresses.delete_one({"id": address_id, "user_id": user["id"]})
    if not res.deleted_count:
        raise HTTPException(status_code=404, detail="Address not found")
    # Si on vient de supprimer l'adresse par défaut, promouvoir la plus récente.
    remaining_default = await db.addresses.find_one({"user_id": user["id"], "is_default": True})
    if not remaining_default:
        newest = await db.addresses.find_one({"user_id": user["id"]}, sort=[("created_at", -1)])
        if newest:
            await db.addresses.update_one({"id": newest["id"]}, {"$set": {"is_default": True}})
    return {"ok": True}


# --- Suppression de compte (PIPEDA / Loi 25) ---------------------------------
@api.post("/account/delete")
async def account_delete(payload: AccountDeleteIn, response: Response,
                         user: dict = Depends(get_current_user)):
    """Suppression du compte + anonymisation des commandes.
    Les commandes sont CONSERVÉES (obligations comptables/fiscales) mais toutes
    les données personnelles y sont remplacées. Irréversible."""
    doc = await db.users.find_one({"id": user["id"]})
    if not doc or not verify_password(payload.current_password, doc["password_hash"]):
        raise HTTPException(status_code=403, detail="Current password is incorrect")
    if doc.get("role") == "admin":
        raise HTTPException(status_code=400, detail="Admin accounts cannot be self-deleted")

    now = datetime.now(timezone.utc).isoformat()
    anon = f"deleted-user-{doc['id'][:8]}"

    # 1. Anonymiser les commandes (on garde montants, items, dates — pas l'identité)
    await db.orders.update_many(
        {"user_id": doc["id"]},
        {"$set": {
            "email": f"{anon}@anonymized.invalid",
            "shipping_address.full_name": "[deleted]",
            "shipping_address.address1": "[deleted]",
            "shipping_address.address2": "",
            "shipping_address.phone": "",
            "anonymized_at": now,
        }},
    )
    # 2. Purger les données annexes
    await db.addresses.delete_many({"user_id": doc["id"]})
    await db.stock_notifications.delete_many({"email": doc["email"]})
    await db.subscribers.delete_one({"email": doc["email"]})
    await db.email_change_requests.delete_many({"user_id": doc["id"]})
    # 3. Supprimer l'utilisateur
    await db.users.delete_one({"id": doc["id"]})
    clear_auth_cookie(response)
    logging.info("Account deleted + orders anonymized for user %s", anon)
    return {"ok": True}


# ---------------------------------------------------------------------------
# Product endpoints
# ---------------------------------------------------------------------------
@api.get("/products")
async def list_products(category: Optional[str] = None, q: Optional[str] = None, featured: Optional[bool] = None):
    filt: dict = {"active": True}
    if category and category != "all":
        filt["category"] = category
    if featured is True:
        filt["featured"] = True
    if q:
        # Neutralise les métacaractères regex : sans ça, un `q` du type
        # "(a+)+$" est injecté tel quel dans MongoDB → ReDoS / scan complet.
        q_safe = re.escape(q.strip())
        filt["$or"] = [
            {"name_en": {"$regex": q_safe, "$options": "i"}},
            {"name_fr": {"$regex": q_safe, "$options": "i"}},
            {"slug": {"$regex": q_safe, "$options": "i"}},
        ]
    products = await db.products.find(filt, {"_id": 0}).sort("name_en", 1).to_list(500)
    return products


@api.get("/products/{slug}")
async def get_product(slug: str):
    product = await db.products.find_one({"slug": slug}, {"_id": 0})
    if not product:
        raise HTTPException(404, "Product not found")
    return product


@api.post("/notify-stock")
async def notify_stock_request(payload: StockNotifyIn, request: Request):
    _rate_limit("notify_stock", _client_ip(request), 10, 3600, "Too many requests. Try again later.")
    """Public endpoint — a visitor asks to be emailed once a sold-out product/variant is back."""
    product = await db.products.find_one({"id": payload.product_id}, {"_id": 0})
    if not product:
        raise HTTPException(404, "Product not found")
    variant_id = payload.variant_id
    if variant_id and not any(v.get("id") == variant_id for v in product.get("variants", [])):
        raise HTTPException(400, "Variant not found for this product")
    email = payload.email.lower().strip()
    existing = await db.stock_notifications.find_one({
        "email": email, "product_id": payload.product_id, "variant_id": variant_id, "notified": False,
    })
    if existing:
        return {"ok": True, "already_subscribed": True}
    await db.stock_notifications.insert_one({
        "id": str(uuid.uuid4()),
        "email": email,
        "product_id": payload.product_id,
        "variant_id": variant_id,
        "notified": False,
        "created_at": datetime.now(timezone.utc).isoformat(),
    })
    return {"ok": True, "already_subscribed": False}


# ---------------------------------------------------------------------------
# BLOC 1 — Catégories : collection réelle + CRUD admin + publication.
# Les produits continuent de référencer une catégorie par slug (string) : aucune
# migration produit, aucune rupture des 12 produits seedés.
# ---------------------------------------------------------------------------
@api.get("/categories")
async def list_categories():
    """Vitrine : uniquement les catégories publiées."""
    return await db.categories.find({"published": True}, {"_id": 0}).sort("display_order", 1).to_list(200)


@api.get("/admin/categories")
async def admin_list_categories(_admin: dict = Depends(get_admin_user)):
    return await db.categories.find({}, {"_id": 0}).sort("display_order", 1).to_list(200)


@api.post("/admin/categories")
async def admin_create_category(payload: CategoryIn, _admin: dict = Depends(get_admin_user)):
    doc = payload.model_dump()
    doc["id"] = str(uuid.uuid4())
    doc["created_at"] = datetime.now(timezone.utc).isoformat()
    try:
        await db.categories.insert_one(dict(doc))
    except DuplicateKeyError:
        raise HTTPException(409, f"A category with slug '{doc['slug']}' already exists")
    doc.pop("_id", None)
    return doc


@api.put("/admin/categories/{cat_id}")
async def admin_update_category(cat_id: str, payload: CategoryIn, _admin: dict = Depends(get_admin_user)):
    existing = await db.categories.find_one({"id": cat_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Category not found")
    new = payload.model_dump()
    old_slug, new_slug = existing["slug"], new["slug"]

    if new_slug != old_slug and await db.categories.find_one({"slug": new_slug, "id": {"$ne": cat_id}}):
        raise HTTPException(409, f"A category with slug '{new_slug}' already exists")

    await db.categories.update_one({"id": cat_id}, {"$set": new})

    # Cascade : renommer un slug ne doit jamais orpheliner les produits.
    migrated = 0
    if new_slug != old_slug:
        res = await db.products.update_many({"category": old_slug}, {"$set": {"category": new_slug}})
        migrated = res.modified_count

    out = {**existing, **new}
    out["products_migrated"] = migrated
    return out


@api.delete("/admin/categories/{cat_id}")
async def admin_delete_category(cat_id: str, _admin: dict = Depends(get_admin_user)):
    cat = await db.categories.find_one({"id": cat_id}, {"_id": 0})
    if not cat:
        raise HTTPException(404, "Category not found")
    in_use = await db.products.count_documents({"category": cat["slug"]})
    if in_use:
        # Même principe que le soft-delete produit lié à des commandes : on masque.
        await db.categories.update_one({"id": cat_id}, {"$set": {"published": False}})
        raise HTTPException(
            409,
            f"Category in use by {in_use} product(s); it has been hidden instead of deleted.",
        )
    await db.categories.delete_one({"id": cat_id})
    return {"ok": True, "deleted": True}


# ---------------------------------------------------------------------------
# BLOC 2 — Menus : navigation header/footer pilotée depuis l'admin.
# ---------------------------------------------------------------------------
def _normalize_menu_items(items: list) -> list:
    out = []
    for it in items:
        d = dict(it)
        if not d.get("id"):
            d["id"] = str(uuid.uuid4())
        out.append(d)
    return out


@api.get("/menus")
async def list_menus(location: Optional[str] = None):
    """Vitrine : menus publiés, items non publiés retirés."""
    filt: dict = {"published": True}
    if location:
        filt["location"] = location
    menus = await db.menus.find(filt, {"_id": 0}).sort("display_order", 1).to_list(50)
    for m in menus:
        m["items"] = sorted(
            [i for i in m.get("items", []) if i.get("published", True)],
            key=lambda i: i.get("display_order", 0),
        )
    return menus


@api.get("/admin/menus")
async def admin_list_menus(_admin: dict = Depends(get_admin_user)):
    return await db.menus.find({}, {"_id": 0}).sort("display_order", 1).to_list(50)


@api.post("/admin/menus")
async def admin_create_menu(payload: MenuIn, _admin: dict = Depends(get_admin_user)):
    doc = payload.model_dump()
    doc["items"] = _normalize_menu_items(doc.get("items") or [])
    doc["id"] = str(uuid.uuid4())
    doc["created_at"] = datetime.now(timezone.utc).isoformat()
    try:
        await db.menus.insert_one(dict(doc))
    except DuplicateKeyError:
        raise HTTPException(409, f"A menu with slug '{doc['slug']}' already exists")
    doc.pop("_id", None)
    return doc


@api.put("/admin/menus/{menu_id}")
async def admin_update_menu(menu_id: str, payload: MenuIn, _admin: dict = Depends(get_admin_user)):
    existing = await db.menus.find_one({"id": menu_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Menu not found")
    new = payload.model_dump()
    if new["slug"] != existing["slug"] and await db.menus.find_one({"slug": new["slug"], "id": {"$ne": menu_id}}):
        raise HTTPException(409, f"A menu with slug '{new['slug']}' already exists")
    # Les ids d'items existants sont conservés ; seuls les nouveaux en reçoivent un.
    new["items"] = _normalize_menu_items(new.get("items") or [])
    await db.menus.update_one({"id": menu_id}, {"$set": new})
    return {**existing, **new}


@api.delete("/admin/menus/{menu_id}")
async def admin_delete_menu(menu_id: str, _admin: dict = Depends(get_admin_user)):
    res = await db.menus.delete_one({"id": menu_id})
    if not res.deleted_count:
        raise HTTPException(404, "Menu not found")
    return {"ok": True, "deleted": True}


# ---------------------------------------------------------------------------
# BLOC 3 — Prélancement : vérification du jeton d'aperçu.
# Le jeton n'est JAMAIS exposé via /meta — seule cette comparaison serveur existe.
# ---------------------------------------------------------------------------
@api.get("/prelaunch/preview")
async def prelaunch_preview(token: str, request: Request):
    _rate_limit("prelaunch_preview", _client_ip(request), 20, 3600, "Too many attempts. Try again later.")
    if not PRELAUNCH_PREVIEW_TOKEN:
        return {"ok": False}
    return {"ok": hmac.compare_digest(token or "", PRELAUNCH_PREVIEW_TOKEN)}


# ---------------------------------------------------------------------------
# Newsletter / subscribers — conforme LCAP (CASL) : on conserve la preuve de
# consentement (date, IP, source) pour chaque inscription, et un lien de
# désabonnement fonctionne sans authentification (obligatoire par la loi).
# ---------------------------------------------------------------------------
@api.post("/newsletter/subscribe")
async def newsletter_subscribe(payload: NewsletterSubscribeIn, request: Request):
    _rate_limit("newsletter_subscribe", _client_ip(request), 10, 3600, "Too many requests. Try again later.")
    email = payload.email.lower().strip()
    now = datetime.now(timezone.utc).isoformat()
    ip = _client_ip(request)

    existing = await db.subscribers.find_one({"email": email}, {"_id": 0})
    if existing and existing.get("status") == "subscribed":
        return {"ok": True, "already_subscribed": True}

    if existing:
        # Ancien désabonné qui se réinscrit : nouveau consentement, nouvelle preuve.
        await db.subscribers.update_one(
            {"email": email},
            {"$set": {
                "status": "subscribed",
                "lang": payload.lang,
                "source": payload.source,
                "consent_at": now,
                "consent_ip": ip,
                "unsubscribed_at": None,
            }},
        )
    else:
        await db.subscribers.insert_one({
            "id": str(uuid.uuid4()),
            "email": email,
            "lang": payload.lang,
            "source": payload.source,
            "status": "subscribed",
            "consent_at": now,
            "consent_ip": ip,
            "unsubscribe_token": str(uuid.uuid4()),
            "unsubscribed_at": None,
            "created_at": now,
            "converted": False,  # bascule à True à la création de compte
        })
    fresh = await db.subscribers.find_one({"email": email}, {"_id": 0})
    asyncio.create_task(
        send_prelaunch_welcome(email, payload.lang or "en", (fresh or {}).get("unsubscribe_token", ""))
    )
    return {"ok": True, "already_subscribed": False}


@api.get("/newsletter/unsubscribe")
async def newsletter_unsubscribe(token: str):
    """Aucune authentification requise — un lien de désabonnement doit
    fonctionner en un clic, sans login, exigence CASL/LCAP."""
    res = await db.subscribers.update_one(
        {"unsubscribe_token": token, "status": "subscribed"},
        {"$set": {"status": "unsubscribed", "unsubscribed_at": datetime.now(timezone.utc).isoformat()}},
    )
    if not res.matched_count:
        # Idempotent : déjà désabonné ou token invalide → même réponse,
        # on ne révèle pas si l'email existe.
        return {"ok": True}
    return {"ok": True}


def _ensure_variant_ids(payload_doc: dict) -> dict:
    """Ensure every variant has an id. Sync legacy price_cad/stock from first variant if variants present."""
    variants = payload_doc.get("variants") or []
    out_variants = []
    for v in variants:
        v = dict(v)
        if not v.get("id"):
            v["id"] = str(uuid.uuid4())
        out_variants.append(v)
    payload_doc["variants"] = out_variants
    # Sync legacy fields for backward compat / cart fallback
    if out_variants:
        payload_doc["price_cad"] = float(out_variants[0].get("price", 0.0))
        payload_doc["stock"] = sum(int(v.get("stock", 0)) for v in out_variants)
    return payload_doc


@api.post("/admin/products")
async def admin_create_product(payload: ProductIn, _admin: dict = Depends(require_area("products", "manage"))):
    existing = await db.products.find_one({"slug": payload.slug})
    if existing:
        raise HTTPException(409, "Slug already exists")
    doc = payload.model_dump()
    doc = _ensure_variant_ids(doc)
    doc["id"] = str(uuid.uuid4())
    doc["created_at"] = datetime.now(timezone.utc).isoformat()
    await db.products.insert_one(doc)
    doc.pop("_id", None)
    return doc


@api.put("/admin/products/{product_id}")
async def admin_update_product(product_id: str, payload: ProductIn, _admin: dict = Depends(require_area("products", "manage"))):
    before = await db.products.find_one({"id": product_id}, {"_id": 0})
    update = payload.model_dump()
    update = _ensure_variant_ids(update)
    res = await db.products.update_one({"id": product_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(404, "Product not found")
    after = await db.products.find_one({"id": product_id}, {"_id": 0})

    # Back-in-stock: fire for any variant (or legacy product-level stock) that went from <=0 to >0.
    if before:
        before_variant_stock = {v.get("id"): v.get("stock", 0) for v in before.get("variants", [])}
        for v in after.get("variants", []):
            vid = v.get("id")
            if before_variant_stock.get(vid, 0) <= 0 < v.get("stock", 0):
                asyncio.create_task(_maybe_notify_restock(product_id, vid))
        if before.get("stock", 0) <= 0 < after.get("stock", 0):
            asyncio.create_task(_maybe_notify_restock(product_id, None))

    return after


@api.delete("/admin/products/{product_id}")
async def admin_delete_product(product_id: str, admin: dict = Depends(require_area("products", "manage"))):
    return await _soft_delete("products", product_id, admin)


@api.post("/admin/upload/coa")
async def admin_upload_coa(file: UploadFile = File(...), _admin: dict = Depends(require_area("products", "manage"))):
    """Uploads a Certificate of Analysis PDF and returns a URL to paste into a
    product's or variant's coa_url field. Storage is local disk under UPLOAD_DIR,
    served statically at /uploads/coa/<file>."""
    filename = file.filename or ""
    is_pdf = (file.content_type == "application/pdf") or filename.lower().endswith(".pdf")
    if not is_pdf:
        raise HTTPException(400, "Only PDF files are allowed")

    contents = await file.read()
    size_mb = len(contents) / (1024 * 1024)
    if size_mb > MAX_COA_UPLOAD_MB:
        raise HTTPException(400, f"File too large — max {MAX_COA_UPLOAD_MB:.0f} MB")
    if not contents.startswith(b"%PDF"):
        raise HTTPException(400, "File is not a valid PDF")

    safe_name = f"{uuid.uuid4().hex}.pdf"
    dest = COA_UPLOAD_DIR / safe_name
    with open(dest, "wb") as f:
        f.write(contents)

    rel_path = f"/api/uploads/coa/{safe_name}"
    url = f"{PUBLIC_BASE_URL}{rel_path}" if PUBLIC_BASE_URL else rel_path
    return {"url": url, "original_filename": filename, "size_bytes": len(contents)}


@api.post("/admin/upload/image")
async def admin_upload_image(file: UploadFile = File(...), _admin: dict = Depends(require_area("products", "manage"))):
    """Uploads a product image (PNG, JPEG, WebP, GIF) and returns a URL to use in 
    the image_url field. Storage is local disk under UPLOAD_DIR/images, served 
    statically at /uploads/images/<file>."""
    filename = file.filename or ""
    
    # Determine file extension from filename
    ext = None
    if "." in filename:
        ext = filename.rsplit(".", 1)[1].lower()
    
    # Validate by content type first
    content_type = file.content_type or ""
    if content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(400, "Only PNG, JPEG, WebP, and GIF images are allowed")
    
    contents = await file.read()
    size_mb = len(contents) / (1024 * 1024)
    if size_mb > MAX_IMAGE_UPLOAD_MB:
        raise HTTPException(400, f"File too large — max {MAX_IMAGE_UPLOAD_MB:.0f} MB")
    
    # Map content type to extension if not provided
    if not ext:
        ext_map = {
            "image/png": "png",
            "image/jpeg": "jpg",
            "image/webp": "webp",
            "image/gif": "gif",
        }
        ext = ext_map.get(content_type, "jpg")
    
    safe_name = f"{uuid.uuid4().hex}.{ext}"
    dest = IMAGE_UPLOAD_DIR / safe_name
    with open(dest, "wb") as f:
        f.write(contents)

    rel_path = f"/api/uploads/images/{safe_name}"
    return {"url": rel_path, "original_filename": filename, "size_bytes": len(contents)}


# ---------------------------------------------------------------------------
# Order / Checkout
# ---------------------------------------------------------------------------
def _resolve_variant(p: dict, variant_id: Optional[str]) -> dict:
    """Return the selected variant subdoc. Falls back to first variant or builds a synthetic one from legacy fields."""
    variants = p.get("variants") or []
    if variant_id:
        for v in variants:
            if v.get("id") == variant_id:
                return v
        raise HTTPException(400, f"Variant {variant_id} not found for product {p['slug']}")
    if variants:
        return variants[0]
    # Legacy synthetic variant
    return {
        "id": "_default",
        "name": f"{p.get('dosage_mg', 0)}mg" if p.get("dosage_mg") else "Default",
        "price": p.get("price_cad", 0.0),
        "stock": p.get("stock", 0),
        "sku": p["slug"].upper(),
        "preorder_enabled": p.get("preorder_allowed", False),
        "preorder_delay_message": "",
        "preorder_price": None,
        "preorder_note": "",
        "coa_status": "available" if p.get("coa_url") else "none",
        "badge_coa_available": bool(p.get("coa_url")),
        "badge_coa_pending": not bool(p.get("coa_url")),
        "badge_coming_soon": False,
        "coa_url": p.get("coa_url", "") or "",
        "sale_price": None,
    }


def _variant_effective_price(v: dict, is_preorder: bool) -> float:
    if is_preorder and v.get("preorder_price"):
        return float(v["preorder_price"])
    sale = v.get("sale_price")
    if sale and float(sale) < float(v.get("price", 0.0)):
        return float(sale)
    return float(v.get("price", 0.0))


# ---------------------------------------------------------------------------
# Réservation atomique du stock.
# Remplace le pattern check-then-act (lecture dans _build_order_totals,
# écriture historiquement ~200 lignes plus loin dans checkout). Le filtre
# $gte dans le update_one garantit qu'aucune décrémentation ne peut passer
# sous zéro, même avec N workers concurrents sur le dernier flacon.
# ---------------------------------------------------------------------------
async def _reserve_stock_atomic(line_items: list) -> list:
    """
    Décrémente le stock de chaque ligne non-preorder de façon atomique.
    Retourne la liste des lignes effectivement réservées (pour rollback).
    Lève HTTPException(400) et rollback si une ligne échoue.
    """
    reserved: list = []
    for it in line_items:
        if it.get("preorder"):
            continue
        qty = it["qty"]
        vid = it.get("variant_id")

        if vid in (None, "", "_default"):
            res = await db.products.update_one(
                {"id": it["product_id"], "stock": {"$gte": qty}},
                {"$inc": {"stock": -qty}},
            )
        else:
            res = await db.products.update_one(
                {"id": it["product_id"],
                 "variants": {"$elemMatch": {"id": vid, "stock": {"$gte": qty}}}},
                {"$inc": {"variants.$[v].stock": -qty}},
                array_filters=[{"v.id": vid}],
            )

        if res.modified_count != 1:
            await _release_stock_atomic(reserved)
            raise HTTPException(
                400,
                f"Insufficient stock for {it.get('name_en', it['product_id'])}"
                f"{(' (' + it['variant_name'] + ')') if it.get('variant_name') else ''}",
            )
        reserved.append(it)
    return reserved


async def _release_stock_atomic(line_items: list) -> None:
    """Rollback d'une réservation partielle. Ne notifie pas le restock
    (la marchandise n'a jamais réellement quitté le stock)."""
    for it in line_items:
        if it.get("preorder"):
            continue
        qty = it["qty"]
        vid = it.get("variant_id")
        if vid in (None, "", "_default"):
            await db.products.update_one({"id": it["product_id"]}, {"$inc": {"stock": qty}})
        else:
            await db.products.update_one(
                {"id": it["product_id"], "variants.id": vid},
                {"$inc": {"variants.$.stock": qty}},
            )


async def _build_order_totals(items: List[CartItem], coupon_code: Optional[str] = None):
    line_items = []
    subtotal = 0.0
    has_preorder = False

    # Un seul aller-retour Mongo au lieu de N (le panier moyen faisait N find_one
    # séquentiels, chacun un RTT réseau complet).
    _ids = list({it.product_id for it in items})
    _docs = await db.products.find({"id": {"$in": _ids}}, {"_id": 0}).to_list(len(_ids))
    _by_id = {d["id"]: d for d in _docs}

    for it in items:
        p = _by_id.get(it.product_id)
        if not p:
            raise HTTPException(400, f"Product {it.product_id} not found")
        if not p.get("active"):
            raise HTTPException(400, f"Product {p['name_en']} unavailable")

        v = _resolve_variant(p, it.variant_id)
        is_preorder = False
        # coa_status "pending" no longer blocks or forces preorder on its own
        # (variant stays purchasable with a warning). Only badge_coming_soon
        # (product not yet launched) drives the "coming" preorder path here.
        coa_coming = bool(v.get("badge_coming_soon"))
        if v.get("preorder_enabled") and (coa_coming or v.get("stock", 0) < it.qty):
            is_preorder = True
            has_preorder = True
        elif v.get("stock", 0) < it.qty:
            if p.get("preorder_allowed"):
                is_preorder = True
                has_preorder = True
            else:
                raise HTTPException(400, f"Insufficient stock for {p['name_en']} ({v.get('name','')})")

        unit_price = _variant_effective_price(v, is_preorder)
        line_total = round(unit_price * it.qty, 2)
        line_items.append({
            "product_id": p["id"],
            "variant_id": v.get("id"),
            "variant_name": v.get("name", ""),
            "slug": p["slug"],
            "sku": v.get("sku", p["slug"].upper()),
            "name_en": p["name_en"],
            "name_fr": p["name_fr"],
            "price_cad": unit_price,
            "qty": it.qty,
            "line_total": line_total,
            "image_url": p.get("image_url", ""),
            "preorder": is_preorder,
            # Poids figé à l'achat : l'étiquette doit refléter ce qui a été vendu,
            # même si la fiche produit change ensuite. Les commandes antérieures
            # sans ce champ retombent sur 50 g/unité dans _order_weight_kg().
            "weight_grams": float(v.get("weight_grams") or 50.0),
        })
        subtotal += line_total
    subtotal = round(subtotal, 2)

    # Apply coupon (unchanged logic)
    discount = 0.0
    applied_coupon = None
    if coupon_code:
        coupon = await db.coupons.find_one({"code": coupon_code.upper().strip()}, {"_id": 0})
        if not coupon or not coupon.get("active"):
            raise HTTPException(400, "Invalid coupon code")
        if coupon.get("expires_at"):
            try:
                if datetime.fromisoformat(coupon["expires_at"].replace("Z", "+00:00")) < datetime.now(timezone.utc):
                    raise HTTPException(400, "Coupon expired")
            except ValueError:
                pass
        if coupon.get("usage_limit") and coupon.get("used_count", 0) >= coupon["usage_limit"]:
            raise HTTPException(400, "Coupon usage limit reached")
        if subtotal < coupon.get("min_subtotal", 0):
            raise HTTPException(400, f"Minimum subtotal of ${coupon['min_subtotal']:.2f} required for this coupon")
        if coupon["discount_type"] == "percent":
            discount = round(subtotal * (coupon["value"] / 100.0), 2)
        else:
            discount = round(min(coupon["value"], subtotal), 2)
        applied_coupon = {"code": coupon["code"], "discount_type": coupon["discount_type"], "value": coupon["value"], "discount_amount": discount}

    tax_rate = 0.0
    shipping = 0.0 if (subtotal - discount) >= FREE_SHIPPING_THRESHOLD_CAD else SHIPPING_FLAT_CAD
    tax = 0.0
    total = round(max(0, subtotal - discount) + shipping, 2)
    return line_items, subtotal, tax_rate, tax, shipping, total, discount, applied_coupon, has_preorder


async def _nowpayments_create(order_id: str, total_cad: float, pay_currency: str):
    """Create a NOWPayments invoice (embeddable widget, exact amount). Falls back to mock if no API key."""
    if not NOWPAYMENTS_API_KEY:
        return {
            "mock": True,
            "payment_id": f"mock-{order_id[:8]}",
            "pay_address": "TEST_ADDRESS_CONFIGURE_NOWPAYMENTS_API_KEY",
            "pay_amount": round(total_cad / 60000, 8) if pay_currency == "btc" else round(total_cad / 3500, 6),
            "pay_currency": pay_currency,
            "order_id": order_id,
            "payment_status": "waiting",
        }
    body = {
        "price_amount": total_cad,
        "price_currency": "cad",
        "order_id": order_id,
        "order_description": f"FIRONOVA order {order_id}",
    }
    if PUBLIC_BASE_URL:
        body["ipn_callback_url"] = f"{PUBLIC_BASE_URL}/api/webhook/nowpayments"
        body["success_url"] = f"{PUBLIC_BASE_URL}/order/{order_id}"
        body["cancel_url"] = f"{PUBLIC_BASE_URL}/order/{order_id}"
    try:
        async with httpx.AsyncClient(timeout=15) as cx:
            r = await cx.post(
                f"{NOWPAYMENTS_BASE_URL}/invoice",
                headers={"x-api-key": NOWPAYMENTS_API_KEY, "Content-Type": "application/json"},
                json=body,
            )
            r.raise_for_status()
            inv = r.json()
            return {
                "invoice_id": inv.get("id"),
                "invoice_url": inv.get("invoice_url"),
                "order_id": order_id,
                "price_amount": total_cad,
                "price_currency": "cad",
                "payment_status": "waiting",
            }
    except Exception as e:
        logging.error("NOWPayments error: %s", e)
        raise HTTPException(502, "Crypto payment provider unavailable")


# ---------------------------------------------------------------------------
# Canada Post (Postes Canada) — live rating & tracking.
# Gracefully returns nothing when not configured, so callers fall back to the
# existing flat-rate shipping_zones/shipping_methods system (same pattern used
# for NOWPayments' mock mode above).
# ---------------------------------------------------------------------------
_CP_RATE_NS = {"cp": "http://www.canadapost.ca/ws/ship/rate-v4"}
_CP_TRACK_NS = {"cp": "http://www.canadapost.ca/ws/track"}
_CP_SHIP_NS = {"cp": "http://www.canadapost.ca/ws/ncshipment-v4"}
_CP_CSHIP_NS = {"cp": "http://www.canadapost.ca/ws/shipment-v8"}
_CP_MANIFEST_NS = {"cp": "http://www.canadapost.ca/ws/manifest-v8"}

_CP_OAUTH_TOKEN: str = ""
_CP_OAUTH_EXPIRES_AT: Optional[datetime] = None


def _cp_use_openapi() -> bool:
    mode = CANADA_POST_API_MODE
    if mode == "openapi":
        return True
    if mode == "legacy":
        return False
    return bool(CANADA_POST_OAUTH_CLIENT_ID and CANADA_POST_OAUTH_CLIENT_SECRET)


def _cp_path_customers() -> tuple[str, str]:
    mailed_by = (CANADA_POST_MAILED_BY or CANADA_POST_CUSTOMER_NUMBER or "").strip()
    mobo = (CANADA_POST_MOBO or CANADA_POST_CUSTOMER_NUMBER or "").strip()
    return mailed_by, mobo


def _cp_openapi_headers(token: str, accept: str = "application/json") -> dict:
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": accept,
        "Accept-Language": "en-CA",
    }
    if CANADA_POST_PLATFORM_ID:
        headers["platform-id"] = CANADA_POST_PLATFORM_ID
    return headers


def _cp_safe_json(response: httpx.Response) -> dict:
    try:
        data = response.json()
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _cp_error_detail(response: httpx.Response) -> str:
    payload = _cp_safe_json(response)
    title = str(payload.get("title") or "").strip()
    detail = str(payload.get("detail") or "").strip()
    errors = payload.get("errors") if isinstance(payload.get("errors"), list) else []
    first = errors[0] if errors else {}
    code = str(first.get("errorCode") or "").strip()
    msg = str(first.get("message") or first.get("description") or "").strip()
    parts = [p for p in [title, detail, f"{code} {msg}".strip()] if p]
    if parts:
        return " | ".join(parts)
    return (response.text or "").strip()[:500]


async def _cp_get_oauth_token(force_refresh: bool = False) -> str:
    global _CP_OAUTH_TOKEN, _CP_OAUTH_EXPIRES_AT
    now = datetime.now(timezone.utc)
    if (not force_refresh and _CP_OAUTH_TOKEN and _CP_OAUTH_EXPIRES_AT
            and _CP_OAUTH_EXPIRES_AT > now + timedelta(seconds=30)):
        return _CP_OAUTH_TOKEN

    data = {"grant_type": "client_credentials", "scope": "merchant"}
    try:
        async with httpx.AsyncClient(timeout=20) as cx:
            r = await cx.post(
                CANADA_POST_OAUTH_TOKEN_URL,
                data=data,
                auth=(CANADA_POST_OAUTH_CLIENT_ID, CANADA_POST_OAUTH_CLIENT_SECRET),
                headers={"Accept": "application/json"},
            )
    except Exception as ex:
        logging.error("Canada Post OAuth token request failed: %s", ex)
        raise HTTPException(502, "Canada Post OAuth token endpoint unreachable")

    if r.status_code >= 400:
        logging.error("Canada Post OAuth token %s: %s", r.status_code, r.text[:800])
        raise HTTPException(502, f"Canada Post OAuth rejected credentials ({r.status_code})")

    payload = _cp_safe_json(r)
    token = str(payload.get("access_token") or "")
    expires_in = int(payload.get("expires_in") or 300)
    if not token:
        raise HTTPException(502, "Canada Post OAuth returned no access token")

    _CP_OAUTH_TOKEN = token
    _CP_OAUTH_EXPIRES_AT = now + timedelta(seconds=max(30, expires_in))
    return _CP_OAUTH_TOKEN


async def _cp_openapi_call(method: str, url_or_path: str, *, json_body: Optional[dict] = None,
                           accept: str = "application/json") -> httpx.Response:
    token = await _cp_get_oauth_token()
    url = url_or_path if url_or_path.startswith("http") else f"{CANADA_POST_OPENAPI_BASE_URL}{url_or_path}"
    headers = _cp_openapi_headers(token, accept=accept)
    if json_body is not None:
        headers["Content-Type"] = "application/json"

    # follow_redirects=True est INDISPENSABLE : Canada Post renvoie l'artifact
    # (le PDF de l'étiquette) via une redirection 302 vers l'URL réelle. Sans
    # suivre la redirection, on écrit la réponse 302 vide -> étiquette blanche.
    async with httpx.AsyncClient(timeout=45, follow_redirects=True) as cx:
        r = await cx.request(method, url, json=json_body, headers=headers)
        if r.status_code == 401:
            token = await _cp_get_oauth_token(force_refresh=True)
            headers = _cp_openapi_headers(token, accept=accept)
            if json_body is not None:
                headers["Content-Type"] = "application/json"
            r = await cx.request(method, url, json=json_body, headers=headers)
    return r


async def _estimate_parcel_weight_kg(items: Optional[List["CartItem"]]) -> float:
    if not items:
        return 0.5
    total_g = 0.0
    for it in items:
        p = await db.products.find_one({"id": it.product_id}, {"_id": 0})
        if not p:
            continue
        v = _resolve_variant(p, it.variant_id)
        total_g += float(v.get("weight_grams") or 50.0) * it.qty
    return max(0.1, round(total_g / 1000.0, 3))


async def _canada_post_get_rates(destination_postal_code: str, destination_country: str, weight_kg: float) -> list:
    """Calls Canada Post's Rating API (rate-v4). Returns [] if not configured or on any error —
    callers must fall back to the flat-rate system in that case."""
    if not (CANADA_POST_API_KEY and CANADA_POST_CUSTOMER_NUMBER and CANADA_POST_ORIGIN_POSTAL_CODE):
        return []

    origin_pc = CANADA_POST_ORIGIN_POSTAL_CODE.replace(" ", "").upper()
    dest_pc = (destination_postal_code or "").replace(" ", "").upper()
    weight_kg = max(0.1, round(weight_kg, 3))

    if destination_country == "CA":
        destination_xml = f"<domestic><postal-code>{dest_pc}</postal-code></domestic>"
    elif destination_country == "US":
        destination_xml = f"<united-states><zip-code>{dest_pc}</zip-code></united-states>"
    else:
        destination_xml = f"<international><country-code>{destination_country}</country-code></international>"

    contract_xml = f"<contract-id>{CANADA_POST_CONTRACT_ID}</contract-id>" if CANADA_POST_CONTRACT_ID else ""
    body = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<mailing-scenario xmlns="http://www.canadapost.ca/ws/ship/rate-v4">'
        f"<customer-number>{CANADA_POST_CUSTOMER_NUMBER}</customer-number>"
        f"{contract_xml}"
        f"<parcel-characteristics><weight>{weight_kg}</weight></parcel-characteristics>"
        f"<origin-postal-code>{origin_pc}</origin-postal-code>"
        f"<destination>{destination_xml}</destination>"
        "</mailing-scenario>"
    )
    try:
        async with httpx.AsyncClient(timeout=15) as cx:
            r = await cx.post(
                f"{CANADA_POST_BASE_URL}/rs/ship/price",
                content=body.encode("utf-8"),
                auth=_cp_auth_tuple(),
                headers={
                    "Accept": "application/vnd.cpc.ship.rate-v4+xml",
                    "Content-Type": "application/vnd.cpc.ship.rate-v4+xml",
                },
            )
            if r.status_code >= 400:
                logging.error("Canada Post rating error %s: %s", r.status_code, r.text[:500])
                return []
            root = ET.fromstring(r.text)
            quotes = []
            for pq in root.findall("cp:price-quote", _CP_RATE_NS):
                due_el = pq.find("cp:price-details/cp:due", _CP_RATE_NS)
                quotes.append({
                    "carrier": "Canada Post",
                    "service_code": pq.findtext("cp:service-code", default="", namespaces=_CP_RATE_NS),
                    "service_name": pq.findtext("cp:service-name", default="", namespaces=_CP_RATE_NS),
                    "cost_cad": float(due_el.text) if due_el is not None and due_el.text else None,
                    "eta_days": pq.findtext(
                        "cp:service-standard/cp:expected-transit-time", default="", namespaces=_CP_RATE_NS
                    ),
                })
            return [q for q in quotes if q["cost_cad"] is not None]
    except Exception as e:
        logging.error("Canada Post rating request failed: %s", e)
        return []


async def _canada_post_track(pin: str) -> Optional[dict]:
    """Live tracking lookup by PIN. Returns None if not configured or on any error."""
    if not CANADA_POST_API_KEY:
        return None
    try:
        async with httpx.AsyncClient(timeout=15) as cx:
            r = await cx.get(
                f"{CANADA_POST_BASE_URL}/vis/track/pin/{pin}/detail",
                auth=_cp_auth_tuple(),
                headers={"Accept": "application/vnd.cpc.track+xml"},
            )
            if r.status_code >= 400:
                logging.error("Canada Post tracking error %s: %s", r.status_code, r.text[:400])
                return None
            root = ET.fromstring(r.text)
            events = []
            for ev in root.findall(".//cp:occurrence", _CP_TRACK_NS):
                events.append({
                    "date": ev.findtext("cp:event-date", default="", namespaces=_CP_TRACK_NS),
                    "time": ev.findtext("cp:event-time", default="", namespaces=_CP_TRACK_NS),
                    "description": ev.findtext("cp:event-description", default="", namespaces=_CP_TRACK_NS),
                    "location": ev.findtext("cp:event-site", default="", namespaces=_CP_TRACK_NS),
                })
            summary = root.findtext(".//cp:significant-status/cp:description", default="", namespaces=_CP_TRACK_NS)
            return {"pin": pin, "summary": summary, "events": events}
    except Exception as e:
        logging.error("Canada Post tracking request failed: %s", e)
        return None


def _cp_tracking_indicates_delivered(track_data: Optional[dict]) -> tuple[bool, str]:
    """Heuristique prudente pour détecter une livraison confirmée via repérage CP.
    Retourne (is_delivered, evidence_text)."""
    if not isinstance(track_data, dict):
        return False, ""
    texts: list[str] = []
    summary = str(track_data.get("summary") or "").strip()
    if summary:
        texts.append(summary)
    events = track_data.get("events") if isinstance(track_data.get("events"), list) else []
    for ev in events:
        if not isinstance(ev, dict):
            continue
        desc = str(ev.get("description") or "").strip()
        if desc:
            texts.append(desc)

    # Mots-clés de livraison finale (évite "out for delivery" / "en cours de livraison").
    delivered_re = re.compile(
        r"\b(delivered|item delivered|successfully delivered|livr[ée]e?|colis livr[ée]|livraison effectu[ée])\b",
        re.IGNORECASE,
    )
    for txt in texts:
        if delivered_re.search(txt):
            return True, txt
    return False, ""


def _sandbox_fallback_ready(shipped_at_iso: str) -> bool:
    """En sandbox uniquement: autorise un passage auto à delivered après délai,
    si le tracking CP est indisponible."""
    if not (CANADA_POST_ENVIRONMENT == "dev" and CANADA_POST_SANDBOX_DELIVERY_FALLBACK):
        return False
    if not shipped_at_iso:
        return False
    try:
        dt = datetime.fromisoformat(shipped_at_iso.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        age = datetime.now(timezone.utc) - dt.astimezone(timezone.utc)
        return age >= timedelta(hours=max(1, CANADA_POST_SANDBOX_DELIVER_AFTER_HOURS))
    except Exception:
        return False


def is_canada_post_configured() -> bool:
    """Vrai seulement si les trois éléments indispensables sont présents.
    Sinon TOUT retombe proprement sur le tarif fixe / le suivi manuel."""
    if _cp_use_openapi():
        mailed_by, mobo = _cp_path_customers()
        return bool(
            mailed_by
            and mobo
            and CANADA_POST_ORIGIN_POSTAL_CODE
            and CANADA_POST_OAUTH_CLIENT_ID
            and CANADA_POST_OAUTH_CLIENT_SECRET
        )
    return bool(CANADA_POST_API_KEY and CANADA_POST_CUSTOMER_NUMBER and CANADA_POST_ORIGIN_POSTAL_CODE)


def _cp_auth_tuple() -> tuple[str, str]:
    """Supporte "user:password" (recommandé CP) et token seul (legacy)."""
    raw = (CANADA_POST_API_KEY or "").strip()
    if ":" in raw:
        user, pwd = raw.split(":", 1)
        return user.strip(), pwd.strip()
    return raw, ""


def _cp_xml_escape(v: str) -> str:
    """Une apostrophe dans un nom de rue casse le XML — et un chevron l'injecte."""
    return (str(v or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;").replace("'", "&apos;"))


def _cp_intended_method() -> str:
    if CANADA_POST_INTENDED_METHOD:
        return CANADA_POST_INTENDED_METHOD
    return "Account" if CANADA_POST_CONTRACT_ID.strip() else "CreditCard"


async def _canada_post_create_shipment_openapi(order: dict, service_code: str, weight_kg: float) -> dict:
    ship = order.get("shipping_address") or {}
    # Contenant configuré (tare + dimensions) — améliore la justesse du tarif.
    box = await _select_box_for_order(order)
    box_dims = None
    if box:
        weight_kg = round(weight_kg + float(box.get("tare_grams") or 0) / 1000.0, 3)
        box_dims = {
            "length": round(float(box["length_cm"]), 1),
            "width": round(float(box["width_cm"]), 1),
            "height": round(float(box["height_cm"]), 1),
        }
    dest_pc = str(ship.get("postal_code", "")).replace(" ", "").upper()
    origin_pc = CANADA_POST_ORIGIN_POSTAL_CODE.replace(" ", "").upper()
    mailed_by, mobo = _cp_path_customers()
    group_id = f"FN-{datetime.now(timezone.utc).strftime('%Y%m%d')}"

    settlement = {
        "paidByCustomer": mobo,
        "intendedMethodOfPayment": _cp_intended_method(),
    }
    contract = CANADA_POST_CONTRACT_ID.strip()
    if contract:
        settlement["contractId"] = contract

    payload: dict[str, Any] = {
        "groupId": group_id,
        "requestedShippingPoint": origin_pc,
        "cpcPickupIndicator": True,
        "deliverySpec": {
            "serviceCode": service_code,
            "sender": {
                "name": CANADA_POST_SENDER_NAME,
                "company": CANADA_POST_SENDER_NAME,
                "contactPhone": CANADA_POST_SENDER_PHONE,
                "addressDetails": {
                    "addressLine1": CANADA_POST_SENDER_ADDRESS,
                    "city": CANADA_POST_SENDER_CITY,
                    "provState": CANADA_POST_SENDER_PROVINCE,
                    "countryCode": "CA",
                    "postalZipCode": origin_pc,
                },
            },
            "destination": {
                "name": str(ship.get("full_name") or "").strip()[:44],
                "addressDetails": {
                    "addressLine1": ship.get("address1") or "",
                    "addressLine2": ship.get("address2") or "",
                    "city": ship.get("city") or "",
                    "provState": ship.get("province") or "",
                    "countryCode": ship.get("country") or "CA",
                    "postalZipCode": dest_pc,
                },
            },
            "parcelCharacteristics": {
                "weight": max(0.1, round(weight_kg, 3)),
                **({"dimensions": box_dims} if box_dims else {}),
            },
            "printPreferences": {
                "outputFormat": os.environ.get("CANADA_POST_LABEL_FORMAT", "4x6"),
                "encoding": "PDF",
            },
            "preferences": {
                "showPackingInstructions": False,
                "showPostageRate": False,
                "showInsuredValue": False,
            },
            "settlementInfo": settlement,
        },
    }

    r = await _cp_openapi_call("POST", f"/{mailed_by}/{mobo}/shipments", json_body=payload)
    if r.status_code >= 400:
        detail = _cp_error_detail(r)
        logging.error("Canada Post OpenAPI create-shipment %s: %s", r.status_code, detail)
        raise HTTPException(502, f"Canada Post rejected the shipment ({r.status_code})")

    data = _cp_safe_json(r)
    links = data.get("links") if isinstance(data.get("links"), list) else []
    label_href = ""
    for link in links:
        if isinstance(link, dict) and link.get("rel") == "label" and link.get("href"):
            label_href = str(link.get("href"))
            break
    return {
        "pin": str(data.get("trackingPin") or ""),
        "label_href": label_href,
        "shipment_id": str(data.get("shipmentId") or ""),
        "group_id": group_id,
    }


async def _canada_post_get_artifact_openapi(href: str, order_id: str) -> Optional[str]:
    if not href:
        return None
    try:
        r = await _cp_openapi_call("GET", href, accept="application/pdf")
    except HTTPException:
        return None
    except Exception as ex:
        logging.error("Canada Post OpenAPI get-artifact failed: %s", ex)
        return None
    if r.status_code >= 400:
        logging.error("Canada Post OpenAPI get-artifact %s: %s", r.status_code, _cp_error_detail(r))
        return None
    fname = f"{order_id}-{uuid.uuid4().hex[:8]}.pdf"
    (LABEL_UPLOAD_DIR / fname).write_bytes(r.content)
    return f"/uploads/labels/{fname}"


async def _canada_post_get_manifest_artifact_openapi(href: str, date_str: str) -> Optional[str]:
    """Télécharge le PDF du manifeste via le flux en 2 étapes du devportal CP:
    1) GET {manifest_href} Accept:application/json  → obtient le lien "artifact"
    2) GET {artifact_href} Accept:application/pdf   → télécharge le PDF réel.
    """
    if not href:
        return None
    try:
        # Étape 1: récupérer le JSON du manifeste pour trouver le lien artifact
        r_json = await _cp_openapi_call("GET", href, accept="application/json")
        if r_json.status_code >= 400:
            logging.error("CP manifest-artifact step1 %s: %s", r_json.status_code, _cp_error_detail(r_json))
            return None
        manifest_data = _cp_safe_json(r_json)
        links = manifest_data.get("links") or []
        artifact_href = next(
            (l.get("href") for l in links
             if isinstance(l, dict) and l.get("rel") == "artifact" and l.get("href")),
            None,
        )
        if not artifact_href:
            logging.error("CP manifest-artifact: no artifact link found in manifest %s", href)
            return None

        # Étape 2: télécharger le PDF via le lien artifact
        r_pdf = await _cp_openapi_call("GET", artifact_href, accept="application/pdf")
        if r_pdf.status_code >= 400:
            logging.error("CP manifest-artifact step2 %s: %s", r_pdf.status_code, _cp_error_detail(r_pdf))
            return None
        if r_pdf.content[:4] != b"%PDF":
            logging.error("CP manifest-artifact: response is not a PDF (%d bytes)", len(r_pdf.content))
            return None
        fname = f"manifest-{date_str}-{uuid.uuid4().hex[:8]}.pdf"
        (LABEL_UPLOAD_DIR / fname).write_bytes(r_pdf.content)
        logging.info("CP manifest PDF saved: %s", fname)
        return f"/uploads/labels/{fname}"
    except HTTPException:
        return None
    except Exception as ex:
        logging.error("Canada Post OpenAPI get-manifest-artifact failed: %s", ex)
        return None


async def _canada_post_shipment_price(shipment_id: str, preferred_service_code: Optional[str] = None) -> Optional[dict]:
    """Coût réel facturé par Postes Canada pour un envoi (Get Shipment Price).
    C'est ce qui permet de comparer ce qu'on PAIE à ce qu'on FACTURE au client."""
    if not shipment_id or not _cp_use_openapi():
        return None
    mailed_by, mobo = _cp_path_customers()
    try:
        r = await _cp_openapi_call("GET", f"/{mailed_by}/{mobo}/shipments/{shipment_id}/price")
    except Exception as ex:
        logging.error("Canada Post get-price failed (%s): %s", shipment_id, ex)
        return None
    if r.status_code >= 400:
        logging.error("Canada Post get-price %s: %s", r.status_code, _cp_error_detail(r))
        return None
    # L'endpoint /price retourne une LISTE de devis, pas un objet unique.
    # _cp_safe_json() ne gère que les dicts; on parse directement ici.
    try:
        raw = r.json()
    except Exception:
        logging.error("Canada Post get-price: JSON parse failed for %s", shipment_id)
        return None
    quotes: list[dict] = []
    if isinstance(raw, list):
        quotes = [q for q in raw if isinstance(q, dict)]
    elif isinstance(raw, dict):
        quotes = [raw]
    if not quotes:
        logging.error("Canada Post get-price: unexpected payload for %s: %s", shipment_id, str(raw)[:200])
        return None

    selected = None
    preferred = str(preferred_service_code or "").strip().upper()
    if preferred:
        selected = next((q for q in quotes if str(q.get("serviceCode") or "").upper() == preferred), None)
    if selected is None:
        selected = quotes[0]

    std = selected.get("serviceStandard") or {}
    return {
        "service_code": selected.get("serviceCode"),
        "base_amount": selected.get("baseAmount"),
        "pre_tax_amount": selected.get("preTaxAmount"),
        "gst": selected.get("gstAmount"),
        "pst": selected.get("pstAmount"),
        "hst": selected.get("hstAmount"),
        "due_amount": selected.get("dueAmount"),
        "rated_weight_kg": selected.get("ratedWeight"),
        "expected_delivery": std.get("expectedDeliveryDate"),
        "expected_transit_days": std.get("expectedTransitTime"),
        "fetched_at": datetime.now(timezone.utc).isoformat(),
    }


async def _canada_post_estimate_openapi(order: dict, service_code: str, weight_kg: float) -> Optional[dict]:
    """Estimation du coût via OpenAPI sans transmission:
    on crée un envoi temporaire, on lit son prix, puis on l'annule (void)."""
    if not (_cp_use_openapi() and is_canada_post_configured()):
        return None
    shipment_id = ""
    try:
        # Réutilise le payload officiel déjà accepté en prod par la création
        # d'étiquette normale pour éviter les erreurs de schéma.
        created = await _canada_post_create_shipment_openapi(order, service_code, weight_kg)
        shipment_id = str(created.get("shipment_id") or "")
        if not shipment_id:
            return None

        price = await _canada_post_shipment_price(shipment_id, preferred_service_code=service_code)

        if not price:
            return None

        due = price.get("due_amount")
        eta = price.get("expected_transit_days")
        svc = price.get("service_code")

        return {
            "service_code": svc,
            "cost_cad": float(due) if due is not None else None,
            "eta_days": eta,
        }
    except Exception as ex:
        logging.error("Canada Post OpenAPI estimate failed: %s", ex)
        return None

    finally:
        if shipment_id:
            await _canada_post_void_openapi(shipment_id)


async def _canada_post_manifest_details(manifest_href: str) -> Optional[dict]:
    """Détails de coût d'un manifeste (Get Manifest Details) : total réellement
    facturé pour la journée, pour le rapprochement comptable."""
    if not manifest_href:
        return None
    href = manifest_href.rstrip("/")
    if not href.endswith("/details"):
        href = f"{href}/details"
    try:
        r = await _cp_openapi_call("GET", href)
    except Exception as ex:
        logging.error("Canada Post manifest-details failed: %s", ex)
        return None
    if r.status_code >= 400:
        logging.error("Canada Post manifest-details %s: %s", r.status_code, _cp_error_detail(r))
        return None
    d = _cp_safe_json(r) or {}
    p = d.get("manifestPricingInfo") or {}
    return {
        "po_number": d.get("poNumber"),
        "manifest_date": d.get("manifestDate"),
        "manifest_time": d.get("manifestTime"),
        "base_cost": p.get("baseCost"),
        "options_and_surcharges": p.get("optionsAndSurcharges"),
        "gst": p.get("gst"),
        "pst": p.get("pst"),
        "hst": p.get("hst"),
        "total_due": p.get("totalDueCpc"),
    }


async def _canada_post_transmit_openapi(group_id: str) -> list:
    mailed_by, mobo = _cp_path_customers()
    origin_pc = CANADA_POST_ORIGIN_POSTAL_CODE.replace(" ", "").upper()
    payload = {
        "groupIds": [group_id],
        "requestedShippingPoint": origin_pc,
        "cpcPickupIndicator": True,
        "detailedManifests": True,
        "methodOfPayment": _cp_intended_method(),
        "manifestAddress": {
            "manifestCompany": CANADA_POST_SENDER_NAME,
            "manifestName": CANADA_POST_SENDER_NAME,
            "phoneNumber": CANADA_POST_SENDER_PHONE,
            "addressDetails": {
                "addressLine1": CANADA_POST_SENDER_ADDRESS,
                "city": CANADA_POST_SENDER_CITY,
                "provState": CANADA_POST_SENDER_PROVINCE,
                "countryCode": "CA",
                "postalZipCode": origin_pc,
            },
        },
    }
    r = await _cp_openapi_call("POST", f"/{mailed_by}/{mobo}/manifests", json_body=payload)
    if r.status_code >= 400:
        detail = _cp_error_detail(r)
        logging.error("Canada Post OpenAPI transmit %s: %s", r.status_code, detail)
        raise HTTPException(502, f"Canada Post rejected the transmission ({r.status_code})")

    data = r.json() if r.headers.get("content-type", "").startswith("application/json") else []
    hrefs = []
    if isinstance(data, list):
        for link in data:
            if isinstance(link, dict) and link.get("rel") == "manifest" and link.get("href"):
                hrefs.append(str(link.get("href")))
    return hrefs


async def _canada_post_void_openapi(shipment_id: str) -> bool:
    if not shipment_id:
        return False
    mailed_by, mobo = _cp_path_customers()
    try:
        r = await _cp_openapi_call("DELETE", f"/{mailed_by}/{mobo}/shipments/{shipment_id}")
        return r.status_code < 400
    except Exception as ex:
        logging.error("Canada Post OpenAPI void failed: %s", ex)
        return False


async def _canada_post_create_shipment(order: dict, service_code: str, weight_kg: float) -> dict:
    """Create Shipment (non-contractuel par défaut) → tracking PIN + lien étiquette.

    Retourne {"pin", "label_href", "shipment_id", "group_id"} ou lève HTTPException.
    """
    if not is_canada_post_configured():
        raise HTTPException(503, "Canada Post is not configured")
    if _cp_use_openapi():
        return await _canada_post_create_shipment_openapi(order, service_code, weight_kg)

    cust = CANADA_POST_CUSTOMER_NUMBER
    contract = CANADA_POST_CONTRACT_ID.strip()
    # Le groupe sert au manifeste : un groupe par jour d'expédition.
    group_id = f"FN-{datetime.now(timezone.utc).strftime('%Y%m%d')}"

    ship = order.get("shipping_address") or {}
    weight_kg = max(0.1, round(weight_kg, 3))
    e = _cp_xml_escape

    dest_pc = str(ship.get("postal_code", "")).replace(" ", "").upper()
    if contract:
        ns = "http://www.canadapost.ca/ws/shipment-v8"
        path = f"/rs/{cust}/{cust}/shipment"
        ctype = "application/vnd.cpc.shipment-v8+xml"
        root_tag = "shipment"
        extra = f"<contract-id>{e(contract)}</contract-id>"
    else:
        ns = "http://www.canadapost.ca/ws/ncshipment-v4"
        path = f"/rs/{cust}/ncshipment"
        ctype = "application/vnd.cpc.ncshipment-v4+xml"
        root_tag = "non-contract-shipment"
        extra = ""

    body = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        f'<{root_tag} xmlns="{ns}">'
        f"<requested-shipping-point>{e(CANADA_POST_ORIGIN_POSTAL_CODE.replace(' ', '').upper())}</requested-shipping-point>"
        f"<group-id>{e(group_id)}</group-id>"
        f"{extra}"
        "<delivery-spec>"
        f"<service-code>{e(service_code)}</service-code>"
        "<sender>"
        f"<name>{e(CANADA_POST_SENDER_NAME)}</name>"
        f"<company>{e(CANADA_POST_SENDER_NAME)}</company>"
        f"<contact-phone>{e(CANADA_POST_SENDER_PHONE)}</contact-phone>"
        "<address-details>"
        f"<address-line-1>{e(CANADA_POST_SENDER_ADDRESS)}</address-line-1>"
        f"<city>{e(CANADA_POST_SENDER_CITY)}</city>"
        f"<prov-state>{e(CANADA_POST_SENDER_PROVINCE)}</prov-state>"
        f"<postal-zip-code>{e(CANADA_POST_ORIGIN_POSTAL_CODE.replace(' ', '').upper())}</postal-zip-code>"
        "</address-details>"
        "</sender>"
        "<destination>"
        f"<name>{e(ship.get('full_name'))}</name>"
        "<address-details>"
        f"<address-line-1>{e(ship.get('address1'))}</address-line-1>"
        f"<address-line-2>{e(ship.get('address2'))}</address-line-2>"
        f"<city>{e(ship.get('city'))}</city>"
        f"<prov-state>{e(ship.get('province'))}</prov-state>"
        f"<country-code>{e(ship.get('country') or 'CA')}</country-code>"
        f"<postal-zip-code>{e(dest_pc)}</postal-zip-code>"
        "</address-details>"
        "</destination>"
        # Contenu volontairement non décrit : emballage neutre.
        f"<parcel-characteristics><weight>{weight_kg}</weight></parcel-characteristics>"
        "<preferences><show-packing-instructions>false</show-packing-instructions></preferences>"
        "</delivery-spec>"
        f"</{root_tag}>"
    )

    try:
        async with httpx.AsyncClient(timeout=30) as cx:
            r = await cx.post(
                f"{CANADA_POST_BASE_URL}{path}",
                content=body.encode("utf-8"),
                auth=_cp_auth_tuple(),
                headers={"Accept": ctype, "Content-Type": ctype, "Accept-language": "en-CA"},
            )
    except Exception as ex:
        logging.error("Canada Post create-shipment request failed: %s", ex)
        raise HTTPException(502, "Canada Post unreachable")

    if r.status_code >= 400:
        logging.error("Canada Post create-shipment %s: %s", r.status_code, r.text[:800])
        raise HTTPException(502, f"Canada Post rejected the shipment ({r.status_code})")

    root = ET.fromstring(r.text)

    def _find(tag: str) -> str:
        for ns_map in (_CP_SHIP_NS, _CP_CSHIP_NS):
            v = root.findtext(f"cp:{tag}", default="", namespaces=ns_map)
            if v:
                return v
        # Repli sans namespace
        el = root.find(f".//{{*}}{tag}")
        return el.text if el is not None and el.text else ""

    pin = _find("tracking-pin")
    shipment_id = _find("shipment-id") or _find("non-contract-shipment-id")

    label_href = ""
    for link in root.findall(".//{*}link"):
        if link.get("rel") == "label":
            label_href = link.get("href", "")
            break

    if not pin:
        logging.error("Canada Post create-shipment: no tracking-pin in response: %s", r.text[:600])
        raise HTTPException(502, "Canada Post returned no tracking number")

    return {"pin": pin, "label_href": label_href, "shipment_id": shipment_id, "group_id": group_id}


async def _canada_post_get_artifact(href: str, order_id: str) -> Optional[str]:
    """Get Artifact → télécharge le PDF de l'étiquette, le stocke, renvoie son URL."""
    if not href:
        return None
    if _cp_use_openapi():
        return await _canada_post_get_artifact_openapi(href, order_id)
    try:
        async with httpx.AsyncClient(timeout=30) as cx:
            r = await cx.get(href, auth=_cp_auth_tuple(), headers={"Accept": "application/pdf"})
            if r.status_code >= 400:
                logging.error("Canada Post get-artifact %s: %s", r.status_code, r.text[:300])
                return None
            fname = f"{order_id}-{uuid.uuid4().hex[:8]}.pdf"
            (LABEL_UPLOAD_DIR / fname).write_bytes(r.content)
            return f"/uploads/labels/{fname}"
    except Exception as ex:
        logging.error("Canada Post get-artifact failed: %s", ex)
        return None


async def _canada_post_transmit(group_id: str) -> list:
    """Transmit Shipments → manifeste(s). SANS CET APPEL, Postes Canada facture
    tous les envois non payés AVEC une surcharge de 2 $/article et retire le
    rabais d'automatisation. C'est l'étape la plus coûteuse à oublier."""
    if not is_canada_post_configured():
        raise HTTPException(503, "Canada Post is not configured")
    if _cp_use_openapi():
        return await _canada_post_transmit_openapi(group_id)
    cust = CANADA_POST_CUSTOMER_NUMBER
    e = _cp_xml_escape
    body = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<transmit-set xmlns="http://www.canadapost.ca/ws/manifest-v8">'
        f"<group-ids><group-id>{e(group_id)}</group-id></group-ids>"
        f"<cpc-pickup-indicator>true</cpc-pickup-indicator>"
        f"<requested-shipping-point>{e(CANADA_POST_ORIGIN_POSTAL_CODE.replace(' ', '').upper())}</requested-shipping-point>"
        "<detailed-manifests>true</detailed-manifests>"
        "<method-of-payment>Account</method-of-payment>"
        "<manifest-address>"
        f"<manifest-company>{e(CANADA_POST_SENDER_NAME)}</manifest-company>"
        f"<phone-number>{e(CANADA_POST_SENDER_PHONE)}</phone-number>"
        "<address-details>"
        f"<address-line-1>{e(CANADA_POST_SENDER_ADDRESS)}</address-line-1>"
        f"<city>{e(CANADA_POST_SENDER_CITY)}</city>"
        f"<prov-state>{e(CANADA_POST_SENDER_PROVINCE)}</prov-state>"
        f"<postal-zip-code>{e(CANADA_POST_ORIGIN_POSTAL_CODE.replace(' ', '').upper())}</postal-zip-code>"
        "</address-details>"
        "</manifest-address>"
        "</transmit-set>"
    )
    ctype = "application/vnd.cpc.manifest-v8+xml"
    try:
        async with httpx.AsyncClient(timeout=45) as cx:
            r = await cx.post(
                f"{CANADA_POST_BASE_URL}/rs/{cust}/{cust}/manifest",
                content=body.encode("utf-8"),
                auth=_cp_auth_tuple(),
                headers={"Accept": ctype, "Content-Type": ctype, "Accept-language": "en-CA"},
            )
    except Exception as ex:
        logging.error("Canada Post transmit request failed: %s", ex)
        raise HTTPException(502, "Canada Post unreachable")

    if r.status_code >= 400:
        logging.error("Canada Post transmit %s: %s", r.status_code, r.text[:800])
        raise HTTPException(502, f"Canada Post rejected the transmission ({r.status_code})")

    root = ET.fromstring(r.text)
    hrefs = [l.get("href") for l in root.findall(".//{*}link") if l.get("rel") == "manifest"]
    return [h for h in hrefs if h]


async def _canada_post_void(shipment_id: str) -> bool:
    """Void Shipment — annule une étiquette gâchée NON transmise."""
    if not (is_canada_post_configured() and shipment_id):
        return False
    if _cp_use_openapi():
        return await _canada_post_void_openapi(shipment_id)
    cust = CANADA_POST_CUSTOMER_NUMBER
    path = (f"/rs/{cust}/{cust}/shipment/{shipment_id}" if CANADA_POST_CONTRACT_ID.strip()
            else f"/rs/{cust}/ncshipment/{shipment_id}")
    try:
        async with httpx.AsyncClient(timeout=20) as cx:
            r = await cx.delete(f"{CANADA_POST_BASE_URL}{path}", auth=_cp_auth_tuple(),
                                headers={"Accept": "application/vnd.cpc.shipment-v8+xml"})
            return r.status_code < 400
    except Exception as ex:
        logging.error("Canada Post void failed: %s", ex)
        return False


async def _auto_create_dispatch_label(order_id: str, service_code: Optional[str] = None) -> Optional[dict]:
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        return None
    if order.get("payment_status") != "paid":
        return None
    info = order.get("shipping_info") or {}
    if info.get("label_url") and info.get("tracking_number"):
        return info
    if not is_canada_post_configured():
        return None

    svc = (service_code or info.get("service_code") or CANADA_POST_DEFAULT_SERVICE_CODE or "DOM.EP").strip()
    try:
        res = await _canada_post_create_shipment(order, svc, _order_weight_kg(order))
        label_url = await _canada_post_get_artifact(res["label_href"], order["id"])
        now = datetime.now(timezone.utc).isoformat()
        shipping_info = {
            **info,
            "carrier": "Canada Post",
            "tracking_number": res["pin"],
            "label_url": label_url,
            "cp_shipment_id": res["shipment_id"],
            "cost": await _canada_post_shipment_price(res["shipment_id"], preferred_service_code=svc),
            "cp_group_id": res["group_id"],
            "cp_transmitted": False,
            "service_code": svc,
            "shipped_at": now,
        }
        await db.orders.update_one(
            {"id": order["id"]},
            {"$set": {"shipping_info": shipping_info, "fulfillment_status": "shipped"},
             "$push": {"notes": {
                 "id": str(uuid.uuid4()),
                 "text": f"Étiquette Postes Canada créée automatiquement — suivi {res['pin']}.",
                 "author": "system",
                 "created_at": now,
             }}},
        )
        fresh = await db.orders.find_one({"id": order["id"]}, {"_id": 0})
        asyncio.create_task(send_shipping_notification(fresh))
        return shipping_info
    except Exception as ex:
        logging.error("auto label failed for %s: %s", order["order_number"], ex)
        return None


async def _auto_label_paid_orders_once() -> int:
    cursor = db.orders.find(
        {
            "payment_status": "paid",
            "fulfillment_status": {"$in": ["processing", "pending"]},
            "shipping_info.label_url": {"$in": [None, ""]},
            "shipping_info.tracking_number": {"$in": [None, ""]},
        },
        {"_id": 0, "id": 1},
    ).sort("paid_at", 1)
    n = 0
    async for order in cursor:
        result = await _auto_create_dispatch_label(order["id"])
        if result:
            n += 1
    return n


async def _auto_label_paid_orders_watchdog() -> None:
    while True:
        try:
            count = await _auto_label_paid_orders_once()
            if count:
                logging.info("auto label watchdog: %d label(s) created", count)
        except Exception as ex:  # pragma: no cover
            logging.error("auto label watchdog failed: %s", ex)
        await asyncio.sleep(max(15, CANADA_POST_AUTO_LABEL_INTERVAL_SECONDS))


async def _auto_sync_delivered_orders_once(limit: int = 200) -> int:
    """Passe automatiquement en 'delivered' les commandes expédiées dont le
    repérage Canada Post confirme la livraison."""
    if not CANADA_POST_API_KEY:
        return 0
    rows = await db.orders.find(
        {
            "fulfillment_status": "shipped",
            "shipping_info.tracking_number": {"$nin": [None, ""]},
        },
        {"_id": 0, "id": 1, "order_number": 1, "shipping_info": 1},
    ).sort("shipping_info.shipped_at", 1).to_list(max(1, min(limit, 1000)))

    updated = 0
    for order in rows:
        info = order.get("shipping_info") or {}
        pin = str(info.get("tracking_number") or "").strip()
        if not pin:
            continue

        live = await _canada_post_track(pin)
        delivered, evidence = _cp_tracking_indicates_delivered(live)
        source = "canada_post_tracking_auto"
        if not delivered:
            shipped_at = str(info.get("shipped_at") or "")
            if _sandbox_fallback_ready(shipped_at):
                delivered = True
                evidence = "sandbox fallback after delay"
                source = "sandbox_time_fallback_auto"
        if not delivered:
            continue

        now = datetime.now(timezone.utc).isoformat()
        res = await db.orders.update_one(
            {"id": order["id"], "fulfillment_status": "shipped"},
            {
                "$set": {
                    "fulfillment_status": "delivered",
                    "shipping_info.delivered_at": now,
                    "shipping_info.delivery_source": source,
                },
                "$push": {
                    "notes": {
                        "id": str(uuid.uuid4()),
                        "text": f"Statut livré auto-confirmé par repérage Canada Post ({pin}) — {evidence or 'delivered'}.",
                        "author": "system",
                        "created_at": now,
                    }
                },
            },
        )
        if res.modified_count:
            updated += 1
    return updated


async def _auto_sync_delivered_orders_watchdog() -> None:
    while True:
        try:
            count = await _auto_sync_delivered_orders_once()
            if count:
                logging.info("auto delivery watchdog: %d order(s) marked delivered", count)
        except Exception as ex:  # pragma: no cover
            logging.error("auto delivery watchdog failed: %s", ex)
        await asyncio.sleep(max(60, CANADA_POST_AUTO_DELIVERY_SYNC_SECONDS))


# ---------------------------------------------------------------------------
# Email helpers (Resend)
# ---------------------------------------------------------------------------
def _items_html(items: list, lang: str = "en") -> str:
    rows = []
    for it in items:
        name = (it.get("name_fr") or it.get("name_en")) if lang == "fr" else (it.get("name_en") or it.get("name_fr"))
        rows.append(
            f'<tr><td style="padding:8px 0;border-bottom:1px solid #E2E8F0">'
            f'<strong style="color:#0B2E4F">{it["qty"]}× {name}</strong>'
            f'<div style="font-family:monospace;font-size:11px;color:#94A3B8">{it.get("slug","")}</div>'
            f'</td><td style="padding:8px 0;border-bottom:1px solid #E2E8F0;text-align:right;font-weight:bold;color:#0B2E4F">'
            f'${it["line_total"]:.2f}</td></tr>'
        )
    return "".join(rows)


def _order_email_html(order: dict, body_intro_fr: str, body_intro_en: str = None) -> str:
    """Courriel de commande — identité NOVA, bilingue selon order['lang']."""
    # rétrocompat : si appelé avec un seul intro (ancienne signature positionnelle)
    if body_intro_en is None:
        body_intro_en = body_intro_fr
    lang = (order.get("lang") or "en").lower()
    lang = "fr" if lang.startswith("fr") else "en"
    def L(fr, en): return fr if lang == "fr" else en

    interac = order["payment_info"].get("instructions") if order["payment_method"] == "interac" else None
    np_info = order["payment_info"].get("provider_response") if order["payment_method"] == "nowpayments" else None

    payment_block = ""
    if interac:
        payment_block = f"""
        <div style="background:#F7FAFC;border:2px solid #00B8D4;border-radius:8px;padding:20px;margin:24px 0">
          <div style="font-family:monospace;font-size:11px;letter-spacing:2px;color:#0B2E4F;font-weight:bold;margin-bottom:12px">⚡ {L("INSTRUCTIONS DE VIREMENT INTERAC", "INTERAC E-TRANSFER INSTRUCTIONS")}</div>
          <table style="width:100%;font-family:monospace;font-size:13px">
            <tr><td style="padding:6px 0;color:#3E5C76">{L("Envoyer à", "Send to")}:</td><td style="padding:6px 0;font-weight:bold">{interac["send_to"]}</td></tr>
            <tr><td style="padding:6px 0;color:#3E5C76">{L("Montant", "Amount")}:</td><td style="padding:6px 0;font-weight:bold">${interac["amount_cad"]:.2f} CAD</td></tr>
            <tr><td style="padding:6px 0;color:#3E5C76">{L("Référence (obligatoire)", "Reference (required)")}:</td><td style="padding:6px 0;font-weight:bold;color:#00B8D4">{interac["reference"]}</td></tr>
            <tr><td style="padding:6px 0;color:#3E5C76">{L("Question de sécurité", "Security question")}:</td><td style="padding:6px 0">{interac["security_question"]}</td></tr>
            <tr><td style="padding:6px 0;color:#3E5C76">{L("Réponse", "Security answer")}:</td><td style="padding:6px 0;font-weight:bold">{interac["security_answer_hint"]}</td></tr>
          </table>
        </div>"""
    elif np_info:
        mock_warning = ""
        if np_info.get("mock"):
            mock_warning = f'<div style="background:#FFF9E6;border:1px solid #E8A33D;border-radius:4px;padding:10px;margin-bottom:12px;font-size:12px;color:#0B2E4F">⚠ {L("MODE DÉMO — configurez NOWPAYMENTS_API_KEY pour les paiements crypto réels.", "DEMO MODE — configure NOWPAYMENTS_API_KEY for live crypto payments.")}</div>'
        if np_info.get("invoice_url"):
            payment_block = f"""
        <div style="background:#F7FAFC;border:2px solid #0B2E4F;border-radius:8px;padding:20px;margin:24px 0">
          <div style="font-family:monospace;font-size:11px;letter-spacing:2px;font-weight:bold;margin-bottom:12px;color:#0B2E4F">₿ {L("PAIEMENT CRYPTO", "CRYPTO PAYMENT")}</div>
          {mock_warning}
          <p style="font-size:13px;margin:0 0 16px;color:#1A2A38">{L("Payez le montant exact en toute sécurité via NOWPayments — votre commande est confirmée automatiquement dès réception.", "Pay the exact order amount securely via NOWPayments — your order is confirmed automatically once payment is received.")}</p>
          <a href="{np_info["invoice_url"]}" style="display:inline-block;background:#00B8D4;color:#fff;font-family:monospace;font-size:12px;letter-spacing:2px;padding:12px 24px;text-decoration:none;border-radius:6px">{L("PAYER MAINTENANT", "PAY NOW")} →</a>
        </div>"""
        else:
            payment_block = f"""
        <div style="background:#F7FAFC;border:2px solid #0B2E4F;border-radius:8px;padding:20px;margin:24px 0">
          <div style="font-family:monospace;font-size:11px;letter-spacing:2px;font-weight:bold;margin-bottom:12px;color:#0B2E4F">₿ {L("INSTRUCTIONS PAIEMENT CRYPTO", "CRYPTO PAYMENT INSTRUCTIONS")}</div>
          {mock_warning}
          <table style="width:100%;font-family:monospace;font-size:13px">
            <tr><td style="padding:6px 0;color:#3E5C76">{L("Adresse de dépôt", "Deposit address")}:</td><td style="padding:6px 0;font-weight:bold;word-break:break-all">{np_info.get("pay_address","")}</td></tr>
            <tr><td style="padding:6px 0;color:#3E5C76">{L("Envoyer exactement", "Send exactly")}:</td><td style="padding:6px 0;font-weight:bold">{np_info.get("pay_amount","")} {str(np_info.get("pay_currency","")).upper()}</td></tr>
          </table>
        </div>"""

    heading = L(body_intro_fr, body_intro_en)
    recap = L(f'Commande <strong>{order["order_number"]}</strong> · {len(order["items"])} article(s) · ${order["total"]:.2f} CAD',
              f'Order <strong>{order["order_number"]}</strong> · {len(order["items"])} item(s) · ${order["total"]:.2f} CAD')
    base = os.environ.get("PUBLIC_BASE_URL", "https://fironova.com").rstrip("/")
    track = f"""
      <div style="margin:24px 0 4px">
        <a href="{base}/order/{order.get('id','')}" style="display:inline-block;background:#0B2E4F;color:#fff;font-family:monospace;font-size:12px;letter-spacing:2px;padding:12px 24px;text-decoration:none;border-radius:6px">{L("SUIVRE MA COMMANDE", "TRACK MY ORDER")} →</a>
      </div>"""

    return f"""<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#F7FAFC;font-family:'Helvetica Neue',Arial,sans-serif;color:#0B2E4F">
  <table style="width:100%;max-width:640px;margin:0 auto;background:#fff;border:1px solid #E2E8F0;border-radius:12px;overflow:hidden">
    <tr><td style="background:#0B2E4F;color:#fff;padding:20px 28px;font-family:monospace;font-size:11px;letter-spacing:3px">// FIRONOVA · {order["order_number"]}</td></tr>
    <tr><td style="padding:32px 28px">
      <h1 style="margin:0 0 8px;font-size:26px;font-weight:800;letter-spacing:-0.02em;color:#0B2E4F">{heading}</h1>
      <p style="margin:0 0 24px;color:#3E5C76;font-size:15px;line-height:1.6">{recap}</p>
      {payment_block}
      <table style="width:100%;margin-top:24px;font-size:14px">
        {_items_html(order["items"], lang)}
        <tr><td style="padding:10px 0;color:#3E5C76;font-size:12px">{L("Sous-total", "Subtotal")}</td><td style="padding:10px 0;text-align:right;color:#0B2E4F">${order["subtotal"]:.2f}</td></tr>
        <tr><td style="padding:4px 0;color:#3E5C76;font-size:12px">{L("Livraison", "Shipping")}</td><td style="padding:4px 0;text-align:right;color:#0B2E4F">${order["shipping"]:.2f}</td></tr>
        <tr><td style="padding:14px 0;border-top:2px solid #0B2E4F;font-weight:bold;font-size:18px;color:#0B2E4F">TOTAL CAD</td><td style="padding:14px 0;border-top:2px solid #0B2E4F;text-align:right;font-weight:bold;font-size:18px;color:#0B2E4F">${order["total"]:.2f}</td></tr>
      </table>
      {track}
      <p style="margin:32px 0 0;font-family:monospace;font-size:10px;letter-spacing:2px;color:#94A3B8;text-transform:uppercase">{L("Réservé à la recherche · Ne pas consommer", "For Research Use Only · Not For Human Or Veterinary Consumption")}</p>
    </td></tr>
    <tr><td style="background:#0B2E4F;color:#fff;padding:14px 28px;font-family:monospace;font-size:10px;letter-spacing:2px">FIRONOVA · CANADA · {datetime.now(timezone.utc).strftime("%Y")}</td></tr>
  </table>
</body></html>"""


async def _send_email(to: str | list, subject: str, html: str, from_email: str | None = None) -> None:
    """Sends via Resend; logs and continues silently on any failure (no API key, send error, etc.).
    from_email permet de surcharger l'expéditeur (ex. auth vs commandes). Défaut : SENDER_EMAIL."""
    to_list = to if isinstance(to, list) else [to]
    if not RESEND_API_KEY:
        logging.info("[email-log] would send to %s subj=%r (no RESEND_API_KEY configured)", to_list, subject)
        return
    try:
        params = {"from": from_email or SENDER_EMAIL, "to": to_list, "subject": subject, "html": html}
        result = await asyncio.to_thread(resend.Emails.send, params)
        logging.info("[email] sent id=%s to=%s", result.get("id") if isinstance(result, dict) else result, to_list)
    except Exception as e:
        logging.error("[email] failed to send to=%s err=%s", to_list, e)


async def send_order_confirmation(order: dict) -> None:
    if not order.get("email"):
        logging.info("[email] skip customer confirm: no email on order %s", order["order_number"])
    else:
        html = _order_email_html(order, "Commande reçue", "Order received")
        await _send_email(order["email"], f"FIRONOVA — Order {order['order_number']} received", html)

    # Admin notification
    admin_html = _order_email_html(order, "Nouvelle commande", "New order received")
    await _send_email(
        ADMIN_NOTIFICATION_EMAIL,
        f"[FIRONOVA ADMIN] New order {order['order_number']} — ${order['total']:.2f} CAD",
        admin_html,
    )


async def send_payment_received(order: dict) -> None:
    if not order.get("email"):
        logging.info("[email] skip payment-received: no email on order %s", order["order_number"])
        return
    html = _order_email_html(order, "Paiement reçu", "Payment received")
    await _send_email(order["email"], f"FIRONOVA — Payment received for {order['order_number']}", html)


def _simple_order_email_html(order: dict, heading: str, body_html: str) -> str:
    return f"""<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#F7FAFC;font-family:'Helvetica Neue',Arial,sans-serif;color:#0B2E4F">
  <table style="width:100%;max-width:640px;margin:0 auto;background:#fff;border:1px solid #E2E8F0;border-radius:12px;overflow:hidden">
    <tr><td style="background:#0B2E4F;color:#fff;padding:20px 28px">
      <div style="font-family:monospace;font-size:12px;letter-spacing:3px">FIRONOVA<span style="color:#00B8D4"> ·</span></div>
      <div style="font-size:20px;font-weight:800;letter-spacing:-0.5px;margin-top:6px">{heading}</div>
    </td></tr>
    <tr><td style="padding:28px">
      <div style="font-family:monospace;font-size:12px;letter-spacing:2px;color:#3E5C76">ORDER {order.get('order_number','')}</div>
      <div style="font-size:14px;line-height:1.7;margin-top:14px;color:#1A2A38">{body_html}</div>
    </td></tr>
    <tr><td style="background:#F7FAFC;padding:16px 28px;font-family:monospace;font-size:10px;letter-spacing:1px;color:#94A3B8;border-top:1px solid #E2E8F0">
      PRODUITS DESTINÉS À LA RECHERCHE UNIQUEMENT (RUO) · 18+ · Ne pas consommer.<br>
      FOR RESEARCH USE ONLY (RUO) · 18+ · Not for human consumption.
    </td></tr>
  </table>
</body></html>"""


def _prelaunch_email_html(heading: str, body_html: str) -> str:
    """Même gabarit que _simple_order_email_html, mais sans numéro de commande
    (un abonné pré-lancement n'en a pas)."""
    return f"""<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#F7FAFC;font-family:'Helvetica Neue',Arial,sans-serif;color:#0B2E4F">
  <table style="width:100%;max-width:640px;margin:0 auto;background:#fff;border:1px solid #0B2E4F">
    <tr><td style="background:#0B2E4F;color:#fff;padding:20px 28px">
      <div style="font-family:monospace;font-size:12px;letter-spacing:3px">FIRONOVA.</div>
      <div style="font-size:20px;font-weight:800;letter-spacing:-0.5px;margin-top:6px">{heading}</div>
    </td></tr>
    <tr><td style="padding:28px"><div style="font-size:14px;line-height:1.7">{body_html}</div></td></tr>
    <tr><td style="background:#F7FAFC;padding:16px 28px;font-family:monospace;font-size:10px;letter-spacing:1px;color:#94A3B8">
      FOR LABORATORY RESEARCH USE ONLY · NOT FOR HUMAN OR VETERINARY CONSUMPTION · 19+ ONLY
    </td></tr>
  </table>
</body></html>"""


async def send_prelaunch_welcome(email: str, lang: str = "en", unsubscribe_token: str = "") -> None:
    """CTA → création de compte, pour verrouiller les 15 % au lancement."""
    base = PUBLIC_BASE_URL or ""
    register_url = f"{base}/register?ref=launch"
    unsub = f"{base}/api/newsletter/unsubscribe?token={unsubscribe_token}" if unsubscribe_token else ""
    if lang == "fr":
        heading = "Bienvenue sur la liste de lancement"
        body = (
            f"<p>Merci de vous être inscrit à la liste de prélancement FIRONOVA.</p>"
            f"<p>Créez votre compte dès maintenant pour verrouiller <strong>15 % de rabais</strong> "
            f"sur votre première commande au lancement, avec le code "
            f"<strong style='font-family:monospace'>{LAUNCH_COUPON_CODE}</strong>.</p>"
            f"<p style='margin-top:20px'><a href='{register_url}' style='display:inline-block;"
            f"background:#00B8D4;color:#fff;font-family:monospace;font-size:12px;letter-spacing:2px;"
            f"padding:14px 28px;text-decoration:none'>CRÉER MON COMPTE →</a></p>"
        )
        subject = "FIRONOVA — 15 % vous attendent au lancement"
        unsub_txt = "Se désabonner"
    else:
        heading = "Welcome to the launch list"
        body = (
            f"<p>Thanks for joining the FIRONOVA pre-launch list.</p>"
            f"<p>Create your account now to lock in <strong>15% off</strong> your first order "
            f"at launch, with code <strong style='font-family:monospace'>{LAUNCH_COUPON_CODE}</strong>.</p>"
            f"<p style='margin-top:20px'><a href='{register_url}' style='display:inline-block;"
            f"background:#00B8D4;color:#fff;font-family:monospace;font-size:12px;letter-spacing:2px;"
            f"padding:14px 28px;text-decoration:none'>CREATE MY ACCOUNT →</a></p>"
        )
        subject = "FIRONOVA — 15% off waiting at launch"
        unsub_txt = "Unsubscribe"
    if unsub:
        # Lien de désabonnement obligatoire dans chaque envoi commercial (LCAP).
        body += (f"<p style='margin-top:28px;font-size:11px;color:#94A3B8'>"
                 f"<a href='{unsub}' style='color:#94A3B8'>{unsub_txt}</a></p>")
    await _send_email(email, subject, _prelaunch_email_html(heading, body))


async def send_shipping_notification(order: dict) -> None:
    """Courriel de suivi bilingue. Aucune mention du contenu (emballage discret)."""
    if not order.get("email"):
        return
    info = order.get("shipping_info") or {}
    pin = info.get("tracking_number", "")
    carrier = info.get("carrier", "Canada Post")
    track_url = f"https://www.canadapost-postescanada.ca/track-reperage/en#/details/{pin}"
    body = (
        f"Your order has shipped via {carrier}. / Votre commande a été expédiée via {carrier}."
        f"<div style='border-left:3px solid #0B2E4F;padding:10px 14px;margin-top:12px;background:#F7FAFC'>"
        f"<div style='font-family:monospace;font-size:12px;letter-spacing:1px;color:#3E5C76'>"
        f"TRACKING / SUIVI</div>"
        f"<div style='font-family:monospace;font-size:15px;font-weight:bold;margin-top:4px'>{pin}</div>"
        f"</div>"
        f"<p style='margin-top:16px'><a href='{track_url}' "
        f"style='display:inline-block;background:#0B2E4F;color:#fff;font-family:monospace;font-size:12px;"
        f"letter-spacing:2px;padding:12px 24px;text-decoration:none'>TRACK PARCEL / SUIVRE →</a></p>"
    )
    html = _simple_order_email_html(order, "Your order has shipped / Votre commande est expédiée", body)
    await _send_email(order["email"], f"FIRONOVA — Order {order['order_number']} shipped / expédiée", html)


async def send_customer_note_email(order: dict, note_text: str) -> None:
    if not order.get("email"):
        return
    body = (
        f"A note has been added to your order / Une note a été ajoutée à votre commande :"
        f"<div style='border-left:3px solid #0B2E4F;padding:10px 14px;margin-top:12px;background:#F7FAFC'>{note_text}</div>"
    )
    html = _simple_order_email_html(order, "Note about your order / Note sur votre commande", body)
    await _send_email(order["email"], f"FIRONOVA — Note about order {order['order_number']}", html)


async def send_refund_email(order: dict, amount: float, total_refunded: float) -> None:
    if not order.get("email"):
        return
    full = total_refunded >= float(order.get("total", 0))
    kind = "Full refund / Remboursement total" if full else "Partial refund / Remboursement partiel"
    body = (
        f"{kind}<br/>"
        f"Refunded amount / Montant remboursé : <b>${amount:.2f} CAD</b><br/>"
        f"Total refunded to date / Total remboursé à ce jour : <b>${total_refunded:.2f} CAD</b> "
        f"(order total / total de la commande : ${float(order.get('total',0)):.2f} CAD)"
    )
    html = _simple_order_email_html(order, "Order refunded / Commande remboursée", body)
    await _send_email(order["email"], f"FIRONOVA — Refund for order {order['order_number']}", html)


# ---------------------------------------------------------------------------
# Back-in-stock notifications
# ---------------------------------------------------------------------------
def _restock_email_html(product: dict, variant: Optional[dict]) -> str:
    name = product.get("name_en", product.get("slug", ""))
    variant_label = f" — {variant['name']}" if variant and variant.get("name") else ""
    slug = product.get("slug", "")
    link = f"{PUBLIC_BASE_URL}/product/{slug}" if PUBLIC_BASE_URL else f"/product/{slug}"
    return f"""<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#F7FAFC;font-family:'Helvetica Neue',Arial,sans-serif;color:#0B2E4F">
  <table style="width:100%;max-width:640px;margin:0 auto;background:#fff;border:1px solid #0B2E4F">
    <tr><td style="background:#0B2E4F;color:#fff;padding:20px 28px;font-family:monospace;font-size:11px;letter-spacing:3px">// FIRONOVA · BACK IN STOCK</td></tr>
    <tr><td style="padding:32px 28px">
      <h1 style="margin:0 0 12px;font-size:24px;font-weight:900;letter-spacing:-0.02em;text-transform:uppercase">{name}{variant_label}</h1>
      <p style="margin:0 0 20px;color:#555;font-size:15px;line-height:1.6">
        Good news — the product you were tracking is available again.<br/>
        Bonne nouvelle — le produit que vous suiviez est de nouveau en stock.
      </p>
      <a href="{link}" style="display:inline-block;background:#0B2E4F;color:#fff;font-family:monospace;font-size:12px;letter-spacing:2px;padding:12px 24px;text-decoration:none">VIEW PRODUCT / VOIR LE PRODUIT →</a>
      <p style="margin:32px 0 0;font-family:monospace;font-size:10px;letter-spacing:2px;color:#94A3B8;text-transform:uppercase">For Research Use Only · Not For Human Or Veterinary Consumption</p>
    </td></tr>
    <tr><td style="background:#0B2E4F;color:#fff;padding:14px 28px;font-family:monospace;font-size:10px;letter-spacing:2px">FIRONOVA · CANADA · {datetime.now(timezone.utc).strftime("%Y")}</td></tr>
  </table>
</body></html>"""


async def _send_restock_email(to_email: str, product: dict, variant: Optional[dict]) -> None:
    name = product.get("name_en", product.get("slug", ""))
    html = _restock_email_html(product, variant)
    await _send_email(to_email, f"FIRONOVA — {name} is back in stock", html)


async def _maybe_notify_restock(product_id: str, variant_id: Optional[str] = None) -> None:
    """Checks current stock for a product/variant; if positive, emails every pending
    subscriber for that exact product/variant and marks them notified (one-shot)."""
    product = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not product:
        return
    variant = None
    if variant_id and variant_id not in ("", "_default"):
        variant = next((v for v in product.get("variants", []) if v.get("id") == variant_id), None)
        current_stock = variant.get("stock", 0) if variant else 0
    else:
        variant_id = None  # normalize "" / "_default" to None for legacy/product-level match
        current_stock = product.get("stock", 0)
    if current_stock <= 0:
        return

    pending = await db.stock_notifications.find(
        {"product_id": product_id, "variant_id": variant_id, "notified": False},
        {"_id": 0},
    ).to_list(1000)
    if not pending:
        return
    for sub in pending:
        asyncio.create_task(_send_restock_email(sub["email"], product, variant))
    await db.stock_notifications.update_many(
        {"product_id": product_id, "variant_id": variant_id, "notified": False},
        {"$set": {"notified": True, "notified_at": datetime.now(timezone.utc).isoformat()}},
    )


@api.post("/shipping/rates")
async def get_shipping_rates(payload: ShippingRateRequest):
    """Live Canada Post rates when CANADA_POST_API_KEY is configured; otherwise falls back
    to the existing flat-rate shipping_zones/shipping_methods (same zones used at checkout)."""
    weight_kg = await _estimate_parcel_weight_kg(payload.items)
    live_rates = await _canada_post_get_rates(payload.postal_code, payload.country, weight_kg)
    if live_rates:
        return {"source": "canada_post_live", "weight_kg": weight_kg, "rates": live_rates}

    zones = await db.shipping_zones.find({"deleted_at": None}, {"_id": 0}).to_list(50)
    zone = next((z for z in zones if payload.country in z.get("countries", [])), None)
    if not zone:
        zone = next((z for z in zones if "INTL" in z.get("countries", [])), None)
    methods = []
    if zone:
        methods = await db.shipping_methods.find(
            {"zone_id": zone["id"], "active": True, "deleted_at": None}, {"_id": 0}
        ).to_list(50)
    rates = [
        {"carrier": m["name"], "service_code": None, "service_name": m["name"],
         "cost_cad": m["cost_cad"], "eta_days": m["eta_days"]}
        for m in methods
    ] or [{"carrier": "FIRONOVA", "service_code": None, "service_name": "Standard",
           "cost_cad": SHIPPING_FLAT_CAD, "eta_days": "3-7 business days"}]
    return {"source": "flat_rate_fallback", "weight_kg": weight_kg, "rates": rates}


# ---------------------------------------------------------------------------
# Confirmation de paiement — point d'entrée UNIQUE et idempotent.
# Le filtre {"payment_status": {"$ne": "paid"}} dans le update_one garantit
# qu'un seul appelant gagne, même si le webhook Stripe et le polling frontend
# arrivent à la milliseconde près. Le coupon est décompté ici (et pas à la
# création) : un panier abandonné ne doit jamais consommer un usage_limit.
# ---------------------------------------------------------------------------
async def _mark_order_paid(order_id: str, note_text: Optional[str] = None) -> Optional[dict]:
    """Retourne l'order fraîche si CET appel a fait la transition, sinon None."""
    paid_at = datetime.now(timezone.utc).isoformat()
    update: dict = {
        "$set": {
            "payment_status": "paid",
            "fulfillment_status": "processing",
            "paid_at": paid_at,
            "dispatch_batch": compute_dispatch_batch(paid_at),
        }
    }
    if note_text:
        update["$push"] = {"notes": {
            "id": str(uuid.uuid4()),
            "text": note_text,
            "author": "system",
            "created_at": paid_at,
        }}

    res = await db.orders.update_one(
        {"id": order_id, "payment_status": {"$ne": "paid"}},
        update,
    )
    if not res.modified_count:
        return None  # déjà payée : un autre chemin a gagné la course

    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        return None

    # Décompte du coupon au paiement confirmé, une seule fois.
    coupon = order.get("coupon")
    if coupon and coupon.get("code") and not order.get("coupon_counted"):
        await db.coupons.update_one({"code": coupon["code"]}, {"$inc": {"used_count": 1}})
        await db.orders.update_one({"id": order_id}, {"$set": {"coupon_counted": True}})

    if order.get("email"):
        asyncio.create_task(send_payment_received(order))
    # Dispatch manuel : l'étiquette n'est PLUS créée automatiquement au paiement.
    # La commande attend dans « À étiqueter » et l'admin génère l'étiquette
    # depuis l'écran Dispatch.
    # asyncio.create_task(_auto_create_dispatch_label(order_id))
    # --- AFFILIATE: commission pending au paiement confirme ---
    await affiliate_on_order_paid(order)
    return order


@api.post("/checkout")
async def checkout(payload: CheckoutIn, request: Request):
    if not (payload.accept_terms and payload.confirm_age and payload.confirm_research_use):
        raise HTTPException(400, "All compliance confirmations are required")
    if not payload.items:
        raise HTTPException(400, "Cart is empty")

    user = await _resolve_user(request)

    line_items, subtotal, tax_rate, tax, shipping, total, discount, applied_coupon, has_preorder = await _build_order_totals(
        payload.items, payload.coupon_code
    )

    order_id = str(uuid.uuid4())
    # Numérotation Fironova : FN-AAMMJJ-XXXXXX (l'ancien préfixe NP- venait
    # de NORDPEP ; les commandes existantes gardent leur numéro).
    order_number = f"FN-{datetime.now(timezone.utc).strftime('%y%m%d')}-{order_id[:6].upper()}"

    # Réservation atomique AVANT tout appel réseau au PSP. Ferme la fenêtre
    # check-then-act qui laissait deux clients acheter le même dernier flacon.
    reserved = await _reserve_stock_atomic(line_items)

    payment_info: dict = {}
    if payload.payment_method == "interac":
        payment_info = {
            "type": "interac",
            "instructions": {
                "send_to": INTERAC_EMAIL,
                "amount_cad": total,
                "reference": order_number,
                "security_question": "What is the brand name? (lowercase)",
                "security_answer_hint": INTERAC_PASSWORD_HINT.lower(),
            },
        }
        payment_status = "awaiting_etransfer"
    else:
        try:
            np = await _nowpayments_create(order_id, total, payload.pay_currency or "btc")
        except Exception:
            await _release_stock_atomic(reserved)
            raise
        payment_info = {"type": "nowpayments", "provider_response": np}
        payment_status = "awaiting_crypto"

    order_doc = {
        "id": order_id,
        "order_number": order_number,
        "user_id": user["id"] if user else None,
        "email": (user["email"] if user else None) or (payload.email.lower() if payload.email else None),
        "items": line_items,
        "subtotal": subtotal,
        "discount": discount,
        "coupon": applied_coupon,
        "tax_rate": tax_rate,
        "tax": tax,
        "shipping": shipping,
        "total": total,
        "currency": "CAD",
        "shipping_address": payload.shipping.model_dump(),
        "shipping_info": {"carrier": "", "tracking_number": "", "shipped_at": None},
        "payment_method": payload.payment_method,
        "payment_status": payment_status,
        "payment_info": payment_info,
        "fulfillment_status": "preorder" if has_preorder else "pending",
        "has_preorder": has_preorder,
        "notes": [],
        "created_at": datetime.now(timezone.utc).isoformat(),
        "compliance": {
            "accept_terms": True,
            "confirm_age": True,
            "confirm_research_use": True,
            "ip": request.client.host if request.client else None,
        },
    }
    # --- AFFILIATE: attribution depuis le cookie fn_ref (champ additif) ---
    await affiliate_attach_to_order(order_doc, request)
    await db.orders.insert_one(order_doc)
    order_doc.pop("_id", None)

    # Le stock est déjà réservé atomiquement plus haut (_reserve_stock_atomic),
    # avant l'appel au PSP. Rien à faire ici.
    # Le coupon n'est PAS décompté ici : il l'est à la confirmation de paiement
    # (_mark_order_paid), sinon les paniers abandonnés épuisent l'usage_limit.

    # Fire-and-forget order confirmation + admin notification
    asyncio.create_task(send_order_confirmation(order_doc))

    return order_doc


@api.get("/orders/mine")
async def my_orders(user: dict = Depends(get_current_user)):
    items = await db.orders.find(
        {"user_id": user["id"], "deleted_at": None}, {"_id": 0}
    ).sort("created_at", -1).to_list(200)
    return items


@api.get("/orders/{order_id}")
async def get_order(order_id: str, request: Request):
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")
    # Anonymous orders are visible if order_id known; owned orders require auth match or admin
    user = await _resolve_user(request)
    if order.get("user_id"):
        if not user or (user["id"] != order["user_id"] and user.get("role") != "admin"):
            raise HTTPException(403, "Forbidden")
    if not (user and user.get("role") == "admin"):
        if isinstance(order.get("compliance"), dict):
            order["compliance"].pop("ip", None)
        order["notes"] = [n for n in (order.get("notes") or []) if n.get("visible_to_customer")]
    return order


@api.get("/orders/{order_id}/tracking")
async def order_tracking(order_id: str, request: Request):
    """Live Canada Post tracking for the order's tracking_number, when configured."""
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")
    user = await _resolve_user(request)
    if order.get("user_id"):
        if not user or (user["id"] != order["user_id"] and user.get("role") != "admin"):
            raise HTTPException(403, "Forbidden")
    pin = (order.get("shipping_info") or {}).get("tracking_number")
    if not pin:
        return {"tracked": False, "reason": "no_tracking_number"}
    live = await _canada_post_track(pin)
    if live:
        return {"tracked": True, "source": "canada_post_live", **live}
    return {"tracked": False, "reason": "unavailable_or_not_configured", "pin": pin}


@api.post("/admin/orders/{order_id}/sync-delivery")
async def admin_sync_delivery_status(order_id: str,
                                     _admin: dict = Depends(require_area("orders", "manage"))):
    """Vérifie le repérage CP et passe la commande à 'delivered' si la livraison
    est confirmée par le transporteur."""
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")

    info = order.get("shipping_info") or {}
    pin = str(info.get("tracking_number") or "").strip()
    if not pin:
        raise HTTPException(400, "No tracking number on this order")

    live = await _canada_post_track(pin)
    if not live:
        # Sandbox: fallback temporel pour permettre les tests E2E malgré
        # l'auth tracking CP indisponible.
        shipped_at = str(info.get("shipped_at") or "")
        if _sandbox_fallback_ready(shipped_at):
            now = datetime.now(timezone.utc).isoformat()
            await db.orders.update_one(
                {"id": order_id, "fulfillment_status": "shipped"},
                {
                    "$set": {
                        "fulfillment_status": "delivered",
                        "shipping_info.delivered_at": now,
                        "shipping_info.delivery_source": "sandbox_time_fallback_manual",
                    },
                    "$push": {
                        "notes": {
                            "id": str(uuid.uuid4()),
                            "text": f"Statut livré (fallback sandbox après délai) — {pin}.",
                            "author": "system",
                            "created_at": now,
                        }
                    },
                },
            )
            updated = await db.orders.find_one({"id": order_id}, {"_id": 0, "fulfillment_status": 1, "shipping_info": 1})
            return {
                "ok": True,
                "tracked": False,
                "delivered": True,
                "updated": True,
                "reason": "sandbox_fallback",
                "fulfillment_status": (updated or {}).get("fulfillment_status"),
                "shipping_info": (updated or {}).get("shipping_info") or {},
            }
        return {
            "ok": True,
            "tracked": False,
            "updated": False,
            "reason": "tracking_unavailable",
            "fulfillment_status": order.get("fulfillment_status"),
        }

    delivered, evidence = _cp_tracking_indicates_delivered(live)
    if not delivered:
        return {
            "ok": True,
            "tracked": True,
            "delivered": False,
            "updated": False,
            "reason": "not_delivered_yet",
            "fulfillment_status": order.get("fulfillment_status"),
            "summary": live.get("summary"),
        }

    # Déjà livré -> rien à changer.
    if str(order.get("fulfillment_status") or "").lower() == "delivered":
        return {
            "ok": True,
            "tracked": True,
            "delivered": True,
            "updated": False,
            "reason": "already_delivered",
            "fulfillment_status": "delivered",
            "summary": live.get("summary"),
        }

    now = datetime.now(timezone.utc).isoformat()
    await db.orders.update_one(
        {"id": order_id},
        {
            "$set": {
                "fulfillment_status": "delivered",
                "shipping_info.delivered_at": now,
                "shipping_info.delivery_source": "canada_post_tracking",
            },
            "$push": {
                "notes": {
                    "id": str(uuid.uuid4()),
                    "text": f"Statut livré confirmé par repérage Canada Post ({pin}) — {evidence or 'delivered'}.",
                    "author": "system",
                    "created_at": now,
                }
            },
        },
    )
    updated = await db.orders.find_one({"id": order_id}, {"_id": 0, "fulfillment_status": 1, "shipping_info": 1})
    return {
        "ok": True,
        "tracked": True,
        "delivered": True,
        "updated": True,
        "fulfillment_status": (updated or {}).get("fulfillment_status"),
        "shipping_info": (updated or {}).get("shipping_info") or {},
        "summary": live.get("summary"),
    }


_ORDER_STATUS_GROUPS = {
    "active": {"fulfillment_status": {"$nin": ["delivered", "cancelled", "failed"]}},
    "completed": {"fulfillment_status": "delivered"},
    "cancelled": {"fulfillment_status": {"$in": ["cancelled", "failed"]}},
}


def _status_group_filter(status_group: Optional[str]) -> dict:
    return dict(_ORDER_STATUS_GROUPS.get(status_group or "", {}))


@api.get("/admin/orders")
async def admin_orders(status_group: Optional[str] = None, _admin: dict = Depends(require_area("orders", "view"))):
    filt = _status_group_filter(status_group)
    filt["deleted_at"] = None
    return await db.orders.find(filt, {"_id": 0}).sort("created_at", -1).to_list(500)


@api.delete("/admin/orders/{order_id}")
async def admin_delete_order(order_id: str, admin: dict = Depends(require_area("orders", "manage"))):
    """Suppression douce — la commande va en corbeille, restaurable, et n'est
    PAS purgée automatiquement (contrairement aux autres types de données),
    car une commande payée est une pièce comptable."""
    return await _soft_delete("orders", order_id, admin)


@api.get("/admin/orders/counts")
async def admin_order_counts(_admin: dict = Depends(require_area("orders", "view"))):
    out = {}
    for group, filt in _ORDER_STATUS_GROUPS.items():
        out[group] = await db.orders.count_documents(filt)
    out["all"] = await db.orders.count_documents({})
    return out


@api.get("/admin/orders/dispatch-batch")
async def admin_dispatch_batch(
    date: Optional[str] = None, _admin: dict = Depends(require_area("orders", "view"))
):
    """
    Commandes du lot d'expédition d'un jour donné (défaut : prochain jour
    ouvrable courant). Payées, non annulées/expédiées/livrées, triées par paiement.
    """
    if not date:
        date = compute_dispatch_batch(datetime.now(timezone.utc))
    filt = {
        "dispatch_batch": date,
        "payment_status": "paid",
        "fulfillment_status": {"$nin": ["cancelled", "failed", "shipped", "delivered"]},
    }
    orders = (
        await db.orders.find(filt, {"_id": 0}).sort("paid_at", 1).to_list(500)
    )
    return {"batch_date": date, "count": len(orders), "orders": orders}


@api.put("/admin/orders/{order_id}/status")
async def admin_update_order(
    order_id: str,
    payment_status: Optional[str] = None,
    fulfillment_status: Optional[str] = None,
    _admin: dict = Depends(require_area("orders", "manage")),
):
    update: dict = {}
    if payment_status:
        update["payment_status"] = payment_status
    if fulfillment_status:
        update["fulfillment_status"] = fulfillment_status
    if not update:
        raise HTTPException(400, "No fields to update")

    existing = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Order not found")

    # Auto-transition: when payment becomes paid, move fulfillment to processing
    if (
        payment_status == "paid"
        and existing.get("payment_status") != "paid"
        and existing.get("fulfillment_status") in ("pending", "preorder", None)
    ):
        update["fulfillment_status"] = "processing"

    # Affecte le lot d'expédition au moment du paiement (idempotent).
    if (
        payment_status == "paid"
        and existing.get("payment_status") != "paid"
        and not existing.get("dispatch_batch")
    ):
        _paid_ref = update.get("paid_at") or existing.get("paid_at") or datetime.now(timezone.utc).isoformat()
        update["dispatch_batch"] = compute_dispatch_batch(_paid_ref)

    # Restock inventory when moving into cancelled/failed from a non-terminal state
    if (
        update.get("fulfillment_status") in ("cancelled", "failed")
        and existing.get("fulfillment_status") not in ("cancelled", "failed")
    ):
        await _restock_order_items(existing)

    await db.orders.update_one({"id": order_id}, {"$set": update})
    updated = await db.orders.find_one({"id": order_id}, {"_id": 0})

    # Trigger payment-received email when payment transitions to "paid"
    if (
        payment_status == "paid"
        and existing.get("payment_status") != "paid"
        and updated.get("email")
    ):
        asyncio.create_task(send_payment_received(updated))

    return updated


@api.post("/admin/orders/{order_id}/confirm-payment")
async def admin_confirm_payment(order_id: str, _admin: dict = Depends(require_area("orders", "manage"))):
    """One-click 'Mark as Paid' — atomically marks order as paid + processing + sends email."""
    existing = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not existing:
        raise HTTPException(404, "Order not found")
    if existing.get("payment_status") == "paid":
        return existing  # idempotent
    updated = await _mark_order_paid(order_id, "Payment manually confirmed by admin")
    return updated or existing


# ---------------------------------------------------------------------------
# Gestion des membres staff — réservé au rôle "admin" (owner). Un staff ne
# peut jamais modifier ses propres permissions ni celles d'un autre membre.
# ---------------------------------------------------------------------------
STAFF_INVITE_TTL_HOURS = 72


# ---------------------------------------------------------------------------
# Journal d'audit — qui a fait quoi, quand. Deux sources d'entrées :
#  1. Automatique : toute action "manage" (mutation) passée par require_area()
#     est journalisée génériquement (méthode + route + zone + auteur).
#  2. Explicite : les actions sensibles sur les membres (invite, promotion,
#     permissions, révocation) sont journalisées avec un détail lisible,
#     puisqu'elles ne passent pas par require_area() (réservées owner-only).
# ---------------------------------------------------------------------------
async def _log_action(user: dict, action: str, detail: str = "", area: str = "") -> None:
    try:
        await db.admin_audit_log.insert_one({
            "id": str(uuid.uuid4()),
            "user_id": user.get("id"),
            "user_email": user.get("email"),
            "user_name": user.get("name"),
            "role": user.get("role"),
            "area": area,
            "action": action,
            "detail": detail,
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
    except Exception as e:
        logging.error("[audit] failed to log action=%s: %s", action, e)


def _staff_invite_html(accept_url: str, inviter_name: str, lang: str = "fr") -> str:
    if lang == "fr":
        heading = "Vous êtes invité·e à rejoindre l'équipe FIRONOVA"
        body = (f"{inviter_name} vous invite à accéder au panneau d'administration FIRONOVA. "
                f"Cliquez ci-dessous pour créer votre mot de passe et activer votre accès. "
                f"Ce lien expire dans {STAFF_INVITE_TTL_HOURS} heures.")
        btn = "Activer mon accès"
    else:
        heading = "You've been invited to the FIRONOVA team"
        body = (f"{inviter_name} invited you to access the FIRONOVA admin panel. "
                f"Click below to set your password and activate your access. "
                f"This link expires in {STAFF_INVITE_TTL_HOURS} hours.")
        btn = "Activate my access"
    return f"""
    <div style="font-family:Georgia,serif;max-width:520px;margin:0 auto;padding:32px;color:#3A0A08;background:#FFFAF6">
      <div style="font-size:22px;font-weight:800;letter-spacing:-0.5px">FIRONOVA<span style="color:#00B8D4">.</span></div>
      <h2 style="margin-top:24px">{heading}</h2>
      <p style="line-height:1.6">{body}</p>
      <a href="{accept_url}" style="display:inline-block;margin-top:16px;background:#3A0A08;color:#fff;
         padding:14px 28px;text-decoration:none;font-family:monospace;font-size:12px;
         letter-spacing:0.2em;text-transform:uppercase">{btn} →</a>
      <p style="margin-top:24px;font-size:12px;color:#6B0504">{accept_url}</p>
    </div>
    """


@api.get("/admin/staff")
async def admin_list_staff(_admin: dict = Depends(get_admin_user)):
    """Membres actifs (admin + staff) — les clients normaux (role=user) sont exclus."""
    staff = await db.users.find(
        {"role": {"$in": ["admin", "staff"]}},
        {"_id": 0, "password_hash": 0, "token_version": 0},
    ).sort("created_at", -1).to_list(200)
    return staff


@api.get("/admin/staff/invites")
async def admin_list_staff_invites(_admin: dict = Depends(get_admin_user)):
    """Invitations en attente — équivalent de l'onglet 'Demandes en attente'."""
    now = datetime.now(timezone.utc).isoformat()
    invites = await db.staff_invites.find(
        {"used": False, "expires_at": {"$gt": now}}, {"_id": 0, "token": 0}
    ).sort("created_at", -1).to_list(100)
    return invites


@api.post("/admin/staff/invite")
async def admin_invite_staff(payload: StaffInviteIn, request: Request, admin: dict = Depends(get_admin_user)):
    email = payload.email.lower().strip()
    if await db.users.find_one({"email": email}):
        raise HTTPException(status_code=409, detail="A user with this email already exists")
    _rate_limit("staff_invite", admin["id"], 20, 3600, "Too many invitations sent. Try again later.")

    token = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    await db.staff_invites.insert_one({
        "id": str(uuid.uuid4()),
        "email": email,
        "name": payload.name.strip(),
        "permissions": payload.permissions.model_dump(),
        "as_owner": payload.as_owner,
        "invited_by": admin["id"],
        "token": token,
        "created_at": now.isoformat(),
        "expires_at": (now + timedelta(hours=STAFF_INVITE_TTL_HOURS)).isoformat(),
        "used": False,
    })
    base = PUBLIC_BASE_URL or str(request.base_url).rstrip("/")
    accept_url = f"{base}/staff-accept?token={token}"
    asyncio.create_task(_send_email(
        email, "FIRONOVA — Invitation à rejoindre l'équipe",
        _staff_invite_html(accept_url, admin.get("name", "L'équipe FIRONOVA")),
    ))
    await _log_action(admin, "staff.invite", detail=f"Invited {email} as {'owner' if payload.as_owner else 'staff'}")
    return {"ok": True, "sent_to": email}


@api.delete("/admin/staff/invites/{invite_id}")
async def admin_cancel_staff_invite(invite_id: str, admin: dict = Depends(get_admin_user)):
    res = await db.staff_invites.delete_one({"id": invite_id, "used": False})
    if not res.deleted_count:
        raise HTTPException(status_code=404, detail="Invite not found")
    await _log_action(admin, "staff.invite_cancel", detail=f"Cancelled invite {invite_id}")
    return {"ok": True}


@api.post("/staff/accept")
async def staff_accept_invite(payload: StaffAcceptIn, response: Response):
    """Lien cliqué depuis l'email — pas d'authentification préalable, le
    token à usage unique + TTL sert de preuve. Crée le compte staff (ou
    owner, si l'invitation le précisait)."""
    now = datetime.now(timezone.utc).isoformat()
    invite = await db.staff_invites.find_one({"token": payload.token, "used": False})
    if not invite or invite["expires_at"] < now:
        raise HTTPException(status_code=400, detail="Invalid or expired invitation")
    if await db.users.find_one({"email": invite["email"]}):
        raise HTTPException(status_code=409, detail="An account with this email already exists")

    as_owner = invite.get("as_owner", False)
    user_doc = {
        "id": str(uuid.uuid4()),
        "email": invite["email"],
        "name": invite["name"],
        "password_hash": hash_password(payload.password),
        "role": "admin" if as_owner else "staff",
        "token_version": 0,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    if not as_owner:
        user_doc["permissions"] = invite["permissions"]
    await db.users.insert_one(user_doc)
    await db.staff_invites.update_one({"token": payload.token}, {"$set": {"used": True, "used_at": now}})

    role = user_doc["role"]
    token = create_access_token(user_doc["id"], user_doc["email"], role, token_version=0)
    set_auth_cookie(response, token)
    return {
        "id": user_doc["id"], "email": user_doc["email"], "name": user_doc["name"],
        "role": role, "permissions": user_doc.get("permissions"),
        # NOTE: auth cookie-only — pas de token dans le body.
    }


@api.put("/admin/staff/{user_id}/permissions")
async def admin_update_staff_permissions(user_id: str, payload: StaffPermissionsIn,
                                         admin: dict = Depends(get_admin_user)):
    target = await db.users.find_one({"id": user_id})
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.get("role") == "admin":
        raise HTTPException(status_code=400, detail="Cannot restrict another admin's access this way")
    await db.users.update_one(
        {"id": user_id},
        {"$set": {"role": "staff", "permissions": payload.model_dump()},
         "$inc": {"token_version": 1}},  # les changements de droits prennent effet immédiatement
    )
    await _log_action(admin, "staff.permissions_update",
                      detail=f"Updated permissions for {target.get('email')}: {payload.model_dump()}")
    return {"ok": True}


@api.post("/admin/staff/{user_id}/promote")
async def admin_promote_to_owner(user_id: str, admin: dict = Depends(get_admin_user)):
    """Fait passer un membre staff au rang de owner (accès total, y compris
    la gestion des autres membres). Réversible uniquement en révoquant puis
    ré-invitant — il n'y a volontairement pas de 'rétrograder un owner' pour
    éviter qu'un owner en soit accidentellement privé de son propre accès."""
    target = await db.users.find_one({"id": user_id})
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.get("role") == "admin":
        raise HTTPException(status_code=400, detail="This user is already an owner")
    await db.users.update_one(
        {"id": user_id},
        {"$set": {"role": "admin"}, "$unset": {"permissions": ""}, "$inc": {"token_version": 1}},
    )
    await _log_action(admin, "staff.promote_to_owner", detail=f"Promoted {target.get('email')} to owner")
    return {"ok": True}


@api.delete("/admin/staff/{user_id}")
async def admin_revoke_staff(user_id: str, admin: dict = Depends(get_admin_user)):
    """Révoque l'accès admin — le compte redevient un compte client normal,
    n'est PAS supprimé (historique de commandes éventuel préservé)."""
    if user_id == admin["id"]:
        raise HTTPException(status_code=400, detail="You cannot revoke your own access")
    target = await db.users.find_one({"id": user_id})
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.get("role") == "admin":
        raise HTTPException(status_code=400, detail="Cannot revoke another admin this way")
    await db.users.update_one(
        {"id": user_id},
        {"$set": {"role": "user"}, "$unset": {"permissions": ""}, "$inc": {"token_version": 1}},
    )
    await _log_action(admin, "staff.revoke", detail=f"Revoked access for {target.get('email')}")
    return {"ok": True}


@api.get("/admin/audit-log")
async def admin_audit_log(limit: int = 200, admin: dict = Depends(get_admin_user)):
    """Journal d'audit — owner only. Couvre automatiquement toute action
    'manage' (mutation) sur les 35 endpoints admin, plus les actions
    explicites de gestion d'équipe (invite/promotion/permissions/révocation)."""
    limit = max(1, min(limit, 1000))
    entries = await db.admin_audit_log.find({}, {"_id": 0}).sort("created_at", -1).to_list(limit)
    return entries


@api.get("/admin/customers")
async def admin_customers(_admin: dict = Depends(require_area("customers", "view"))):
    """Clients enrichis : dépenses cumulées, nb de commandes payées, dernière commande,
    et segment de rétention déterministe (nouveau / actif / fidèle / à risque / inactif)."""
    users = await db.users.find(
        {"role": {"$ne": "admin"}},
        {"_id": 0, "password_hash": 0, "token_version": 0},
    ).sort("created_at", -1).to_list(2000)

    # Agrégation des commandes payées par email (une seule passe)
    agg = db.orders.aggregate([
        {"$match": {"payment_status": "paid", "email": {"$ne": None}}},
        {"$group": {
            "_id": "$email",
            "orders": {"$sum": 1},
            "spent": {"$sum": "$total"},
            "last_order": {"$max": "$created_at"},
        }},
    ])
    stats = {}
    async for row in agg:
        if row["_id"]:
            stats[row["_id"].lower()] = row

    now = datetime.now(timezone.utc)

    def _segment(orders, last_iso):
        if orders == 0:
            return "prospect"
        days = 999
        if last_iso:
            try:
                days = (now - datetime.fromisoformat(last_iso.replace("Z", "+00:00"))).days
            except Exception:
                days = 999
        if orders >= 3:
            return "loyal" if days <= 120 else "at_risk"
        if days <= 45:
            return "active"
        if days <= 120:
            return "cooling"
        return "dormant"

    out = []
    for u in users:
        st = stats.get((u.get("email") or "").lower())
        orders = st["orders"] if st else 0
        spent = round(st["spent"], 2) if st else 0.0
        last_order = st["last_order"] if st else None
        u["orders_count"] = orders
        u["total_spent"] = spent
        u["last_order_at"] = last_order
        u["segment"] = _segment(orders, last_order)
        out.append(u)

    # Compte par segment (pour les filtres UI)
    seg_counts = {}
    for u in out:
        seg_counts[u["segment"]] = seg_counts.get(u["segment"], 0) + 1

    return {"customers": out, "segment_counts": seg_counts, "total": len(out)}


@api.get("/admin/subscribers")
async def admin_list_subscribers(status: Optional[str] = None, _admin: dict = Depends(require_area("subscribers", "view"))):
    query = {"status": status} if status else {}
    subs = await db.subscribers.find(
        query, {"_id": 0, "unsubscribe_token": 0}
    ).sort("created_at", -1).to_list(5000)
    return subs


@api.get("/admin/subscribers.csv")
async def admin_subscribers_csv(status: Optional[str] = None, _admin: dict = Depends(require_area("subscribers", "view"))):
    query = {"status": status} if status else {}
    subs = await db.subscribers.find(query, {"_id": 0, "unsubscribe_token": 0}).to_list(5000)
    rows = [
        {
            "email": s.get("email", ""),
            "lang": s.get("lang", ""),
            "source": s.get("source", ""),
            "status": s.get("status", ""),
            "consent_at": s.get("consent_at", ""),
            "consent_ip": s.get("consent_ip", ""),
            "unsubscribed_at": s.get("unsubscribed_at") or "",
        }
        for s in subs
    ]
    return _csv_response(rows, f"fironova-subscribers-{datetime.now().strftime('%Y%m%d')}.csv")


@api.get("/admin/stats")
async def admin_stats(_admin: dict = Depends(require_area("dashboard", "view"))):
    total_orders = await db.orders.count_documents({})
    pending = await db.orders.count_documents({"fulfillment_status": "pending"})
    paid = await db.orders.count_documents({"payment_status": "paid"})
    users = await db.users.count_documents({"role": "user"})
    products = await db.products.count_documents({})
    low_stock = await db.products.count_documents(
        {"$expr": {"$lte": ["$stock", {"$ifNull": ["$low_stock_threshold", 10]}]}, "active": True}
    )
    revenue_cursor = db.orders.aggregate([
        {"$match": {"payment_status": "paid"}},
        {"$group": {"_id": None, "total": {"$sum": "$total"}}},
    ])
    revenue_doc = await revenue_cursor.to_list(1)
    revenue = revenue_doc[0]["total"] if revenue_doc else 0
    return {
        "total_orders": total_orders,
        "pending_orders": pending,
        "paid_orders": paid,
        "customers": users,
        "products": products,
        "low_stock": low_stock,
        "revenue_cad": round(revenue, 2),
    }


# ---------------------------------------------------------------------------
# Admin — order notes & shipping & stock
# ---------------------------------------------------------------------------
@api.post("/admin/orders/{order_id}/notes")
async def admin_add_order_note(order_id: str, payload: OrderNoteIn, admin: dict = Depends(require_area("orders", "manage"))):
    note = {
        "text": payload.text,
        "admin_email": admin["email"],
        "visible_to_customer": payload.visible_to_customer,
        "ts": datetime.now(timezone.utc).isoformat(),
    }
    res = await db.orders.update_one({"id": order_id}, {"$push": {"notes": note}})
    if res.matched_count == 0:
        raise HTTPException(404, "Order not found")
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if payload.visible_to_customer and order.get("email"):
        asyncio.create_task(send_customer_note_email(order, payload.text))
    return order


@api.post("/admin/orders/{order_id}/refund")
async def admin_refund_order(order_id: str, payload: RefundIn, admin: dict = Depends(require_area("orders", "manage"))):
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")
    already = float(order.get("refunded_amount", 0) or 0)
    total = float(order.get("total", 0))
    amount = round(payload.amount, 2)
    if already + amount > total + 0.001:
        raise HTTPException(400, f"Refund exceeds order total (already refunded ${already:.2f} of ${total:.2f})")
    new_refunded = round(already + amount, 2)
    update = {"refunded_amount": new_refunded}
    if new_refunded >= total:
        update["payment_status"] = "refunded"
        update["fulfillment_status"] = "refunded"
    note = {
        "text": f"Refund issued: ${amount:.2f} CAD (total refunded ${new_refunded:.2f} / ${total:.2f})",
        "admin_email": admin["email"],
        "visible_to_customer": False,
        "ts": datetime.now(timezone.utc).isoformat(),
    }
    await db.orders.update_one({"id": order_id}, {"$set": update, "$push": {"notes": note}})
    await affiliate_on_order_refunded(order_id, new_refunded, total)
    updated = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if updated.get("email"):
        asyncio.create_task(send_refund_email(updated, amount, new_refunded))
    return updated


@api.post("/admin/orders/{order_id}/resend-email")
async def admin_resend_order_email(order_id: str, _admin: dict = Depends(require_area("orders", "manage"))):
    """Re-sends the order details / payment-instructions email to the customer."""
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")
    if not order.get("email"):
        raise HTTPException(400, "Order has no customer email")
    if order.get("payment_status") == "paid":
        html = _order_email_html(order, "Paiement reçu", "Payment received")
    else:
        html = _order_email_html(order, "Commande reçue", "Order received")
    await _send_email(order["email"], f"FIRONOVA — Order {order['order_number']} details", html)
    return {"ok": True, "sent_to": order["email"]}


@api.put("/admin/orders/{order_id}/shipping")
async def admin_set_shipping_info(order_id: str, payload: ShippingInfoIn, _admin: dict = Depends(require_area("orders", "manage"))):
    existing_order = await db.orders.find_one({"id": order_id}, {"_id": 0, "shipping_info": 1})
    if not existing_order:
        raise HTTPException(404, "Order not found")
    prev = existing_order.get("shipping_info") or {}

    shipped_at = payload.shipped_at or (datetime.now(timezone.utc).isoformat() if payload.tracking_number else None)
    # PIÈGE : ce PUT remplaçait shipping_info EN BLOC, ce qui effaçait label_url,
    # cp_group_id et surtout cp_transmitted. La commande sortait alors de la
    # requête du manifeste → surcharge de 2 $/article encourue en silence.
    # On repart donc de l'état existant et on ne surcharge que les champs manuels.
    shipping_info = {
        **prev,
        "carrier": payload.carrier or "",
        "tracking_number": payload.tracking_number or "",
        "shipped_at": shipped_at,
    }
    update = {"shipping_info": shipping_info}
    if payload.tracking_number:
        update["fulfillment_status"] = "shipped"
    res = await db.orders.update_one({"id": order_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(404, "Order not found")
    return await db.orders.find_one({"id": order_id}, {"_id": 0})


# ---------------------------------------------------------------------------
# BLOC 4 — Postes Canada : étiquettes, manifeste, annulation.
# Le tarif live et le suivi existaient déjà. Ce qui manquait : générer
# l'étiquette, et surtout TRANSMETTRE LE MANIFESTE. Sans manifeste, Postes
# Canada facture chaque envoi non payé avec 2 $ de surcharge par article et
# retire le rabais d'automatisation.
# ---------------------------------------------------------------------------
def _order_weight_kg(order: dict) -> float:
    """Poids d'après les line_items figés sur la commande (pas de relecture produit :
    le poids doit refléter ce qui a été vendu, même si la fiche a changé depuis)."""
    total_g = 0.0
    for it in _order_items(order):
        total_g += float(it.get("weight_grams") or 50.0) * int(it.get("qty") or 1)
    return max(0.1, round(total_g / 1000.0, 3)) if total_g else 0.5


@api.get("/admin/orders/{order_id}/shipping-rates")
async def admin_order_shipping_rates(order_id: str, _admin: dict = Depends(require_area("orders", "view"))):
    """Services disponibles pour CETTE commande, afin de peupler le sélecteur admin."""
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")
    if not is_canada_post_configured():
        return {"configured": False, "rates": []}
    ship = order.get("shipping_address") or {}
    rates = await _canada_post_get_rates(
        ship.get("postal_code", ""), ship.get("country") or "CA", _order_weight_kg(order)
    )
    return {"configured": True, "rates": rates}


@api.post("/admin/orders/{order_id}/create-label")
async def admin_create_label(order_id: str, payload: CreateLabelIn,
                             _admin: dict = Depends(require_area("orders", "manage"))):
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")

    info = order.get("shipping_info") or {}
    # Idempotence exigée : ne jamais recréer une étiquette déjà émise —
    # sinon on paie deux fois le même colis.
    if info.get("label_url") and info.get("tracking_number"):
        return {"already_existed": True, "shipping_info": info}

    if not is_canada_post_configured():
        raise HTTPException(503, "Canada Post is not configured")

    res = await _canada_post_create_shipment(order, payload.service_code, _order_weight_kg(order))
    label_url = await _canada_post_get_artifact(res["label_href"], order_id)

    now = datetime.now(timezone.utc).isoformat()
    shipping_info = {
        **info,
        "carrier": "Canada Post",
        "tracking_number": res["pin"],
        "label_url": label_url,
        "cp_shipment_id": res["shipment_id"],
        # Coût réel de l'étiquette côté transporteur (pas le montant client).
        "cost": await _canada_post_shipment_price(res["shipment_id"], preferred_service_code=payload.service_code),
        "cp_group_id": res["group_id"],
        "cp_transmitted": False,   # tant que False → surcharge de 2 $ encourue
        "service_code": payload.service_code,
        "shipped_at": now,
    }
    await db.orders.update_one(
        {"id": order_id},
        {"$set": {"shipping_info": shipping_info, "fulfillment_status": "shipped"},
         "$push": {"notes": {
             "id": str(uuid.uuid4()),
             "text": f"Étiquette Postes Canada créée — suivi {res['pin']} (lot {res['group_id']}).",
             "author": "system",
             "created_at": now,
         }}},
    )
    fresh = await db.orders.find_one({"id": order_id}, {"_id": 0})
    asyncio.create_task(send_shipping_notification(fresh))
    return {"already_existed": False, "shipping_info": shipping_info}


@api.post("/admin/orders/{order_id}/void-label")
async def admin_void_label(order_id: str, _admin: dict = Depends(require_area("orders", "manage"))):
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")
    info = order.get("shipping_info") or {}
    if info.get("cp_transmitted"):
        raise HTTPException(400, "Label already transmitted to Canada Post — it can no longer be voided.")
    ok = await _canada_post_void(info.get("cp_shipment_id", ""))
    if not ok:
        raise HTTPException(502, "Canada Post refused to void this label")
    await db.orders.update_one(
        {"id": order_id},
        {"$set": {"shipping_info": {"carrier": "", "tracking_number": "", "shipped_at": None},
                  "fulfillment_status": "processing"},
         "$push": {"notes": {
             "id": str(uuid.uuid4()),
             "text": "Étiquette Postes Canada annulée (void).",
             "author": "system",
             "created_at": datetime.now(timezone.utc).isoformat(),
         }}},
    )
    return {"ok": True, "voided": True}


@api.get("/admin/shipping/pending-manifest")
async def admin_pending_manifest(_admin: dict = Depends(require_area("orders", "view"))):
    """Alimente la bannière rouge de l'admin : combien d'étiquettes non transmises."""
    cursor = db.orders.find(
        {"shipping_info.cp_group_id": {"$nin": [None, ""]}, "shipping_info.cp_transmitted": False},
        {"_id": 0, "id": 1, "order_number": 1, "shipping_info": 1},
    )
    pending = await cursor.to_list(2000)
    groups: dict = {}
    for o in pending:
        gid = (o.get("shipping_info") or {}).get("cp_group_id")
        groups.setdefault(gid, 0)
        groups[gid] += 1
    return {
        "configured": is_canada_post_configured(),
        "pending_count": len(pending),
        "groups": [{"group_id": g, "count": c} for g, c in sorted(groups.items())],
    }


@api.get("/admin/shipping/config-status")
async def admin_shipping_config_status(_admin: dict = Depends(require_area("shipping", "view"))):
    """Expose un état lisible de la config Postes Canada (sans secrets)
    pour faciliter le diagnostic côté interface admin."""
    using_openapi = _cp_use_openapi()
    mailed_by, mobo = _cp_path_customers()
    missing_required = []
    if using_openapi:
        if not mailed_by:
            missing_required.append("CANADA_POST_MAILED_BY/CANADA_POST_CUSTOMER_NUMBER")
        if not mobo:
            missing_required.append("CANADA_POST_MOBO/CANADA_POST_CUSTOMER_NUMBER")
        if not CANADA_POST_ORIGIN_POSTAL_CODE:
            missing_required.append("CANADA_POST_ORIGIN_POSTAL_CODE")
        if not CANADA_POST_OAUTH_CLIENT_ID:
            missing_required.append("CANADA_POST_OAUTH_CLIENT_ID")
        if not CANADA_POST_OAUTH_CLIENT_SECRET:
            missing_required.append("CANADA_POST_OAUTH_CLIENT_SECRET")
    else:
        if not CANADA_POST_API_KEY:
            missing_required.append("CANADA_POST_API_KEY")
        if not CANADA_POST_CUSTOMER_NUMBER:
            missing_required.append("CANADA_POST_CUSTOMER_NUMBER")
        if not CANADA_POST_ORIGIN_POSTAL_CODE:
            missing_required.append("CANADA_POST_ORIGIN_POSTAL_CODE")

    return {
        "configured": is_canada_post_configured(),
        "api_mode": CANADA_POST_API_MODE,
        "using_openapi": using_openapi,
        "environment": CANADA_POST_ENVIRONMENT,
        "base_url": CANADA_POST_OPENAPI_BASE_URL if using_openapi else CANADA_POST_BASE_URL,
        "has_legacy_api_key": bool(CANADA_POST_API_KEY),
        "has_customer_number": bool(CANADA_POST_CUSTOMER_NUMBER),
        "has_origin_postal_code": bool(CANADA_POST_ORIGIN_POSTAL_CODE),
        "has_oauth_client_id": bool(CANADA_POST_OAUTH_CLIENT_ID),
        "has_oauth_client_secret": bool(CANADA_POST_OAUTH_CLIENT_SECRET),
        "has_platform_id": bool(CANADA_POST_PLATFORM_ID),
        "has_mailed_by": bool(mailed_by),
        "has_mobo": bool(mobo),
        "missing_required": missing_required,
    }


@api.post("/admin/shipping/backfill-label-costs")
async def admin_backfill_label_costs(limit: int = 300,
                                     force: bool = False,
                                     _admin: dict = Depends(require_area("shipping", "manage"))):
    """Récupère le coût réel des étiquettes existantes via shipment_id.

    - force=False: ne traite que les commandes sans shipping_info.cost
    - force=True: recalcule même si un coût est déjà présent
    """
    if not _cp_use_openapi():
        raise HTTPException(400, "Label cost backfill requires Canada Post OpenAPI mode")

    safe_limit = max(1, min(int(limit or 1), 2000))
    base_filter = {
        "shipping_info.cp_shipment_id": {"$nin": [None, ""]},
    }
    if not force:
        base_filter["$or"] = [
            {"shipping_info.cost": {"$exists": False}},
            {"shipping_info.cost": None},
            {"shipping_info.cost": {}},
        ]

    rows = await db.orders.find(
        base_filter,
        {"_id": 0, "id": 1, "order_number": 1, "shipping_info": 1},
    ).sort("created_at", -1).to_list(safe_limit)

    updated = 0
    unchanged = 0
    failed = []
    for o in rows:
        info = o.get("shipping_info") or {}
        shipment_id = info.get("cp_shipment_id")
        if not shipment_id:
            unchanged += 1
            continue

        try:
            price = await _canada_post_shipment_price(str(shipment_id))
            if not price:
                unchanged += 1
                continue

            await db.orders.update_one(
                {"id": o["id"]},
                {"$set": {"shipping_info.cost": price,
                          "shipping_info.cost_refreshed_at": datetime.now(timezone.utc).isoformat()}},
            )
            updated += 1
        except Exception as ex:
            failed.append({
                "order_id": o.get("id"),
                "order_number": o.get("order_number"),
                "error": str(ex),
            })

    return {
        "ok": True,
        "processed": len(rows),
        "updated": updated,
        "unchanged": unchanged,
        "failed": failed,
        "limit": safe_limit,
        "force": force,
    }


@api.post("/admin/shipping/transmit")
async def admin_transmit_manifest(_admin: dict = Depends(require_area("orders", "manage"))):
    """À faire CHAQUE JOUR. Oublier = 2 $/article de surcharge + perte du rabais."""
    if not is_canada_post_configured():
        raise HTTPException(503, "Canada Post is not configured")
    pending = await db.orders.find(
        {"shipping_info.cp_group_id": {"$nin": [None, ""]}, "shipping_info.cp_transmitted": False},
        {"_id": 0, "id": 1, "shipping_info": 1},
    ).to_list(2000)
    if not pending:
        return {"ok": True, "transmitted_groups": [], "manifests": [], "orders_marked": 0}

    group_ids = sorted({(o["shipping_info"] or {}).get("cp_group_id") for o in pending if (o["shipping_info"] or {}).get("cp_group_id")})
    manifests: list = []
    done_groups: list = []
    for gid in group_ids:
        try:
            hrefs = await _canada_post_transmit(gid)
        except HTTPException:
            logging.error("Transmission du manifeste échouée pour le lot %s", gid)
            continue
        manifests.extend(hrefs)
        done_groups.append(gid)

    marked = 0
    if done_groups:
        res = await db.orders.update_many(
            {"shipping_info.cp_group_id": {"$in": done_groups}, "shipping_info.cp_transmitted": False},
            {"$set": {"shipping_info.cp_transmitted": True,
                      "shipping_info.cp_transmitted_at": datetime.now(timezone.utc).isoformat()}},
        )
        marked = res.modified_count
        # Détails de coût du manifeste : total réellement facturé par Postes
        # Canada pour la journée (rapprochement comptable).
        cost_details = None
        for href in manifests:
            cost_details = await _canada_post_manifest_details(href)
            if cost_details:
                break
        await db.manifests.insert_one({
            "id": str(uuid.uuid4()),
            "group_ids": done_groups,
            "manifest_links": manifests,
            "cost": cost_details,
            # Date du lot (TZ cutoff) : permet de retrouver le manifeste du jour.
            "dispatch_date": _local_today_iso(),
            "created_at": datetime.now(timezone.utc).isoformat(),
        })

    if not done_groups:
        raise HTTPException(502, "No manifest could be transmitted — check the Canada Post logs.")
    return {"ok": True, "transmitted_groups": done_groups, "manifests": manifests, "orders_marked": marked}


@api.get("/admin/dispatch/{date}/manifest.pdf")
async def admin_dispatch_manifest_pdf(date: str,
                                      _admin: dict = Depends(require_area("orders", "view"))):
    """Manifeste(s) transmis pour la date donnée.
    Priorité: 1) PDF local sauvegardé, 2) hrefs CP en direct, 3) récapitulatif interne."""
    docs = await db.manifests.find({"dispatch_date": date}, {"_id": 0}).sort("created_at", 1).to_list(50)
    if not docs:
        raise HTTPException(404, "Aucun manifeste transmis pour cette date.")

    # 1) PDF déjà téléchargé localement (par retry-manifest)
    for d in docs:
        local_url = d.get("local_pdf_url") or ""
        if local_url and local_url.startswith("/uploads/labels/"):
            fpath = LABEL_UPLOAD_DIR / local_url.split("/")[-1]
            if fpath.exists():
                return Response(
                    content=fpath.read_bytes(),
                    media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="manifeste-{date}.pdf"'},
                )

    # 2) Hrefs CP disponibles — tentative de téléchargement direct
    hrefs = []
    for d in docs:
        for h in (d.get("manifest_links") or []):
            if h and h not in hrefs:
                hrefs.append(h)

    pdfs = []
    for href in hrefs:
        try:
            r = await _cp_openapi_call("GET", href, accept="application/pdf")
            if r.status_code < 400 and r.content:
                pdfs.append(r.content)
        except Exception as ex:  # pragma: no cover
            logging.error("manifest artifact failed (%s): %s", href, ex)

    if pdfs:
        merged = _merge_pdfs(pdfs) if len(pdfs) > 1 else pdfs[0]
        return Response(
            content=merged,
            media_type="application/pdf",
            headers={"Content-Disposition": f'inline; filename="manifeste-{date}.pdf"'},
        )

    # 3) Fallback : récapitulatif interne des commandes du lot
    orders = await db.orders.find(
        {"payment_status": "paid", "dispatch_batch": date,
         "shipping_info.label_url": {"$nin": [None, ""]}},
        {"_id": 0, "order_number": 1, "shipping_info": 1, "shipping_address": 1, "total": 1},
    ).sort("created_at", 1).to_list(500)
    if not orders:
        raise HTTPException(404, "Aucune commande étiquetée pour cette date.")

    lines = [
        f"<h1>Manifeste — lot du {date}</h1>",
        f"<p style='font-size:11px;color:#94A3B8'>Récapitulatif interne — utilisez « Récupérer manifeste CP » pour le document officiel</p>",
        "<table style='width:100%;border-collapse:collapse;font-family:monospace;font-size:11px'>",
        "<tr style='background:#f0f0f0'><th style='padding:4px;border:1px solid #ccc'>Commande</th>"
        "<th style='padding:4px;border:1px solid #ccc'>Destinataire</th>"
        "<th style='padding:4px;border:1px solid #ccc'>Suivi</th>"
        "<th style='padding:4px;border:1px solid #ccc'>Total</th></tr>",
    ]
    total_sum = 0.0
    for o in orders:
        info = o.get("shipping_info") or {}
        addr = o.get("shipping_address") or {}
        dest = f"{addr.get('full_name', '')} — {addr.get('city', '')}, {addr.get('province', '')}"
        pin = info.get("tracking_number", "")
        total = o.get("total") or 0
        total_sum += float(total)
        lines.append(
            f"<tr><td style='padding:4px;border:1px solid #ccc'>{o.get('order_number','')}</td>"
            f"<td style='padding:4px;border:1px solid #ccc'>{dest}</td>"
            f"<td style='padding:4px;border:1px solid #ccc'>{pin}</td>"
            f"<td style='padding:4px;border:1px solid #ccc;text-align:right'>${float(total):.2f}</td></tr>"
        )
    lines += [
        f"<tr style='font-weight:bold'><td colspan='3' style='padding:4px;border:1px solid #ccc;text-align:right'>Total</td>"
        f"<td style='padding:4px;border:1px solid #ccc;text-align:right'>${total_sum:.2f}</td></tr>",
        "</table>",
        f"<p style='font-size:10px;margin-top:12px'>{len(orders)} envoi(s) · Postes Canada — transmis le {date}</p>",
    ]
    html = (
        "<!DOCTYPE html><html><head><meta charset='utf-8'>"
        "<style>body{font-family:sans-serif;margin:24px;color:#111}</style></head>"
        f"<body>{''.join(lines)}</body></html>"
    )
    from weasyprint import HTML as WP
    try:
        pdf_bytes = WP(string=html).write_pdf()
    except Exception:
        return Response(
            content=html.encode("utf-8"),
            media_type="text/html",
            headers={"Content-Disposition": f'inline; filename="manifeste-{date}.html"'},
        )
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="manifeste-{date}.pdf"'},
    )


@api.post("/admin/dispatch/{date}/retry-manifest")
async def admin_retry_manifest(date: str,
                               _admin: dict = Depends(require_area("orders", "manage"))):
    """Récupère le manifeste officiel Postes Canada pour la date donnée.
    Appelle GET /manifests pour lister les vrais hrefs existants, puis
    télécharge le PDF via le flux en 2 étapes (JSON → artifact → PDF).
    N'essaie pas de re-transmettre les lots déjà transmis."""
    if not is_canada_post_configured():
        raise HTTPException(503, "Canada Post is not configured")
    if not _cp_use_openapi():
        raise HTTPException(400, "retry-manifest nécessite le mode OpenAPI")

    mailed_by, mobo = _cp_path_customers()

    # Étape 1: lister les manifests existants via GET /manifests
    try:
        r = await _cp_openapi_call("GET", f"/{mailed_by}/{mobo}/manifests")
    except Exception as ex:
        raise HTTPException(502, f"Impossible de contacter Canada Post: {ex}")
    if r.status_code >= 400:
        raise HTTPException(502, f"Canada Post GET /manifests {r.status_code}: {_cp_error_detail(r)}")

    raw = r.json() if r.headers.get("content-type","").startswith("application/json") else []
    if not isinstance(raw, list):
        raw = []
    manifest_hrefs = [l.get("href") for l in raw
                      if isinstance(l, dict) and l.get("rel") == "manifest" and l.get("href")]
    if not manifest_hrefs:
        # Fallback: essayer aussi les hrefs stockés en base pour cette date
        manifest_doc = await db.manifests.find_one({"dispatch_date": date}, {"_id": 0})
        stored_hrefs = [h for h in (manifest_doc or {}).get("manifest_links", [])
                        if h and "workgroup1" not in h and "0000000001" not in h]
        manifest_hrefs = stored_hrefs

    if not manifest_hrefs:
        raise HTTPException(404, "Aucun manifeste trouvé auprès de Canada Post pour cette date.")

    # Étape 2: télécharger le PDF de chaque manifest et sauvegarder le premier valide
    local_pdf_url: Optional[str] = None
    for href in manifest_hrefs:
        pdf_url = await _canada_post_get_manifest_artifact_openapi(href, date)
        if pdf_url:
            local_pdf_url = pdf_url
            logging.info("Manifest PDF saved for %s: %s", date, pdf_url)
            break

    # Mettre à jour le document manifeste en base
    now = datetime.now(timezone.utc).isoformat()
    group_ids = await db.orders.distinct(
        "shipping_info.cp_group_id",
        {"payment_status": "paid", "dispatch_batch": date,
         "shipping_info.cp_group_id": {"$nin": [None, ""]}}
    )
    await db.manifests.update_one(
        {"dispatch_date": date},
        {"$set": {
            "manifest_links": manifest_hrefs,
            "local_pdf_url": local_pdf_url,
            "refreshed_at": now,
            **({"group_ids": group_ids} if group_ids else {}),
        }},
        upsert=True,
    )

    return {
        "ok": True,
        "date": date,
        "manifest_hrefs": manifest_hrefs,
        "local_pdf_url": local_pdf_url,
        "pdf_source": "cp" if local_pdf_url else "fallback",
    }


@api.get("/admin/dispatch/{date}/manifest-status")
async def admin_dispatch_manifest_status(date: str,
                                         _admin: dict = Depends(require_area("orders", "view"))):
    """Indique si un manifeste a été transmis pour cette date (pilote le bouton
    de téléchargement dans l'écran Dispatch)."""
    count = await db.manifests.count_documents({"dispatch_date": date})
    # Vérifie aussi si le PDF manifeste est déjà sauvegardé localement
    doc = await db.manifests.find_one({"dispatch_date": date}, {"_id": 0})
    local_pdf = (doc or {}).get("local_pdf_url")
    return {"date": date, "transmitted": count > 0, "manifests": count, "local_pdf_url": local_pdf}


# ---------------------------------------------------------------------------
# Dispatch batch — traitement des commandes payées par fenêtre journalière
# (cutoff 13h ET). Modèle ShipStation : on regroupe par dispatch_batch, on
# génère toutes les étiquettes d'un lot en une passe, puis on transmet le
# manifeste une fois par jour (voir /admin/shipping/transmit).
# ---------------------------------------------------------------------------
def _iso_day_shift(day: str, delta: int) -> str:
    """Renvoie la date ISO décalée de <delta> jours (bornes de recherche UTC)."""
    try:
        d = datetime.strptime(day, "%Y-%m-%d").date() + timedelta(days=delta)
        return d.isoformat()
    except Exception:
        return day


def _local_today_iso() -> str:
    """Date locale (ORDER_CUTOFF_TZ) au format YYYY-MM-DD."""
    return datetime.now(ZoneInfo(ORDER_CUTOFF_TZ)).date().isoformat()


class DispatchLabelsIn(BaseModel):
    service_code: str = Field(default="DOM.EP", min_length=1, max_length=40)


@api.get("/admin/dispatch/today")
async def admin_dispatch_today(date: Optional[str] = None,
                               service_code: Optional[str] = None,
                               _admin: dict = Depends(require_area("orders", "view"))):
    """File d'expédition du jour : commandes payées dont le dispatch_batch
    tombe le <date> (défaut = aujourd'hui, TZ cutoff)."""
    day = date or _local_today_iso()
    cursor = db.orders.find(
        {
            "payment_status": "paid",
            "$or": [
                {
                    # File de travail : ce qui reste à traiter pour ce lot.
                    "dispatch_batch": day,
                    "fulfillment_status": {"$in": ["processing", "pending", "packed", "shipped"]},
                },
                {
                    # HISTORIQUE : étiquettes réellement émises ce jour-là.
                    # Indispensable car le report de minuit modifie
                    # dispatch_batch, alors que shipped_at ne bouge jamais.
                    # Fenêtre élargie (J-1 → J+1) car shipped_at est en UTC :
                    # le tri fin par heure locale est fait plus bas.
                    "shipping_info.shipped_at": {"$gte": _iso_day_shift(day, -1),
                                                 "$lte": _iso_day_shift(day, 1) + "T23:59:59"},
                },
            ],
        },
        {"_id": 0},
    ).sort("created_at", 1)
    orders = await cursor.to_list(2000)

    to_label, labeled = [], []
    selected_service = (service_code or CANADA_POST_DEFAULT_SERVICE_CODE or "DOM.EP").strip().upper()
    rate_cache: dict[tuple, Any] = {}

    # Charger les emballages actifs une seule fois pour tout le lot.
    available_boxes = await db.shipping_boxes.find(
        {"deleted_at": None, "active": True}, {"_id": 0}
    ).sort("max_units", 1).to_list(200)

    for o in orders:
        info = o.get("shipping_info") or {}
        cost_due = (info.get("cost") or {}).get("due_amount")
        row = {
            "id": o["id"],
            "order_number": o.get("order_number"),
            "email": o.get("email"),
            "items": len(o.get("items", [])),
            "total": o.get("total"),
            "shipping_charged": o.get("shipping"),
            "city": (o.get("shipping_address") or {}).get("city"),
            "province": (o.get("shipping_address") or {}).get("province"),
            "tracking_number": info.get("tracking_number") or "",
            "label_url": info.get("label_url") or "",
            "cp_transmitted": bool(info.get("cp_transmitted")),
            # Coût réel facturé par Postes Canada pour cette étiquette.
            "cost_due": cost_due,
            "rated_weight_kg": (info.get("cost") or {}).get("rated_weight_kg"),
            # Champ unifié pour affichage ligne par ligne dans Dispatch.
            "line_label_cost": cost_due,
            "line_label_cost_source": "actual_cp" if cost_due is not None else None,
        }
        # « Étiquetées » = étiquettes émises CE JOUR (shipped_at), pas les
        # Critère principal : dispatch_batch == day (lot commandé ce jour).
        # Critère secondaire : shipped_at tombe ce jour en heure locale.
        # Les deux sont valides — évite la perte silencieuse des commandes dont
        # shipped_at est en UTC (ex. 00h32 UTC = veille en heure locale).
        shipped_at = info.get("shipped_at") or ""
        labeled_today = o.get("dispatch_batch") == day  # critère primaire
        if not labeled_today and shipped_at:
            try:
                shipped_dt = datetime.fromisoformat(shipped_at.replace("Z", "+00:00"))
                if shipped_dt.tzinfo is None:
                    shipped_dt = shipped_dt.replace(tzinfo=timezone.utc)
                labeled_today = shipped_dt.astimezone(ZoneInfo(ORDER_CUTOFF_TZ)).date().isoformat() == day
            except Exception:
                labeled_today = shipped_at.startswith(day)
        if row["label_url"] and row["tracking_number"]:
            if labeled_today:
                labeled.append(row)
        else:
            # Estimation du prix Canada Post (avant création réelle d'étiquette)
            # selon le service sélectionné dans l'écran Dispatch.
            row["estimated_cost_due"] = None
            row["estimated_eta_days"] = None
            if is_canada_post_configured():
                ship = o.get("shipping_address") or {}
                dest_pc = str(ship.get("postal_code") or "").replace(" ", "").upper()
                dest_country = str(ship.get("country") or "CA").upper()
                weight_kg = _order_weight_kg(o)
                if _cp_use_openapi():
                    cache_key = ("openapi", o.get("id"), selected_service)
                    if cache_key not in rate_cache:
                        rate_cache[cache_key] = await _canada_post_estimate_openapi(o, selected_service, weight_kg)
                    chosen = rate_cache.get(cache_key)
                    if chosen is not None:
                        row["estimated_cost_due"] = chosen.get("cost_cad")
                        row["estimated_eta_days"] = chosen.get("eta_days")
                        row["line_label_cost"] = chosen.get("cost_cad")
                        chosen_code = str(chosen.get("service_code") or "").upper()
                        row["line_label_cost_source"] = (
                            "estimated_cp"
                            if (not chosen_code) or (chosen_code == selected_service)
                            else "estimated_cp_alt"
                        )
                else:
                    cache_key = (dest_pc, dest_country, weight_kg)
                    if cache_key not in rate_cache:
                        rate_cache[cache_key] = await _canada_post_get_rates(dest_pc, dest_country, weight_kg)
                    rates = rate_cache.get(cache_key) or []
                    chosen = next((r for r in rates if str(r.get("service_code") or "").upper() == selected_service), None)
                    # Si le service exact n'est pas renvoyé, on prend un devis CP
                    # alternatif plutôt qu'un montant checkout interne.
                    if chosen is None and rates:
                        chosen = rates[0]
                    if chosen is not None:
                        row["estimated_cost_due"] = chosen.get("cost_cad")
                        row["estimated_eta_days"] = chosen.get("eta_days")
                        row["line_label_cost"] = chosen.get("cost_cad")
                        chosen_code = str(chosen.get("service_code") or "").upper()
                        row["line_label_cost_source"] = (
                            "estimated_cp"
                            if chosen_code == selected_service
                            else "estimated_cp_alt"
                        )
            # Emballage sélectionné (auto ou override) pour cette commande.
            chosen_box = await _select_box_for_order(o, all_boxes=available_boxes)
            row["box_id"] = chosen_box.get("id") if chosen_box else None
            row["box_name"] = chosen_box.get("name") if chosen_box else None
            to_label.append(row)

    overdue = await db.orders.count_documents({
        "payment_status": "paid",
        "dispatch_batch": {"$lt": day},
        "fulfillment_status": {"$in": ["processing", "pending"]},
    })
    # Bilan financier du jour (règle métier Dispatch) :
    # - estimated_labels_total: somme des coûts par ligne de commande affichée
    #   dans Dispatch ("à étiqueter" + "étiquetées").
    # - customer_charged_total: somme des frais facturés aux clients (champ shipping de la facture)
    # - gap_total: écart = manifeste total dû - facturé aux clients
    dispatch_lines = [*to_label, *labeled]
    estimated_labels_total = round(
        sum(float(r.get("line_label_cost") or 0) for r in dispatch_lines if r.get("line_label_cost") is not None),
        2,
    )
    customer_charged_total = round(sum(float(r.get("shipping_charged") or 0) for r in labeled), 2)
    manifest_doc = await db.manifests.find_one({"dispatch_date": day}, {"_id": 0}, sort=[("created_at", -1)])
    manifest_total_due = None
    try:
        manifest_total_due = float(((manifest_doc or {}).get("cost") or {}).get("total_due"))
    except Exception:
        manifest_total_due = None
    gap_total = (round(manifest_total_due - customer_charged_total, 2)
                 if manifest_total_due is not None else None)
    return {
        "date": day,
        "configured": is_canada_post_configured(),
        "totals": {
            "labels_cost": estimated_labels_total,
            "shipping_charged": round(sum(float(r.get("cost_due") or 0) for r in labeled), 2),
            "customer_shipping_charged": customer_charged_total,
            "margin": gap_total,
            "manifest": (manifest_doc or {}).get("cost"),
        },
        "counts": {"to_label": len(to_label), "labeled": len(labeled), "overdue": overdue},
        "to_label": to_label,
        "labeled": labeled,
        "available_boxes": [
            {"id": b.get("id"), "name": b.get("name"), "max_units": b.get("max_units"),
             "tare_grams": b.get("tare_grams"), "length_cm": b.get("length_cm"),
             "width_cm": b.get("width_cm"), "height_cm": b.get("height_cm")}
            for b in available_boxes
        ],
    }


class OrderShippingBoxIn(BaseModel):
    box_id: Optional[str] = None  # None = réinitialiser à la sélection automatique


@api.patch("/admin/orders/{order_id}/shipping-box")
async def admin_order_set_shipping_box(
    order_id: str,
    payload: OrderShippingBoxIn,
    _admin: dict = Depends(require_area("orders", "manage")),
):
    """Définit (ou réinitialise) l'emballage d'une commande en vue de l'étiquetage."""
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")

    if payload.box_id:
        box = await db.shipping_boxes.find_one({"id": payload.box_id, "active": True, "deleted_at": None}, {"_id": 0})
        if not box:
            raise HTTPException(404, "Packaging not found or inactive")
        await db.orders.update_one({"id": order_id}, {"$set": {"shipping_box_override_id": payload.box_id}})
        return {"order_id": order_id, "box_id": payload.box_id, "box_name": box.get("name")}
    else:
        await db.orders.update_one({"id": order_id}, {"$unset": {"shipping_box_override_id": ""}})
        return {"order_id": order_id, "box_id": None, "box_name": None}


@api.post("/admin/orders/{order_id}/dispatch/refresh-estimate")
async def admin_order_refresh_dispatch_estimate(
    order_id: str,
    service_code: Optional[str] = None,
    _admin: dict = Depends(require_area("orders", "view")),
):
    """Recalcule l'estimation CP d'une ligne Dispatch avec le poids produits + tare emballage."""
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")

    selected_service = (service_code or CANADA_POST_DEFAULT_SERVICE_CODE or "DOM.EP").strip().upper()
    chosen_box = await _select_box_for_order(order)
    products_weight_kg = _order_weight_kg(order)
    box_tare_kg = round(float((chosen_box or {}).get("tare_grams") or 0.0) / 1000.0, 3)
    total_weight_kg = max(0.1, round(products_weight_kg + box_tare_kg, 3))

    out = {
        "order_id": order_id,
        "service_requested": selected_service,
        "line_label_cost": None,
        "line_label_cost_source": None,
        "estimated_cost_due": None,
        "estimated_eta_days": None,
        "box_id": (chosen_box or {}).get("id"),
        "box_name": (chosen_box or {}).get("name"),
        "products_weight_kg": products_weight_kg,
        "box_tare_kg": box_tare_kg,
        "packaged_weight_kg": total_weight_kg,
    }

    if not is_canada_post_configured():
        return out

    ship = order.get("shipping_address") or {}
    dest_pc = str(ship.get("postal_code") or "").replace(" ", "").upper()
    dest_country = str(ship.get("country") or "CA").upper()

    if _cp_use_openapi():
        chosen = await _canada_post_estimate_openapi(order, selected_service, products_weight_kg)
    else:
        rates = await _canada_post_get_rates(dest_pc, dest_country, total_weight_kg)
        chosen = next((r for r in rates if str(r.get("service_code") or "").upper() == selected_service), None)
        if chosen is None and rates:
            chosen = rates[0]

    if chosen is None:
        return out

    out["estimated_cost_due"] = chosen.get("cost_cad")
    out["estimated_eta_days"] = chosen.get("eta_days")
    out["line_label_cost"] = chosen.get("cost_cad")
    chosen_code = str(chosen.get("service_code") or "").upper()
    out["line_label_cost_source"] = "estimated_cp" if (not chosen_code) or (chosen_code == selected_service) else "estimated_cp_alt"
    return out


@api.post("/admin/dispatch/{date}/labels")
async def admin_dispatch_labels(date: str, payload: DispatchLabelsIn,
                                _admin: dict = Depends(require_area("orders", "manage"))):
    """Génère en une passe les étiquettes des commandes payées du lot <date>
    qui n'en ont pas encore. Idempotent : commande déjà étiquetée = sautée."""
    if not is_canada_post_configured():
        raise HTTPException(503, "Canada Post is not configured")

    orders = await db.orders.find(
        {
            "payment_status": "paid",
            "dispatch_batch": date,
            "fulfillment_status": {"$in": ["processing", "pending", "packed"]},
        },
        {"_id": 0},
    ).sort("created_at", 1).to_list(2000)

    created, skipped, failed = [], [], []
    for order in orders:
        info = order.get("shipping_info") or {}
        if info.get("label_url") and info.get("tracking_number"):
            skipped.append({"order_number": order.get("order_number"),
                            "tracking_number": info["tracking_number"],
                            "label_url": info["label_url"]})
            continue
        try:
            res = await _canada_post_create_shipment(order, payload.service_code, _order_weight_kg(order))
            label_url = await _canada_post_get_artifact(res["label_href"], order["id"])
            now = datetime.now(timezone.utc).isoformat()
            shipping_info = {
                **info,
                "carrier": "Canada Post",
                "tracking_number": res["pin"],
                "label_url": label_url,
                "cp_shipment_id": res["shipment_id"],
                "cost": await _canada_post_shipment_price(res["shipment_id"], preferred_service_code=payload.service_code),
                "cp_group_id": res["group_id"],
                "cp_transmitted": False,
                "service_code": payload.service_code,
                "shipped_at": now,
            }
            await db.orders.update_one(
                {"id": order["id"]},
                {"$set": {"shipping_info": shipping_info, "fulfillment_status": "shipped"},
                 "$push": {"notes": {
                     "id": str(uuid.uuid4()),
                     "text": f"Étiquette Postes Canada créée (lot {date}) — suivi {res['pin']}.",
                     "author": "system",
                     "created_at": now,
                 }}},
            )
            fresh = await db.orders.find_one({"id": order["id"]}, {"_id": 0})
            asyncio.create_task(send_shipping_notification(fresh))
            created.append({"order_number": order.get("order_number"),
                            "tracking_number": res["pin"],
                            "label_url": label_url})
        except HTTPException as ex:
            failed.append({"order_number": order.get("order_number"), "error": ex.detail})
        except Exception as ex:
            logging.error("[dispatch] label failed for %s: %s", order.get("order_number"), ex)
            failed.append({"order_number": order.get("order_number"), "error": str(ex)})

    all_labels = [c["label_url"] for c in created] + [s["label_url"] for s in skipped]
    return {
        "date": date,
        "created": created,
        "skipped": skipped,
        "failed": failed,
        "label_urls": all_labels,
        "counts": {"created": len(created), "skipped": len(skipped), "failed": len(failed)},
    }


def _merge_pdfs(pdf_bytes_list: list) -> bytes:
    """Fusionne plusieurs PDF en un seul. Requiert pypdf."""
    from pypdf import PdfWriter, PdfReader
    import io
    writer = PdfWriter()
    for b in pdf_bytes_list:
        if not b:
            continue
        reader = PdfReader(io.BytesIO(b))
        for page in reader.pages:
            writer.add_page(page)
    out = io.BytesIO()
    writer.write(out)
    return out.getvalue()


async def _dispatch_labeled_orders(date: str) -> list:
    """Commandes du lot <date> déjà étiquetées (label_url présent), triées."""
    return await db.orders.find(
        {
            "payment_status": "paid",
            "dispatch_batch": date,
            "shipping_info.label_url": {"$nin": [None, ""]},
        },
        {"_id": 0},
    ).sort("created_at", 1).to_list(2000)


@api.get("/admin/dispatch/{date}/labels.pdf")
async def admin_dispatch_labels_pdf(date: str, _admin: dict = Depends(require_area("orders", "view"))):
    """Toutes les étiquettes du lot fusionnées en UN pdf 4x6 (imprimante thermique)."""
    orders = await _dispatch_labeled_orders(date)
    pdfs = []
    for o in orders:
        url = (o.get("shipping_info") or {}).get("label_url") or ""
        if url.startswith("/uploads/labels/"):
            fpath = LABEL_UPLOAD_DIR / url.split("/")[-1]
            if fpath.exists():
                pdfs.append(fpath.read_bytes())
    if not pdfs:
        raise HTTPException(404, "Aucune étiquette pour ce lot.")
    merged = _merge_pdfs(pdfs)
    return Response(
        content=merged,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="etiquettes-{date}.pdf"'},
    )


@api.get("/admin/dispatch/{date}/packing-slips.pdf")
async def admin_dispatch_slips_pdf(date: str, _admin: dict = Depends(require_area("orders", "view"))):
    """Tous les bons de commande du lot fusionnés en UN pdf (imprimante papier)."""
    orders = await _dispatch_labeled_orders(date)
    pdfs = [_generate_invoice_pdf(o) for o in orders]
    pdfs = [p for p in pdfs if p]
    if not pdfs:
        raise HTTPException(404, "Aucun bon de commande pour ce lot.")
    merged = _merge_pdfs(pdfs)
    return Response(
        content=merged,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="bons-{date}.pdf"'},
    )


# ===========================================================================
# POSTE D'EXPÉDITION « FIRONOVA FULFILLMENT » — Phase 1 (v2, amélioré)
#   payé → processing (à préparer) → packing → packed → shipped (étiqueté)
# Améliorations v2 :
#  - capte aussi les commandes payées SANS dispatch_batch (rétro-remplissage
#    à la volée) : plus de commande « fantôme » invisible dans Journée ;
#  - avance groupée d'une colonne entière ;
#  - retards remontés en tête de colonne.
# ===========================================================================
FULFILLMENT_FLOW = ["processing", "packing", "packed", "shipped", "delivered"]
FULFILLMENT_LABELS = {
    "processing": {"fr": "À préparer", "en": "To prepare"},
    "packing":    {"fr": "En préparation", "en": "Preparing"},
    "packed":     {"fr": "Empaquetée", "en": "Packed"},
    "shipped":    {"fr": "Étiquetée", "en": "Labeled"},
    "delivered":  {"fr": "Livrée", "en": "Delivered"},
}


class FulfillmentTransitionIn(BaseModel):
    to: str = Field(min_length=1)


class FulfillmentBulkIn(BaseModel):
    date: str = Field(min_length=1)
    from_status: str = Field(min_length=1)
    to: str = Field(min_length=1)


def _order_items(order: dict) -> list:
    """Articles d'une commande. Les commandes sont stockées avec la clé
    "items" ; on accepte aussi "line_items" par compatibilité."""
    return order.get("items") or order.get("line_items") or []


def _picking_lines(order: dict) -> list:
    out = []
    for it in _order_items(order):
        out.append({
            "sku": it.get("sku") or "",
            "slug": it.get("slug") or "",
            "name_en": it.get("name_en") or "",
            "name_fr": it.get("name_fr") or "",
            "variant_name": it.get("variant_name") or "",
            "qty": int(it.get("qty") or 1),
        })
    return out


async def _fulfillment_backfill_batches(day: str) -> None:
    """Répare les commandes payées sans dispatch_batch (créées avant la logique
    de lot, ou par un flux qui ne l'a pas posé). Sans ça elles restent
    invisibles dans Journée."""
    cursor = db.orders.find(
        {
            "payment_status": "paid",
            "fulfillment_status": {"$in": ["processing", "packing", "packed"]},
            "$or": [{"dispatch_batch": {"$in": [None, ""]}}, {"dispatch_batch": {"$exists": False}}],
        },
        {"_id": 0, "id": 1, "paid_at": 1, "created_at": 1},
    )
    async for o in cursor:
        ref = o.get("paid_at") or o.get("created_at") or datetime.now(timezone.utc).isoformat()
        try:
            batch = compute_dispatch_batch(ref)
        except Exception:
            batch = day
        await db.orders.update_one({"id": o["id"]}, {"$set": {"dispatch_batch": batch}})


@api.get("/admin/fulfillment/day")
async def admin_fulfillment_day(date: Optional[str] = None,
                                _admin: dict = Depends(require_area("orders", "view"))):
    """Tableau de bord « Journée » : lot du jour ventilé par étape physique."""
    def _is_local_day(ts: str, target_day: str) -> bool:
        if not ts:
            return False
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(ZoneInfo(ORDER_CUTOFF_TZ)).date().isoformat() == target_day
        except Exception:
            return ts.startswith(target_day)

    day = date or _local_today_iso()
    await _fulfillment_backfill_batches(day)

    # Étapes en cours : on inclut les retards (<= jour) pour ne rien perdre.
    # Historique journalier : bornes calculées dans le fuseau local métier,
    # puis converties en UTC pour interroger les timestamps stockés.
    local_tz = ZoneInfo(ORDER_CUTOFF_TZ)
    day_local_start = datetime.fromisoformat(day).replace(tzinfo=local_tz)
    day_local_end = day_local_start + timedelta(days=1)
    day_start_utc = day_local_start.astimezone(timezone.utc).isoformat()
    day_end_utc = day_local_end.astimezone(timezone.utc).isoformat()
    orders = await db.orders.find(
        {
            "payment_status": "paid",
            "$or": [
                {
                    # À préparer / en préparation : retards inclus pour qu'une
                    # commande oubliée ne disparaisse jamais de l'écran.
                    "dispatch_batch": {"$lte": day},
                    "fulfillment_status": {"$in": ["processing", "packing"]},
                },
                {
                    # Empaquetée : historique du jour. On se base sur packed_at
                    # (et non sur le statut) pour que la commande RESTE visible
                    # même après l'émission de son étiquette dans Dispatch.
                    "packed_at": {"$gte": day_start_utc, "$lt": day_end_utc},
                },
                {
                    # Commandes étiquetées ce jour dans Dispatch (même logique
                    # métier que l'écran Dispatch pour éviter les écarts de
                    # comptage entre les deux vues).
                    "dispatch_batch": day,
                    "fulfillment_status": "shipped",
                    "shipping_info.label_url": {"$nin": [None, ""]},
                    "shipping_info.tracking_number": {"$nin": [None, ""]},
                    "shipping_info.shipped_at": {"$gte": day_start_utc, "$lt": day_end_utc},
                },
            ],
        },
        {"_id": 0},
    ).sort("created_at", 1).to_list(3000)

    buckets = {"processing": [], "packing": [], "packed": []}
    for o in orders:
        st = o.get("fulfillment_status")
        info = o.get("shipping_info") or {}
        has_label = bool(info.get("label_url") and info.get("tracking_number"))
        packed_today = _is_local_day(o.get("packed_at") or "", day)
        labeled_today = has_label and _is_local_day(info.get("shipped_at") or "", day)
        # Une commande empaquetée aujourd'hui reste dans « Empaquetée » même
        # une fois étiquetée (shipped) : c'est l'historique de la journée.
        if packed_today or labeled_today:
            st = "packed"
        if st not in buckets:
            continue
        addr = o.get("shipping_address") or {}
        buckets[st].append({
            "id": o["id"],
            "order_number": o.get("order_number"),
            "email": o.get("email"),
            "created_at": o.get("created_at"),
            "dispatch_batch": o.get("dispatch_batch"),
            "units": sum(int(i.get("qty") or 1) for i in _order_items(o)),
            "items": len(_order_items(o)),
            "total": o.get("total"),
            "city": addr.get("city"),
            "province": addr.get("province"),
            "tracking_number": info.get("tracking_number") or "",
            "label_url": info.get("label_url") or "",
            "picking": _picking_lines(o),
            "is_overdue": bool(o.get("dispatch_batch") and o["dispatch_batch"] < day),
        })

    # Retards en tête de chaque colonne.
    for k in buckets:
        buckets[k].sort(key=lambda r: (not r["is_overdue"], r["created_at"] or ""))

    counts = {k: len(v) for k, v in buckets.items()}
    counts["total"] = sum(counts.values())
    counts["overdue"] = sum(1 for k in buckets for r in buckets[k] if r["is_overdue"])
    return {
        "date": day,
        "configured": is_canada_post_configured(),
        "labels": {k: FULFILLMENT_LABELS[k] for k in buckets},
        "counts": counts,
        "buckets": buckets,
    }


async def _advance_one(order: dict, target: str, admin_email: str) -> None:
    now = datetime.now(timezone.utc).isoformat()
    ts_field = {"packing": "packing_at", "packed": "packed_at"}.get(target)
    update = {"fulfillment_status": target}
    if ts_field:
        update[ts_field] = now
    await db.orders.update_one(
        {"id": order["id"]},
        {"$set": update,
         "$push": {"notes": {
             "id": str(uuid.uuid4()),
             "text": f"Préparation : {FULFILLMENT_LABELS.get(target, {}).get('fr', target)}.",
             "author": admin_email,
             "created_at": now,
         }}},
    )


@api.post("/admin/fulfillment/{order_id}/advance")
async def admin_fulfillment_advance(order_id: str, payload: FulfillmentTransitionIn,
                                    _admin: dict = Depends(require_area("orders", "manage"))):
    """Fait avancer une commande dans le flux physique (jusqu'à empaquetée)."""
    target = payload.to
    if target not in {"processing", "packing", "packed"}:
        raise HTTPException(400, "Étape gérée par l'étiquetage (Dispatch), pas ici.")
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Commande introuvable")
    if order.get("payment_status") != "paid":
        raise HTTPException(400, "La commande doit être payée avant préparation.")
    await _advance_one(order, target, _admin.get("email", "system"))
    return await db.orders.find_one({"id": order_id}, {"_id": 0})


@api.post("/admin/fulfillment/bulk-advance")
async def admin_fulfillment_bulk(payload: FulfillmentBulkIn,
                                 _admin: dict = Depends(require_area("orders", "manage"))):
    """Avance TOUTES les commandes d'une colonne (ex. tout passer « en
    préparation » d'un coup)."""
    if payload.to not in {"packing", "packed"}:
        raise HTTPException(400, "Cible invalide.")
    orders = await db.orders.find(
        {
            "payment_status": "paid",
            "dispatch_batch": {"$lte": payload.date},
            "fulfillment_status": payload.from_status,
        },
        {"_id": 0},
    ).to_list(3000)
    for o in orders:
        await _advance_one(o, payload.to, _admin.get("email", "system"))
    return {"advanced": len(orders), "to": payload.to}


@api.get("/admin/fulfillment/{date}/picking-list.pdf")
async def admin_fulfillment_picking_pdf(date: str,
                                        _admin: dict = Depends(require_area("orders", "view"))):
    """Liste de prélèvement consolidée : total par article à sortir du stock."""
    orders = await db.orders.find(
        {
            "payment_status": "paid",
            "dispatch_batch": {"$lte": date},
            "fulfillment_status": {"$in": ["processing", "packing"]},
        },
        {"_id": 0},
    ).sort("created_at", 1).to_list(3000)

    totals: dict = {}
    for o in orders:
        for it in _order_items(o):
            key = (it.get("sku") or it.get("slug") or "?", it.get("variant_name") or "")
            if key not in totals:
                totals[key] = {"sku": it.get("sku") or "",
                               "name": it.get("name_fr") or it.get("name_en") or it.get("slug") or "",
                               "variant_name": it.get("variant_name") or "", "qty": 0}
            totals[key]["qty"] += int(it.get("qty") or 1)
    if not totals:
        raise HTTPException(404, "Aucune commande à préparer pour ce lot.")

    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas as _canvas
    import io as _io
    buf = _io.BytesIO()
    c = _canvas.Canvas(buf, pagesize=letter)
    w, h = letter
    y = h - 60
    c.setFont("Helvetica-Bold", 16); c.drawString(50, y, f"Liste de prélèvement — lot {date}")
    c.setFont("Helvetica", 9); y -= 18
    c.drawString(50, y, "FIRONOVA · FOR LABORATORY RESEARCH USE ONLY · 19+"); y -= 30
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "Qté"); c.drawString(90, y, "SKU"); c.drawString(220, y, "Produit"); y -= 6
    c.line(50, y, w - 50, y); y -= 18
    c.setFont("Helvetica", 10)
    for row in sorted(totals.values(), key=lambda r: r["name"]):
        if y < 60:
            c.showPage(); y = h - 60; c.setFont("Helvetica", 10)
        label = row["name"] + (f" — {row['variant_name']}" if row["variant_name"] else "")
        c.drawString(50, y, f"{row['qty']}×"); c.drawString(90, y, (row["sku"] or "")[:22])
        c.drawString(220, y, label[:60]); y -= 18
    c.showPage(); c.save(); buf.seek(0)
    return Response(content=buf.getvalue(), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="prelevement-{date}.pdf"'})


# ---------------------------------------------------------------------------
# Report des étiquettes non imprimées + signaux de navigation
# ---------------------------------------------------------------------------
@api.post("/admin/dispatch/{date}/mark-printed")
async def admin_dispatch_mark_printed(date: str,
                                      _admin: dict = Depends(require_area("orders", "manage"))):
    """Marque les étiquettes du lot comme imprimées. Une étiquette imprimée
    n'est plus reportée au lendemain par le report de minuit."""
    now = datetime.now(timezone.utc).isoformat()
    res = await db.orders.update_many(
        {
            "payment_status": "paid",
            "dispatch_batch": date,
            "shipping_info.label_url": {"$nin": [None, ""]},
        },
        {"$set": {"shipping_info.label_printed_at": now}},
    )
    return {"ok": True, "marked": res.modified_count, "date": date}


async def _rollover_unprinted_labels() -> int:
    """Reporte au prochain jour ouvrable les commandes d'un lot passé dont
    l'étiquette n'a pas été imprimée. Évite qu'un lot oublié disparaisse."""
    today = _local_today_iso()
    cursor = db.orders.find(
        {
            "payment_status": "paid",
            "dispatch_batch": {"$lt": today},
            "fulfillment_status": {"$in": ["processing", "pending", "packing", "packed", "shipped"]},
            "$or": [
                {"shipping_info.label_printed_at": {"$in": [None, ""]}},
                {"shipping_info.label_printed_at": {"$exists": False}},
            ],
        },
        {"_id": 0, "id": 1, "order_number": 1},
    )
    moved = 0
    async for o in cursor:
        await db.orders.update_one(
            {"id": o["id"]},
            {"$set": {"dispatch_batch": today},
             "$push": {"notes": {
                 "id": str(uuid.uuid4()),
                 "text": f"Reportée au lot {today} — étiquette non imprimée.",
                 "author": "system",
                 "created_at": datetime.now(timezone.utc).isoformat(),
             }}},
        )
        moved += 1
    if moved:
        logging.info("[rollover] %d commande(s) reportée(s) au lot %s", moved, today)
    return moved


async def _rollover_watchdog() -> None:
    """Passe une fois par heure : à la première exécution après minuit, les
    lots non imprimés de la veille basculent sur le jour courant."""
    last_day = None
    while True:
        try:
            today = _local_today_iso()
            if last_day != today:
                await _rollover_unprinted_labels()
                last_day = today
        except Exception as ex:  # pragma: no cover
            logging.error("rollover watchdog failed: %s", ex)
        await asyncio.sleep(3600)


@api.get("/admin/ops/signals")
async def admin_ops_signals(_admin: dict = Depends(require_area("orders", "view"))):
    """Compteurs pour les pastilles de navigation (Journée / Dispatch) et
    l'alerte manifeste du tableau de bord."""
    day = _local_today_iso()
    to_prepare = await db.orders.count_documents({
        "payment_status": "paid",
        "dispatch_batch": {"$lte": day},
        "fulfillment_status": {"$in": ["processing", "packing"]},
    })
    to_label = await db.orders.count_documents({
        "payment_status": "paid",
        "dispatch_batch": day,
        "fulfillment_status": {"$in": ["processing", "pending", "packed"]},
        "$or": [
            {"shipping_info.label_url": {"$in": [None, ""]}},
            {"shipping_info.label_url": {"$exists": False}},
        ],
    })
    to_print = await db.orders.count_documents({
        "payment_status": "paid",
        "dispatch_batch": day,
        "shipping_info.label_url": {"$nin": [None, ""]},
        "$or": [
            {"shipping_info.label_printed_at": {"$in": [None, ""]}},
            {"shipping_info.label_printed_at": {"$exists": False}},
        ],
    })
    pending_manifest = await db.orders.count_documents({
        "shipping_info.label_url": {"$nin": [None, ""]},
        "shipping_info.cp_transmitted": {"$ne": True},
    })
    # Retards : lots antérieurs encore non expédiés.
    overdue = await db.orders.count_documents({
        "payment_status": "paid",
        "dispatch_batch": {"$lt": day},
        "fulfillment_status": {"$in": ["processing", "pending", "packing", "packed"]},
    })
    return {
        "date": day,
        "fulfillment": to_prepare,
        # Le badge Dispatch signale ce qui reste À ÉTIQUETER (+ retards),
        # pas les étiquettes déjà créées en attente d'impression.
        "dispatch": to_label + overdue,
        "overdue": overdue,
        "to_label": to_label,
        "to_print": to_print,
        "pending_manifest": pending_manifest,
    }


@api.put("/admin/products/{product_id}/stock")
async def admin_adjust_stock(product_id: str, payload: StockAdjustIn, _admin: dict = Depends(require_area("products", "manage"))):
    res = await db.products.update_one({"id": product_id}, {"$inc": {"stock": payload.delta}})
    if res.matched_count == 0:
        raise HTTPException(404, "Product not found")
    if payload.delta > 0:
        asyncio.create_task(_maybe_notify_restock(product_id, None))
    return await db.products.find_one({"id": product_id}, {"_id": 0})


@api.get("/admin/stock-notifications")
async def admin_list_stock_notifications(_admin: dict = Depends(require_area("products", "view"))):
    """Overview of pending back-in-stock subscriptions, grouped implicitly by product/variant."""
    pending = await db.stock_notifications.find({"notified": False}, {"_id": 0}).sort("created_at", -1).to_list(2000)
    return pending


# ---------------------------------------------------------------------------
# Admin — coupons
# ---------------------------------------------------------------------------
@api.get("/admin/coupons")
async def admin_list_coupons(_admin: dict = Depends(require_area("coupons", "view"))):
    return await db.coupons.find({"deleted_at": None}, {"_id": 0}).sort("created_at", -1).to_list(500)


@api.post("/admin/coupons")
async def admin_create_coupon(payload: CouponIn, _admin: dict = Depends(require_area("coupons", "manage"))):
    code = payload.code.upper().strip()
    if await db.coupons.find_one({"code": code}):
        raise HTTPException(409, "Coupon code already exists")
    doc = {
        "id": str(uuid.uuid4()),
        "code": code,
        "discount_type": payload.discount_type,
        "value": payload.value,
        "min_subtotal": payload.min_subtotal,
        "usage_limit": payload.usage_limit,
        "used_count": 0,
        "active": payload.active,
        "expires_at": payload.expires_at,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    await db.coupons.insert_one(doc)
    doc.pop("_id", None)
    return doc


@api.put("/admin/coupons/{coupon_id}")
async def admin_update_coupon(coupon_id: str, payload: CouponIn, _admin: dict = Depends(require_area("coupons", "manage"))):
    update = payload.model_dump()
    update["code"] = update["code"].upper().strip()
    res = await db.coupons.update_one({"id": coupon_id}, {"$set": update})
    if res.matched_count == 0:
        raise HTTPException(404, "Coupon not found")
    return await db.coupons.find_one({"id": coupon_id}, {"_id": 0})


@api.delete("/admin/coupons/{coupon_id}")
async def admin_delete_coupon(coupon_id: str, admin: dict = Depends(require_area("coupons", "manage"))):
    return await _soft_delete("coupons", coupon_id, admin)


@api.post("/coupons/validate")
async def validate_coupon(code: str, subtotal: float):
    coupon = await db.coupons.find_one({"code": code.upper().strip()}, {"_id": 0})
    if not coupon or not coupon.get("active"):
        raise HTTPException(400, "Invalid coupon code")
    if coupon.get("expires_at"):
        try:
            if datetime.fromisoformat(coupon["expires_at"].replace("Z", "+00:00")) < datetime.now(timezone.utc):
                raise HTTPException(400, "Coupon expired")
        except ValueError:
            pass
    if coupon.get("usage_limit") and coupon.get("used_count", 0) >= coupon["usage_limit"]:
        raise HTTPException(400, "Coupon usage limit reached")
    if subtotal < coupon.get("min_subtotal", 0):
        raise HTTPException(400, f"Minimum subtotal of ${coupon['min_subtotal']:.2f} required")
    if coupon["discount_type"] == "percent":
        discount = round(subtotal * (coupon["value"] / 100.0), 2)
    else:
        discount = round(min(coupon["value"], subtotal), 2)
    return {"code": coupon["code"], "discount_type": coupon["discount_type"],
            "value": coupon["value"], "discount_amount": discount, "min_subtotal": coupon.get("min_subtotal", 0)}


# ---------------------------------------------------------------------------
# Admin — shipping zones & methods
# ---------------------------------------------------------------------------
@api.get("/admin/shipping/zones")
async def admin_list_zones(_admin: dict = Depends(require_area("shipping", "view"))):
    zones = await db.shipping_zones.find({"deleted_at": None}, {"_id": 0}).sort("name", 1).to_list(200)
    # attach methods
    out = []
    for z in zones:
        methods = await db.shipping_methods.find({"zone_id": z["id"], "deleted_at": None}, {"_id": 0}).to_list(200)
        z["methods"] = methods
        out.append(z)
    return out


@api.post("/admin/shipping/zones")
async def admin_create_zone(payload: ShippingZoneIn, _admin: dict = Depends(require_area("shipping", "manage"))):
    doc = payload.model_dump()
    doc["id"] = str(uuid.uuid4())
    doc["created_at"] = datetime.now(timezone.utc).isoformat()
    await db.shipping_zones.insert_one(doc)
    doc.pop("_id", None)
    return doc


@api.put("/admin/shipping/zones/{zone_id}")
async def admin_update_zone(zone_id: str, payload: ShippingZoneIn, _admin: dict = Depends(require_area("shipping", "manage"))):
    res = await db.shipping_zones.update_one({"id": zone_id}, {"$set": payload.model_dump()})
    if res.matched_count == 0:
        raise HTTPException(404, "Zone not found")
    return await db.shipping_zones.find_one({"id": zone_id}, {"_id": 0})


@api.delete("/admin/shipping/zones/{zone_id}")
async def admin_delete_zone(zone_id: str, admin: dict = Depends(require_area("shipping", "manage"))):
    # Cascade : les méthodes de cette zone vont aussi en corbeille, pour
    # pouvoir tout restaurer ensemble si la suppression était une erreur.
    methods = await db.shipping_methods.find({"zone_id": zone_id, "deleted_at": None}, {"_id": 0}).to_list(200)
    for m in methods:
        await _soft_delete("shipping_methods", m["id"], admin)
    return await _soft_delete("shipping_zones", zone_id, admin)


@api.post("/admin/shipping/methods")
async def admin_create_method(payload: ShippingMethodIn, _admin: dict = Depends(require_area("shipping", "manage"))):
    doc = payload.model_dump()
    doc["id"] = str(uuid.uuid4())
    doc["created_at"] = datetime.now(timezone.utc).isoformat()
    await db.shipping_methods.insert_one(doc)
    doc.pop("_id", None)
    return doc


@api.put("/admin/shipping/methods/{method_id}")
async def admin_update_method(method_id: str, payload: ShippingMethodIn, _admin: dict = Depends(require_area("shipping", "manage"))):
    res = await db.shipping_methods.update_one({"id": method_id}, {"$set": payload.model_dump()})
    if res.matched_count == 0:
        raise HTTPException(404, "Method not found")
    return await db.shipping_methods.find_one({"id": method_id}, {"_id": 0})


@api.delete("/admin/shipping/methods/{method_id}")
async def admin_delete_method(method_id: str, admin: dict = Depends(require_area("shipping", "manage"))):
    return await _soft_delete("shipping_methods", method_id, admin)


# ---------------------------------------------------------------------------
# Contenants d'expédition (enveloppes / boîtes) configurables depuis l'admin.
# Chaque contenant a des dimensions (cm), un poids à vide (tare, g) et une
# capacité max en nombre d'unités. Le calcul de colis choisit le plus petit
# contenant dont la capacité >= nombre total d'unités de la commande, ajoute
# sa tare au poids des produits, et transmet ses dimensions à Canada Post
# (nécessaire pour le poids volumétrique).
# ---------------------------------------------------------------------------
class ShippingBoxIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)      # ex. "Enveloppe à bulles"
    length_cm: float = Field(gt=0)
    width_cm: float = Field(gt=0)
    height_cm: float = Field(default=2.0, gt=0)          # épaisseur (enveloppe ~2 cm)
    tare_grams: float = Field(default=20.0, ge=0)        # poids à vide du contenant
    max_units: int = Field(default=10, ge=1)             # capacité en nombre d'articles
    active: bool = True


@api.get("/admin/shipping/boxes")
async def admin_list_boxes(_admin: dict = Depends(require_area("shipping", "view"))):
    return await db.shipping_boxes.find({"deleted_at": None}, {"_id": 0}).sort("max_units", 1).to_list(200)


@api.post("/admin/shipping/boxes")
async def admin_create_box(payload: ShippingBoxIn, _admin: dict = Depends(require_area("shipping", "manage"))):
    doc = payload.model_dump()
    doc["id"] = str(uuid.uuid4())
    doc["created_at"] = datetime.now(timezone.utc).isoformat()
    doc["deleted_at"] = None
    await db.shipping_boxes.insert_one(doc)
    doc.pop("_id", None)
    return doc


@api.put("/admin/shipping/boxes/{box_id}")
async def admin_update_box(box_id: str, payload: ShippingBoxIn, _admin: dict = Depends(require_area("shipping", "manage"))):
    res = await db.shipping_boxes.update_one({"id": box_id}, {"$set": payload.model_dump()})
    if res.matched_count == 0:
        raise HTTPException(404, "Box not found")
    return await db.shipping_boxes.find_one({"id": box_id}, {"_id": 0})


@api.delete("/admin/shipping/boxes/{box_id}")
async def admin_delete_box(box_id: str, admin: dict = Depends(require_area("shipping", "manage"))):
    return await _soft_delete("shipping_boxes", box_id, admin)


async def _select_box_for_order(order: dict, all_boxes: Optional[list] = None) -> Optional[dict]:
    """Plus petit contenant actif dont la capacité >= nb total d'unités.
    Si shipping_box_override_id est défini sur la commande, on l'utilise en priorité."""
    boxes = all_boxes
    if boxes is None:
        boxes = await db.shipping_boxes.find(
            {"deleted_at": None, "active": True}, {"_id": 0}
        ).sort("max_units", 1).to_list(200)

    override_id = order.get("shipping_box_override_id")
    if override_id:
        for b in boxes:
            if b.get("id") == override_id:
                return b

    units = 0
    for it in _order_items(order):
        units += int(it.get("qty") or 1)
    units = max(1, units)
    for b in sorted(boxes, key=lambda b: int(b.get("max_units") or 0)):
        if int(b.get("max_units") or 0) >= units:
            return b
    return boxes[-1] if boxes else None


# ---------------------------------------------------------------------------
# Admin — Analytics
# ---------------------------------------------------------------------------
@api.get("/admin/analytics")
async def admin_analytics(_admin: dict = Depends(require_area("dashboard", "view"))):
    # Revenue per day (last 30 days)
    since = (datetime.now(timezone.utc) - timedelta(days=30)).isoformat()
    daily_cursor = db.orders.aggregate([
        {"$match": {"payment_status": "paid", "created_at": {"$gte": since}}},
        {"$group": {
            "_id": {"$substr": ["$created_at", 0, 10]},
            "revenue": {"$sum": "$total"},
            "orders": {"$sum": 1},
        }},
        {"$sort": {"_id": 1}},
    ])
    daily = await daily_cursor.to_list(60)
    daily = [{"date": d["_id"], "revenue": round(d["revenue"], 2), "orders": d["orders"]} for d in daily]

    # Top products
    top_cursor = db.orders.aggregate([
        {"$match": {"payment_status": "paid"}},
        {"$unwind": "$items"},
        {"$group": {
            "_id": "$items.slug",
            "name_en": {"$first": "$items.name_en"},
            "units_sold": {"$sum": "$items.qty"},
            "revenue": {"$sum": "$items.line_total"},
        }},
        {"$sort": {"units_sold": -1}},
        {"$limit": 10},
    ])
    top = await top_cursor.to_list(10)
    top = [{"slug": t["_id"], "name_en": t["name_en"], "units_sold": t["units_sold"], "revenue": round(t["revenue"], 2)} for t in top]

    # Recent orders
    recent = await db.orders.find({}, {"_id": 0}).sort("created_at", -1).limit(10).to_list(10)

    return {"daily_revenue": daily, "top_products": top, "recent_orders": recent}


# ---------------------------------------------------------------------------
# Admin — CSV exports
# ---------------------------------------------------------------------------
def _csv_response(rows: list, filename: str) -> StreamingResponse:
    buf = io.StringIO()
    if not rows:
        buf.write("\n")
    else:
        writer = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    buf.seek(0)
    return StreamingResponse(
        iter([buf.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@api.get("/admin/orders.csv")
async def admin_orders_csv(status_group: Optional[str] = None, _admin: dict = Depends(require_area("orders", "view"))):
    orders = await db.orders.find(_status_group_filter(status_group), {"_id": 0}).sort("created_at", -1).to_list(5000)
    return _csv_response(_orders_export_rows(orders), f"fironova-orders-{datetime.now().strftime('%Y%m%d')}.csv")


def _orders_export_rows(orders: list) -> list:
    rows = []
    for o in orders:
        addr = o.get("shipping_address", {})
        rows.append({
            "order_number": o.get("order_number", ""),
            "created_at": o.get("created_at", ""),
            "email": o.get("email") or "",
            "customer": addr.get("full_name", ""),
            "city": addr.get("city", ""),
            "province": addr.get("province", ""),
            "postal_code": addr.get("postal_code", ""),
            "country": addr.get("country", ""),
            "payment_method": o.get("payment_method", ""),
            "payment_status": o.get("payment_status", ""),
            "fulfillment_status": o.get("fulfillment_status", ""),
            "items_count": len(o.get("items", [])),
            "subtotal_cad": o.get("subtotal", 0),
            "discount_cad": o.get("discount", 0),
            "shipping_cad": o.get("shipping", 0),
            "total_cad": o.get("total", 0),
            "refunded_cad": o.get("refunded_amount", 0),
            "tracking_number": (o.get("shipping_info") or {}).get("tracking_number", ""),
            "carrier": (o.get("shipping_info") or {}).get("carrier", ""),
        })
    return rows


def _xlsx_response(rows: list, filename: str) -> Response:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active
    headers = list(rows[0].keys()) if rows else ["no_data"]
    ws.append(headers)
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="050505", end_color="050505", fill_type="solid")
    for cell in ws[1]:
        cell.font = header_font
        cell.fill = header_fill
    for r in rows:
        ws.append([r.get(h, "") for h in headers])
    for col_idx, h in enumerate(headers, start=1):
        width = max([len(str(h))] + [len(str(r.get(h, ""))) for r in rows[:500]]) + 2
        ws.column_dimensions[ws.cell(row=1, column=col_idx).column_letter].width = min(width, 50)
    buf = io.BytesIO()
    wb.save(buf)
    return Response(
        content=buf.getvalue(),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@api.get("/admin/orders.xlsx")
async def admin_orders_xlsx(status_group: Optional[str] = None, _admin: dict = Depends(require_area("orders", "view"))):
    orders = await db.orders.find(_status_group_filter(status_group), {"_id": 0}).sort("created_at", -1).to_list(5000)
    return _xlsx_response(_orders_export_rows(orders), f"fironova-orders-{datetime.now().strftime('%Y%m%d')}.xlsx")


@api.get("/admin/products.csv")
async def admin_products_csv(_admin: dict = Depends(require_area("products", "view"))):
    products = await db.products.find({}, {"_id": 0}).sort("name_en", 1).to_list(2000)
    rows = []
    for p in products:
        rows.append({
            "slug": p.get("slug", ""),
            "name_en": p.get("name_en", ""),
            "name_fr": p.get("name_fr", ""),
            "category": p.get("category", ""),
            "sequence": p.get("sequence", ""),
            "purity": p.get("purity", ""),
            "dosage_mg": p.get("dosage_mg", 0),
            "price_cad": p.get("price_cad", 0),
            "stock": p.get("stock", 0),
            "low_stock_threshold": p.get("low_stock_threshold", 10),
            "featured": p.get("featured", False),
            "preorder_allowed": p.get("preorder_allowed", False),
            "lab_tested": p.get("lab_tested", False),
            "coa_url": p.get("coa_url", ""),
            "coa_lot": p.get("coa_lot", ""),
            "coa_date": p.get("coa_date", ""),
            "active": p.get("active", True),
            # Scientific data fields (new)
            "molecular_formula": p.get("molecular_formula", ""),
            "molecular_weight": p.get("molecular_weight", ""),
            "cas_number": p.get("cas_number", ""),
            "sequence_length": p.get("sequence_length", ""),
            "storage": p.get("storage", ""),
            "solubility": p.get("solubility", ""),
            "appearance": p.get("appearance", ""),
            "mechanism": p.get("mechanism", ""),
            "research_areas": "; ".join(p.get("research_areas", [])),
            "synonyms": "; ".join(p.get("synonyms", [])),
        })
    return _csv_response(rows, f"fironova-products-{datetime.now().strftime('%Y%m%d')}.csv")


@api.get("/admin/products.xlsx")
async def admin_products_xlsx(_admin: dict = Depends(require_area("products", "view"))):
    products = await db.products.find({}, {"_id": 0}).sort("name_en", 1).to_list(2000)
    rows = []
    for p in products:
        rows.append({
            "slug": p.get("slug", ""),
            "name_en": p.get("name_en", ""),
            "name_fr": p.get("name_fr", ""),
            "category": p.get("category", ""),
            "purity": p.get("purity", ""),
            "dosage_mg": p.get("dosage_mg", 0),
            "price_cad": p.get("price_cad", 0),
            "stock": p.get("stock", 0),
            "variants": "; ".join(
                f"{v.get('name','')} ${v.get('price',0)} stock={v.get('stock',0)}" for v in (p.get("variants") or [])
            ),
            "low_stock_threshold": p.get("low_stock_threshold", 10),
            "featured": p.get("featured", False),
            "lab_tested": p.get("lab_tested", False),
            "active": p.get("active", True),
            # Scientific data fields (new)
            "molecular_formula": p.get("molecular_formula", ""),
            "molecular_weight": p.get("molecular_weight", ""),
            "cas_number": p.get("cas_number", ""),
            "sequence_length": p.get("sequence_length", ""),
            "storage": p.get("storage", ""),
            "solubility": p.get("solubility", ""),
            "appearance": p.get("appearance", ""),
            "mechanism": p.get("mechanism", ""),
            "research_areas": "; ".join(p.get("research_areas", [])),
            "synonyms": "; ".join(p.get("synonyms", [])),
        })
    return _xlsx_response(rows, f"fironova-products-{datetime.now().strftime('%Y%m%d')}.xlsx")


# ---------------------------------------------------------------------------
# PDF Invoice
# ---------------------------------------------------------------------------
def _generate_invoice_pdf(order: dict) -> bytes:
    buf = io.BytesIO()
    c = rl_canvas.Canvas(buf, pagesize=LETTER)
    w, h = LETTER

    # Header band
    c.setFillColor(rl_colors.black)
    c.rect(0, h - 18 * mm, w, 18 * mm, fill=1, stroke=0)
    c.setFillColor(rl_colors.white)
    c.setFont("Helvetica-Bold", 22)
    c.drawString(20 * mm, h - 13 * mm, "FIRONOVA")
    c.setFillColor(rl_colors.HexColor("#00B8D4"))
    c.circle(20 * mm + 41 * mm, h - 13 * mm + 1.5 * mm, 1.5 * mm, fill=1, stroke=0)
    c.setFillColor(rl_colors.white)
    c.setFont("Courier", 8)
    c.drawRightString(w - 20 * mm, h - 9 * mm, "// INVOICE")
    c.drawRightString(w - 20 * mm, h - 14 * mm, f"ORDER {order.get('order_number','')}")

    # Meta
    y = h - 30 * mm
    c.setFillColor(rl_colors.black)
    c.setFont("Helvetica-Bold", 18)
    c.drawString(20 * mm, y, "INVOICE")
    c.setFont("Helvetica", 9)
    y -= 6 * mm
    c.drawString(20 * mm, y, f"Order #: {order.get('order_number','')}")
    y -= 4 * mm
    c.drawString(20 * mm, y, f"Date: {(order.get('created_at') or '')[:10]}")
    y -= 4 * mm
    c.drawString(20 * mm, y, f"Status: {order.get('payment_status','')} / {order.get('fulfillment_status','')}")

    # Bill to
    addr = order.get("shipping_address") or {}
    c.setFont("Helvetica-Bold", 10)
    c.drawString(110 * mm, h - 36 * mm, "SHIP TO")
    c.setFont("Helvetica", 9)
    sy = h - 42 * mm
    for line in [
        addr.get("full_name", ""),
        addr.get("address1", ""),
        addr.get("address2", "") or None,
        f"{addr.get('city','')}, {addr.get('province','')} {addr.get('postal_code','')}",
        addr.get("country", ""),
        order.get("email") or "",
    ]:
        if line:
            c.drawString(110 * mm, sy, str(line))
            sy -= 4 * mm

    # Items table
    y -= 20 * mm
    c.setFillColor(rl_colors.black)
    c.rect(20 * mm, y - 1, w - 40 * mm, 7 * mm, fill=1, stroke=0)
    c.setFillColor(rl_colors.white)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(22 * mm, y + 1.5 * mm, "ITEM")
    c.drawString(110 * mm, y + 1.5 * mm, "QTY")
    c.drawRightString(150 * mm, y + 1.5 * mm, "UNIT")
    c.drawRightString(w - 22 * mm, y + 1.5 * mm, "TOTAL")
    y -= 6 * mm
    c.setFillColor(rl_colors.black)
    c.setFont("Helvetica", 9)
    for it in order.get("items", []):
        y -= 6 * mm
        c.drawString(22 * mm, y, f"{it.get('name_en','')} ({it.get('slug','')})")
        c.drawString(110 * mm, y, str(it.get("qty", 0)))
        c.drawRightString(150 * mm, y, f"${it.get('price_cad',0):.2f}")
        c.drawRightString(w - 22 * mm, y, f"${it.get('line_total',0):.2f}")
        c.setStrokeColor(rl_colors.HexColor("#e0e0e0"))
        c.line(20 * mm, y - 2 * mm, w - 20 * mm, y - 2 * mm)

    # Totals
    y -= 12 * mm
    c.setFont("Helvetica", 9)
    c.drawRightString(150 * mm, y, "Subtotal")
    c.drawRightString(w - 22 * mm, y, f"${order.get('subtotal',0):.2f}")
    if order.get("discount", 0) > 0:
        y -= 4 * mm
        c.drawRightString(150 * mm, y, f"Discount ({(order.get('coupon') or {}).get('code','')})")
        c.drawRightString(w - 22 * mm, y, f"-${order.get('discount',0):.2f}")
    y -= 4 * mm
    c.drawRightString(150 * mm, y, "Shipping")
    c.drawRightString(w - 22 * mm, y, f"${order.get('shipping',0):.2f}")
    y -= 6 * mm
    c.setStrokeColor(rl_colors.black)
    c.line(110 * mm, y + 2 * mm, w - 20 * mm, y + 2 * mm)
    c.setFont("Helvetica-Bold", 12)
    c.drawRightString(150 * mm, y - 3 * mm, "TOTAL CAD")
    c.drawRightString(w - 22 * mm, y - 3 * mm, f"${order.get('total',0):.2f}")

    # Footer disclaimer
    c.setFont("Courier", 7)
    c.setFillColor(rl_colors.HexColor("#666666"))
    c.drawCentredString(w / 2, 20 * mm, "FOR LABORATORY RESEARCH USE ONLY · NOT FOR HUMAN OR VETERINARY CONSUMPTION · 19+ ONLY")
    c.drawCentredString(w / 2, 16 * mm, f"FIRONOVA · CANADA · INVOICE GENERATED {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")

    c.showPage()
    c.save()
    buf.seek(0)
    return buf.getvalue()


@api.get("/orders/{order_id}/invoice.pdf")
async def order_invoice_pdf(order_id: str, request: Request):
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order:
        raise HTTPException(404, "Order not found")
    user = await _resolve_user(request)
    if order.get("user_id"):
        if not user or (user["id"] != order["user_id"] and user.get("role") != "admin"):
            raise HTTPException(403, "Forbidden")
    pdf = _generate_invoice_pdf(order)
    return Response(
        content=pdf,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="invoice-{order.get("order_number","order")}.pdf"'},
    )


@api.get("/payments/stripe/status/{session_id}")
async def stripe_status(session_id: str, request: Request):
    """Poll Stripe checkout session status. Updates payment_transactions + order atomically once paid."""
    if not _STRIPE_AVAILABLE or not STRIPE_API_KEY:
        raise HTTPException(503, "Stripe not configured")
    txn = await db.payment_transactions.find_one({"session_id": session_id}, {"_id": 0})
    if not txn:
        raise HTTPException(404, "Session not found")
    # Idempotent: if already paid in our DB, return cached
    if txn.get("payment_status") == "paid":
        return {"session_id": session_id, "payment_status": "paid", "status": "complete"}

    origin = str(request.base_url).rstrip("/")
    stripe_checkout = StripeCheckout(api_key=STRIPE_API_KEY, webhook_url=f"{origin}/api/webhook/stripe")
    try:
        status_resp = await stripe_checkout.get_checkout_status(session_id)
    except Exception as e:
        logging.error("Stripe status err: %s", e)
        raise HTTPException(502, "Stripe status unavailable")

    await db.payment_transactions.update_one(
        {"session_id": session_id},
        {"$set": {"payment_status": status_resp.payment_status, "status": status_resp.status,
                  "updated_at": datetime.now(timezone.utc).isoformat()}},
    )
    # If paid, mark it paid via the single idempotent entry point. Safe even if
    # the Stripe webhook already did it concurrently — only one caller wins.
    if status_resp.payment_status == "paid":
        await _mark_order_paid(txn["order_id"], "Payment confirmed via Stripe checkout status")
    # Expired Stripe session = active payment failure → "failed" (distinct from voluntary "cancelled")
    if status_resp.status == "expired":
        order = await db.orders.find_one({"id": txn["order_id"]}, {"_id": 0})
        if order and order.get("payment_status") not in ("paid",) and order.get("fulfillment_status") not in ("cancelled", "failed"):
            await db.orders.update_one(
                {"id": txn["order_id"]},
                {"$set": {"payment_status": "failed", "fulfillment_status": "failed"},
                 "$push": {"notes": {
                     "id": str(uuid.uuid4()),
                     "text": "Payment failed: Stripe checkout session expired",
                     "author": "system",
                     "created_at": datetime.now(timezone.utc).isoformat(),
                 }}},
            )
            await _restock_order_items(order)
    return {
        "session_id": session_id,
        "payment_status": status_resp.payment_status,
        "status": status_resp.status,
        "amount_total": status_resp.amount_total,
        "currency": status_resp.currency,
    }


@api.post("/webhook/nowpayments")
async def nowpayments_ipn(request: Request):
    """NOWPayments IPN callback. HMAC-SHA512 signature verified against sorted JSON payload."""
    if not NOWPAYMENTS_IPN_SECRET:
        raise HTTPException(503, "IPN not configured")
    raw = await request.body()
    sig = request.headers.get("x-nowpayments-sig", "")
    try:
        payload = json.loads(raw)
    except Exception:
        raise HTTPException(400, "Invalid payload")
    expected = hmac.new(
        NOWPAYMENTS_IPN_SECRET.encode(),
        json.dumps(payload, separators=(",", ":"), sort_keys=True).encode(),
        hashlib.sha512,
    ).hexdigest()
    if not sig or not hmac.compare_digest(expected, sig):
        logging.warning("NOWPayments IPN: invalid signature")
        raise HTTPException(401, "Invalid signature")
    order_id = payload.get("order_id")
    np_status = payload.get("payment_status", "")
    if not order_id:
        return {"ok": True}

    # Défense en profondeur au-delà du HMAC : on n'agit que sur une commande
    # qui existe, qui utilise bien ce moyen de paiement, et dont le montant
    # facturé correspond au nôtre. Un IPN "finished" avec un montant divergent
    # n'est JAMAIS auto-confirmé — il est journalisé pour revue manuelle.
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order or order.get("payment_method") != "nowpayments":
        logging.warning("NOWPayments IPN: commande inconnue/incohérente %s — ignorée", order_id)
        return {"ok": True}
    try:
        ipn_amount = float(payload.get("price_amount") or 0)
    except (TypeError, ValueError):
        ipn_amount = 0.0
    order_total = float(order.get("total", 0))
    if np_status == "finished" and abs(ipn_amount - order_total) > 0.01:
        logging.warning(
            "NOWPayments IPN: montant divergent commande %s (ipn %.2f vs commande %.2f) — NON marquée payée",
            order_id, ipn_amount, order_total,
        )
        await db.orders.update_one({"id": order_id}, {"$push": {"notes": {
            "id": str(uuid.uuid4()),
            "text": (f"IPN 'finished' reçu avec un montant divergent "
                     f"(${ipn_amount:.2f} vs ${order_total:.2f}) — paiement NON auto-confirmé, "
                     f"à vérifier manuellement."),
            "author": "system",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }}})
        return {"ok": True}

    updates = {"payment_info.provider_response.payment_status": np_status}
    if payload.get("payment_id"):
        updates["payment_info.provider_response.payment_id"] = str(payload["payment_id"])
    if payload.get("pay_currency"):
        updates["payment_info.provider_response.pay_currency"] = payload["pay_currency"]
    await db.orders.update_one({"id": order_id}, {"$set": updates})
    if np_status == "finished":
        fresh = await _mark_order_paid(
            order_id,
            f"Crypto payment confirmed via NOWPayments IPN (payment_id {payload.get('payment_id')})",
        )
        if fresh:
            logging.info("Order %s marked paid via NOWPayments IPN", order_id)
    return {"ok": True}


@api.get("/payments/crypto/status/{order_id}")
async def crypto_status(order_id: str):
    """Poll NOWPayments payment status. Marks order paid only when np status is 'finished'."""
    order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    if not order or order.get("payment_method") != "nowpayments":
        raise HTTPException(404, "Order not found")
    if order.get("payment_status") == "paid":
        return {"order_id": order_id, "payment_status": "paid", "np_status": "finished"}
    np_info = (order.get("payment_info") or {}).get("provider_response") or {}
    payment_id = np_info.get("payment_id")
    if not payment_id or np_info.get("mock"):
        # Invoice/widget flow (paid state is pushed via IPN) or mock mode: return DB status
        return {
            "order_id": order_id,
            "payment_status": order.get("payment_status"),
            "np_status": np_info.get("payment_status", "waiting"),
            **({"mock": True} if np_info.get("mock") else {}),
        }
    if not NOWPAYMENTS_API_KEY:
        raise HTTPException(503, "Crypto provider not configured")
    try:
        async with httpx.AsyncClient(timeout=15) as cx:
            r = await cx.get(
                f"{NOWPAYMENTS_BASE_URL}/payment/{payment_id}",
                headers={"x-api-key": NOWPAYMENTS_API_KEY},
            )
            r.raise_for_status()
            data = r.json()
    except Exception as e:
        logging.error("NOWPayments status err: %s", e)
        raise HTTPException(502, "Crypto status unavailable")
    np_status = data.get("payment_status", "waiting")
    if np_status != np_info.get("payment_status"):
        await db.orders.update_one(
            {"id": order_id},
            {"$set": {"payment_info.provider_response.payment_status": np_status}},
        )
    if np_status == "finished":
        res = await db.orders.update_one(
            {"id": order_id, "payment_status": {"$ne": "paid"}},
            {"$set": {
                "payment_status": "paid",
                "fulfillment_status": "processing",
                "paid_at": (_pa := datetime.now(timezone.utc).isoformat()),
                "dispatch_batch": compute_dispatch_batch(_pa),
            }},
        )
        if res.modified_count:
            fresh = await db.orders.find_one({"id": order_id}, {"_id": 0})
            if fresh.get("email"):
                asyncio.create_task(send_payment_received(fresh))
        return {"order_id": order_id, "payment_status": "paid", "np_status": np_status}
    return {"order_id": order_id, "payment_status": order.get("payment_status"), "np_status": np_status}


@api.post("/webhook/stripe")
async def stripe_webhook(request: Request):
    """Handle Stripe webhook events to mark orders as paid."""
    if not _STRIPE_AVAILABLE or not STRIPE_API_KEY:
        return {"ok": False, "reason": "stripe_disabled"}
    body = await request.body()
    sig = request.headers.get("Stripe-Signature", "")
    origin = str(request.base_url).rstrip("/")
    stripe_checkout = StripeCheckout(api_key=STRIPE_API_KEY, webhook_url=f"{origin}/api/webhook/stripe")
    try:
        evt = await stripe_checkout.handle_webhook(body, sig)
    except Exception as e:
        logging.error("Stripe webhook err: %s", e)
        return {"ok": False}
    if evt.payment_status == "paid" and evt.session_id:
        txn = await db.payment_transactions.find_one({"session_id": evt.session_id})
        if txn:
            await db.payment_transactions.update_one(
                {"session_id": evt.session_id},
                {"$set": {"payment_status": "paid", "status": "complete",
                          "updated_at": datetime.now(timezone.utc).isoformat()}},
            )
            # Point d'entrée unique et idempotent : que ce webhook arrive avant,
            # après, ou en même temps que le polling stripe_status, un seul des
            # deux fera la transition (garde $ne "paid" dans _mark_order_paid).
            await _mark_order_paid(txn["order_id"], "Payment confirmed via Stripe webhook")
    return {"ok": True}


# ---------------------------------------------------------------------------
# Public meta
# ---------------------------------------------------------------------------
@api.get("/meta")
async def meta():
    return {
        "store": "FIRONOVA",
        "currency": "CAD",
        "shipping_flat_cad": SHIPPING_FLAT_CAD,
        "provinces": PROVINCES_CA,
        "min_age": 19,
        "interac_email": INTERAC_EMAIL,
        "coa_page_enabled": COA_PAGE_ENABLED,
        "canada_post_enabled": is_canada_post_configured(),
        "prelaunch_enabled": PRELAUNCH_ENABLED,
        "launch_coupon_code": LAUNCH_COUPON_CODE,
        "seo": await _seo_get_settings(),
        # PRELAUNCH_PREVIEW_TOKEN n'est JAMAIS exposé ici — il ne se vérifie que
        # côté serveur via GET /prelaunch/preview.
    }


@api.get("/")
async def root():
    return {"service": "fironova-api", "status": "ok"}


# ---------------------------------------------------------------------------
# Seed data
# ---------------------------------------------------------------------------
# =============================================================================
# FIRONOVA — Catalogue produits (19 peptides de recherche)
# Données scientifiques vérifiées (PubChem, ChemicalBook, Sigma-Aldrich).
# active: True  → 5 produits au lancement
# active: False → 14 produits, à activer depuis l'admin
# image_url: "" → à remplir via POST /admin/upload/image
# =============================================================================
SEED_PRODUCTS = [
    {
        "slug": "bpc-157-5mg",
        "name_en": "BPC-157",
        "name_fr": "BPC-157",
        "category": "healing",
        "sequence": "GEPPPGKPADDAGLV",
        "molecular_formula": "C62H98N16O22",
        "molecular_weight": 1419.55,
        "cas_number": "137525-51-0",
        "sequence_length": 15,
        "purity": "≥ 99.0%",
        "dosage_mg": 5.0,
        "description_en": "Body Protection Compound, a 15-amino-acid synthetic peptide derived from gastric protein. Widely studied in research models for tissue repair pathways.",
        "description_fr": "Composé de protection corporelle, peptide synthétique de 15 acides aminés dérivé d'une protéine gastrique. Étudié dans des modèles de recherche sur les voies de réparation tissulaire.",
        "price_cad": 64.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": True,
    },
    {
        "slug": "tb-500-5mg",
        "name_en": "TB-500",
        "name_fr": "TB-500",
        "category": "healing",
        "sequence": "Ac-SDKPDMAEIEKFDKSKLKKTETQEKNPLPSKETIEQEKQAGES",
        "molecular_formula": "C212H350N56O78S",
        "molecular_weight": 4963.44,
        "cas_number": "77591-33-4",
        "sequence_length": 43,
        "purity": "≥ 99.0%",
        "dosage_mg": 5.0,
        "description_en": "Full-length Thymosin Beta-4 (43 amino acids). Investigated in research for actin sequestration and cellular migration studies.",
        "description_fr": "Thymosine bêta-4 complète (43 acides aminés). Étudiée en recherche pour la séquestration de l'actine et les études de migration cellulaire.",
        "price_cad": 79.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": True,
    },
    {
        "slug": "semaglutide-5mg",
        "name_en": "Semaglutide",
        "name_fr": "Sémaglutide",
        "category": "weight-loss",
        "sequence": "GLP-1 analog (31 aa, C18 diacid modified)",
        "molecular_formula": "C187H291N45O59",
        "molecular_weight": 4113.58,
        "cas_number": "910463-68-2",
        "sequence_length": 31,
        "purity": "≥ 98.0%",
        "dosage_mg": 5.0,
        "description_en": "GLP-1 receptor agonist analog under extensive research in metabolic studies.",
        "description_fr": "Analogue agoniste du récepteur GLP-1 largement étudié dans les recherches métaboliques.",
        "price_cad": 189.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": True,
    },
    {
        "slug": "tirzepatide-10mg",
        "name_en": "Tirzepatide",
        "name_fr": "Tirzépatide",
        "category": "weight-loss",
        "sequence": "GIP/GLP-1 dual agonist (39 aa, C20 diacid modified)",
        "molecular_formula": "C225H348N48O68",
        "molecular_weight": 4813.45,
        "cas_number": "2023788-19-2",
        "sequence_length": 39,
        "purity": "≥ 98.0%",
        "dosage_mg": 10.0,
        "description_en": "Dual GIP and GLP-1 receptor agonist studied in metabolic and body-weight research models.",
        "description_fr": "Double agoniste des récepteurs GIP et GLP-1 étudié dans les modèles de recherche métabolique et pondérale.",
        "price_cad": 219.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": True,
    },
    {
        "slug": "ipamorelin-5mg",
        "name_en": "Ipamorelin",
        "name_fr": "Ipamoréline",
        "category": "cognitive",
        "sequence": "Aib-His-D-2-Nal-D-Phe-Lys-NH2",
        "molecular_formula": "C38H49N9O5",
        "molecular_weight": 711.85,
        "cas_number": "170851-70-4",
        "sequence_length": 5,
        "purity": "≥ 98.0%",
        "dosage_mg": 5.0,
        "description_en": "Selective growth hormone secretagogue (ghrelin receptor agonist) studied in endocrine research.",
        "description_fr": "Sécrétagogue sélectif de l'hormone de croissance (agoniste du récepteur de la ghréline) étudié en recherche endocrinienne.",
        "price_cad": 74.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": True,
    },
    {
        "slug": "cjc-1295-no-dac-5mg",
        "name_en": "CJC-1295 No-DAC",
        "name_fr": "CJC-1295 sans DAC",
        "category": "cognitive",
        "sequence": "Tyr-D-Ala-Asp-Ala-Ile-Phe-Thr-Gln-Ser-Tyr-Arg-Lys-Val-Leu-Ala-Gln-Leu-Ser-Ala-Arg-Lys-Leu-Leu-Gln-Asp-Ile-Leu-Ser-Arg-NH2",
        "molecular_formula": "C152H252N44O42",
        "molecular_weight": 3367.9,
        "cas_number": "863288-34-0",
        "sequence_length": 29,
        "purity": "≥ 98.0%",
        "dosage_mg": 5.0,
        "description_en": "Modified GRF (1-29), a GHRH analog studied for pulsatile growth-hormone-release research.",
        "description_fr": "GRF modifié (1-29), analogue de la GHRH étudié pour la recherche sur la libération pulsatile de l'hormone de croissance.",
        "price_cad": 69.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "selank-5mg",
        "name_en": "Selank",
        "name_fr": "Sélank",
        "category": "cognitive",
        "sequence": "Thr-Lys-Pro-Arg-Pro-Gly-Pro",
        "molecular_formula": "C33H57N11O9",
        "molecular_weight": 751.87,
        "cas_number": "129954-34-3",
        "sequence_length": 7,
        "purity": "≥ 99.0%",
        "dosage_mg": 5.0,
        "description_en": "Synthetic heptapeptide derived from tuftsin, studied for anxiolytic and nootropic pathways.",
        "description_fr": "Heptapeptide synthétique dérivé de la tuftsine, étudié pour les voies anxiolytiques et nootropiques.",
        "price_cad": 59.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "semax-10mg",
        "name_en": "Semax",
        "name_fr": "Sémax",
        "category": "cognitive",
        "sequence": "Met-Glu-His-Phe-Pro-Gly-Pro",
        "molecular_formula": "C37H51N9O10S",
        "molecular_weight": 813.92,
        "cas_number": "80714-61-0",
        "sequence_length": 7,
        "purity": "≥ 99.0%",
        "dosage_mg": 10.0,
        "description_en": "Synthetic heptapeptide ACTH(4-7) analog studied for BDNF modulation and neuroprotection.",
        "description_fr": "Heptapeptide synthétique analogue de l'ACTH(4-7) étudié pour la modulation du BDNF et la neuroprotection.",
        "price_cad": 84.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "ghk-cu-50mg",
        "name_en": "GHK-Cu",
        "name_fr": "GHK-Cu",
        "category": "healing",
        "sequence": "Gly-His-Lys · Cu(II)",
        "molecular_formula": "C14H22CuN6O4",
        "molecular_weight": 403.93,
        "cas_number": "89030-95-5",
        "sequence_length": 3,
        "purity": "≥ 99.0%",
        "dosage_mg": 50.0,
        "description_en": "Copper(II) complex of the tripeptide Gly-His-Lys, studied for collagen synthesis and matrix remodeling.",
        "description_fr": "Complexe cuivre(II) du tripeptide Gly-His-Lys, étudié pour la synthèse du collagène et le remodelage matriciel.",
        "price_cad": 89.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "retatrutide-10mg",
        "name_en": "Retatrutide",
        "name_fr": "Rétatrutide",
        "category": "weight-loss",
        "sequence": "GIP/GLP-1/GCGR triple agonist (39 aa, lipid diacid modified)",
        "molecular_formula": "C221H342N46O68",
        "molecular_weight": 4731.33,
        "cas_number": "2381089-83-2",
        "sequence_length": 39,
        "purity": "≥ 98.0%",
        "dosage_mg": 10.0,
        "description_en": "Triple GIP/GLP-1/glucagon receptor agonist studied in metabolic and body-weight research.",
        "description_fr": "Triple agoniste des récepteurs GIP/GLP-1/glucagon étudié en recherche métabolique et pondérale.",
        "price_cad": 249.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "pt-141-10mg",
        "name_en": "PT-141",
        "name_fr": "PT-141",
        "category": "cognitive",
        "sequence": "Ac-Nle-cyclo[Asp-His-D-Phe-Arg-Trp-Lys]-OH",
        "molecular_formula": "C50H68N14O10",
        "molecular_weight": 1025.18,
        "cas_number": "189691-06-3",
        "sequence_length": 7,
        "purity": "≥ 98.0%",
        "dosage_mg": 10.0,
        "description_en": "Cyclic melanocortin receptor agonist (bremelanotide) studied in neuroscience research.",
        "description_fr": "Agoniste cyclique des récepteurs de la mélanocortine (bremélanotide) étudié en recherche en neurosciences.",
        "price_cad": 79.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "melanotan-2-10mg",
        "name_en": "Melanotan-2",
        "name_fr": "Mélanotan-2",
        "category": "cognitive",
        "sequence": "Ac-Nle-cyclo[Asp-His-D-Phe-Arg-Trp-Lys]-NH2",
        "molecular_formula": "C50H69N15O9",
        "molecular_weight": 1024.18,
        "cas_number": "121062-08-6",
        "sequence_length": 7,
        "purity": "≥ 98.0%",
        "dosage_mg": 10.0,
        "description_en": "Cyclic heptapeptide α-MSH analog and non-selective melanocortin receptor agonist studied in research.",
        "description_fr": "Heptapeptide cyclique analogue de l'α-MSH et agoniste non sélectif des récepteurs de la mélanocortine étudié en recherche.",
        "price_cad": 69.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "mots-c-10mg",
        "name_en": "MOTS-c",
        "name_fr": "MOTS-c",
        "category": "weight-loss",
        "sequence": "Met-Arg-Trp-Gln-Glu-Met-Gly-Tyr-Ile-Phe-Tyr-Pro-Arg-Lys-Leu-Arg",
        "molecular_formula": "C101H152N28O22S2",
        "molecular_weight": 2174.6,
        "cas_number": "1627580-64-6",
        "sequence_length": 16,
        "purity": "≥ 98.0%",
        "dosage_mg": 10.0,
        "description_en": "Mitochondrial-derived 16-amino-acid peptide studied for AMPK-linked metabolic regulation.",
        "description_fr": "Peptide mitochondrial de 16 acides aminés étudié pour la régulation métabolique liée à l'AMPK.",
        "price_cad": 99.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "epithalon-10mg",
        "name_en": "Epithalon",
        "name_fr": "Épithalon",
        "category": "healing",
        "sequence": "Ala-Glu-Asp-Gly",
        "molecular_formula": "C14H22N4O9",
        "molecular_weight": 390.35,
        "cas_number": "307297-39-8",
        "sequence_length": 4,
        "purity": "≥ 99.0%",
        "dosage_mg": 10.0,
        "description_en": "Synthetic tetrapeptide (AEDG) studied for telomerase activity and circadian gene expression.",
        "description_fr": "Tétrapeptide synthétique (AEDG) étudié pour l'activité télomérase et l'expression des gènes circadiens.",
        "price_cad": 64.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "tesamorelin-5mg",
        "name_en": "Tesamorelin",
        "name_fr": "Tésamoréline",
        "category": "weight-loss",
        "sequence": "trans-3-hexenoyl-GRF(1-44)-NH2 (44 aa)",
        "molecular_formula": "C221H366N72O67S",
        "molecular_weight": 5135.86,
        "cas_number": "218949-48-5",
        "sequence_length": 44,
        "purity": "≥ 98.0%",
        "dosage_mg": 5.0,
        "description_en": "Stabilized GHRH(1-44) analog studied in metabolic and adipose-tissue research models.",
        "description_fr": "Analogue stabilisé de la GHRH(1-44) étudié dans les modèles de recherche métabolique et adipeuse.",
        "price_cad": 179.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "hexarelin-5mg",
        "name_en": "Hexarelin",
        "name_fr": "Hexaréline",
        "category": "cognitive",
        "sequence": "His-D-2-Me-Trp-Ala-Trp-D-Phe-Lys-NH2",
        "molecular_formula": "C47H58N12O6",
        "molecular_weight": 887.04,
        "cas_number": "140703-51-1",
        "sequence_length": 6,
        "purity": "≥ 98.0%",
        "dosage_mg": 5.0,
        "description_en": "Synthetic hexapeptide growth hormone secretagogue (GHS-R agonist) studied in endocrine research.",
        "description_fr": "Hexapeptide synthétique sécrétagogue de l'hormone de croissance (agoniste GHS-R) étudié en recherche endocrinienne.",
        "price_cad": 74.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "ghrp-2-5mg",
        "name_en": "GHRP-2",
        "name_fr": "GHRP-2",
        "category": "cognitive",
        "sequence": "D-Ala-D-2-Nal-Ala-Trp-D-Phe-Lys-NH2",
        "molecular_formula": "C45H55N9O6",
        "molecular_weight": 817.97,
        "cas_number": "158861-67-7",
        "sequence_length": 6,
        "purity": "≥ 98.0%",
        "dosage_mg": 5.0,
        "description_en": "Synthetic hexapeptide (pralmorelin) growth hormone secretagogue studied in endocrine research.",
        "description_fr": "Hexapeptide synthétique (pralmoréline) sécrétagogue de l'hormone de croissance étudié en recherche endocrinienne.",
        "price_cad": 69.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "ghrp-6-5mg",
        "name_en": "GHRP-6",
        "name_fr": "GHRP-6",
        "category": "cognitive",
        "sequence": "His-D-Trp-Ala-Trp-D-Phe-Lys-NH2",
        "molecular_formula": "C46H56N12O6",
        "molecular_weight": 873.03,
        "cas_number": "87616-84-0",
        "sequence_length": 6,
        "purity": "≥ 98.0%",
        "dosage_mg": 5.0,
        "description_en": "Synthetic hexapeptide growth hormone secretagogue and ghrelin receptor agonist studied in research.",
        "description_fr": "Hexapeptide synthétique sécrétagogue de l'hormone de croissance et agoniste du récepteur de la ghréline étudié en recherche.",
        "price_cad": 64.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
    {
        "slug": "aod-9604-5mg",
        "name_en": "AOD-9604",
        "name_fr": "AOD-9604",
        "category": "weight-loss",
        "sequence": "Tyr-Leu-Arg-Ile-Val-Gln-Cys-Arg-Ser-Val-Glu-Gly-Ser-Cys-Gly-Phe (disulfide Cys7-Cys14)",
        "molecular_formula": "C78H123N23O23S2",
        "molecular_weight": 1815.1,
        "cas_number": "221231-10-3",
        "sequence_length": 16,
        "purity": "≥ 99.0%",
        "dosage_mg": 5.0,
        "description_en": "Modified hGH fragment (176-191) with N-terminal tyrosine, studied in lipid-metabolism research.",
        "description_fr": "Fragment modifié de l'hGH (176-191) avec tyrosine N-terminale, étudié en recherche sur le métabolisme lipidique.",
        "price_cad": 89.99,
        "stock": 0,
        "image_url": "",
        "lab_tested": True,
        "active": False,
    },
]


async def seed_admin_and_products():
    # Indexes
    await db.users.create_index("email", unique=True)
    await db.users.create_index("id", unique=True)
    await db.products.create_index("slug", unique=True)
    await affiliate_ensure_indexes()
    await db.products.create_index("id", unique=True)
    await db.products.create_index([("active", 1), ("category", 1)])
    await db.products.create_index([("active", 1), ("featured", 1)])
    await db.orders.create_index("order_number")
    await db.orders.create_index("user_id")
    await db.orders.create_index("id", unique=True)
    # Écrans admin & watchdog : sans ces index, chaque poll = COLLSCAN complet.
    await db.orders.create_index([("payment_status", 1), ("created_at", -1)])
    await db.orders.create_index([("fulfillment_status", 1), ("created_at", -1)])
    await db.orders.create_index([("dispatch_batch", 1), ("payment_status", 1)])
    await db.orders.create_index([("created_at", -1)])
    await db.coupons.create_index("code", unique=True)
    await db.payment_transactions.create_index("session_id", unique=True)
    await db.payment_transactions.create_index("order_id")
    await db.stock_notifications.create_index([("product_id", 1), ("variant_id", 1), ("notified", 1)])
    await db.subscribers.create_index("email", unique=True)
    await db.subscribers.create_index("unsubscribe_token", unique=True)
    await db.subscribers.create_index("status")
    await db.addresses.create_index([("user_id", 1), ("created_at", -1)])
    await db.categories.create_index("slug", unique=True)
    await db.menus.create_index("slug", unique=True)
    await db.menus.create_index([("location", 1), ("published", 1), ("display_order", 1)])
    # Bannière « manifeste non transmis » : sans index, chaque chargement de
    # l'admin scanne toute la collection orders.
    await db.orders.create_index([("shipping_info.cp_transmitted", 1), ("shipping_info.cp_group_id", 1)])
    await db.email_change_requests.create_index("token", unique=True)
    await db.email_change_requests.create_index("user_id")
    await db.staff_invites.create_index("token", unique=True)
    await db.staff_invites.create_index("email")
    await db.admin_audit_log.create_index([("created_at", -1)])
    await db.admin_audit_log.create_index("user_id")
    await db.products.create_index("deleted_at")
    await db.coupons.create_index("deleted_at")
    await db.shipping_zones.create_index("deleted_at")
    await db.shipping_methods.create_index("deleted_at")
    await db.orders.create_index("deleted_at")

    # Admin
    existing = await db.users.find_one({"email": ADMIN_EMAIL.lower()})
    hashed = hash_password(ADMIN_PASSWORD)
    if not existing:
        await db.users.insert_one({
            "id": str(uuid.uuid4()),
            "email": ADMIN_EMAIL.lower(),
            "name": "FIRONOVA Admin",
            "password_hash": hashed,
            "role": "admin",
            "token_version": 0,
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
    elif not verify_password(ADMIN_PASSWORD, existing["password_hash"]):
        # Rotation de mot de passe détectée (ADMIN_PASSWORD changé côté env) :
        # on incrémente token_version pour révoquer immédiatement toute
        # session admin ouverte avec l'ancien mot de passe.
        await db.users.update_one(
            {"email": ADMIN_EMAIL.lower()},
            {"$set": {"password_hash": hashed, "role": "admin"},
             "$inc": {"token_version": 1}},
        )

    # Products
    featured_slugs = {"bpc-157-5mg", "semaglutide-5mg", "tirzepatide-10mg", "ipamorelin-5mg", "ghk-cu-50mg", "epithalon-10mg"}
    for p in SEED_PRODUCTS:
        default_variant = {
            "id": str(uuid.uuid4()),
            "name": f"{p['dosage_mg']}mg",
            "price": p["price_cad"],
            "stock": p["stock"],
            "sku": p["slug"].upper(),
            "coa_status": "available",
            "badge_coa_available": True,
            "badge_coa_pending": False,
            "badge_coming_soon": False,
            "preorder_enabled": False,
            "preorder_delay_message": "",
            "preorder_price": None,
            "preorder_note": "",
        }
        defaults = {
            **p,
            "id": str(uuid.uuid4()),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "featured": p["slug"] in featured_slugs,
            "preorder_allowed": False,
            "low_stock_threshold": 10,
            "coa_url": "",
            "coa_lot": "",
            "coa_date": "",
            "variants": [default_variant],
        }
        await db.products.update_one({"slug": p["slug"]}, {"$setOnInsert": defaults}, upsert=True)
        # Backfill featured flag and scientific fields on existing docs (non-destructive)
        sci_backfill = {k: p[k] for k in (
            "molecular_formula", "molecular_weight", "cas_number", "sequence_length",
            "sequence", "purity", "description_en", "description_fr",
        ) if k in p}
        sci_backfill["featured"] = p["slug"] in featured_slugs
        await db.products.update_one(
            {"slug": p["slug"]},
            {"$set": sci_backfill},
        )
        for field, value in {"preorder_allowed": False, "low_stock_threshold": 10,
                              "coa_url": "", "coa_lot": "", "coa_date": ""}.items():
            await db.products.update_one(
                {"slug": p["slug"], field: {"$exists": False}},
                {"$set": {field: value}},
            )
        # Ensure at least one variant exists on legacy products
        await db.products.update_one(
            {"slug": p["slug"], "$or": [{"variants": {"$exists": False}}, {"variants": []}]},
            {"$set": {"variants": [default_variant]}},
        )

    # Default shipping zone: Canada
    if await db.shipping_zones.count_documents({}) == 0:
        canada_zone_id = str(uuid.uuid4())
        await db.shipping_zones.insert_one({
            "id": canada_zone_id,
            "name": "Canada",
            "countries": ["CA"],
            "provinces": PROVINCES_CA,
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
        intl_zone_id = str(uuid.uuid4())
        await db.shipping_zones.insert_one({
            "id": intl_zone_id,
            "name": "International",
            "countries": ["INTL"],
            "provinces": [],
            "created_at": datetime.now(timezone.utc).isoformat(),
        })
        await db.shipping_methods.insert_many([
            {
                "id": str(uuid.uuid4()),
                "zone_id": canada_zone_id,
                "name": "Canada Post Xpresspost",
                "cost_cad": 20.0,
                "eta_days": "2-3 business days",
                "active": True,
                "created_at": datetime.now(timezone.utc).isoformat(),
            },
            {
                "id": str(uuid.uuid4()),
                "zone_id": canada_zone_id,
                "name": "Canada Post Expedited",
                "cost_cad": 12.0,
                "eta_days": "5-7 business days",
                "active": True,
                "created_at": datetime.now(timezone.utc).isoformat(),
            },
            {
                "id": str(uuid.uuid4()),
                "zone_id": intl_zone_id,
                "name": "International Tracked",
                "cost_cad": 45.0,
                "eta_days": "10-20 business days",
                "active": True,
                "created_at": datetime.now(timezone.utc).isoformat(),
            },
        ])

    # ------------------------------------------------------------------
    # MIGRATION — variant.coa_status (single source of truth)
    # Converts legacy per-variant booleans to the new coa_status field, once,
    # only on variants that don't yet have it. Non-destructive: legacy booleans
    # are left in place for rollback. Mapping:
    #   coa_url present OR badge_coa_available  -> "available"
    #   else badge_coa_pending                  -> "pending"
    #   else                                    -> "none"
    # ------------------------------------------------------------------
    async for prod in db.products.find({"variants": {"$exists": True, "$ne": []}}, {"variants": 1}):
        vs = prod.get("variants") or []
        changed = False
        for v in vs:
            if "coa_status" in v and v["coa_status"] in ("available", "pending", "none"):
                continue
            if v.get("coa_url") or v.get("badge_coa_available"):
                v["coa_status"] = "available"
            elif v.get("badge_coa_pending"):
                v["coa_status"] = "pending"
            else:
                v["coa_status"] = "none"
            changed = True
        if changed:
            await db.products.update_one({"_id": prod["_id"]}, {"$set": {"variants": vs}})


async def _restock_order_items(order: dict):
    for it in order.get("items", []):
        if it.get("preorder"):
            continue
        if it.get("variant_id") in (None, "", "_default"):
            await db.products.update_one({"id": it["product_id"]}, {"$inc": {"stock": it["qty"]}})
            asyncio.create_task(_maybe_notify_restock(it["product_id"], None))
            continue
        await db.products.update_one(
            {"id": it["product_id"], "variants.id": it["variant_id"]},
            {"$inc": {"variants.$.stock": it["qty"]}},
        )
        asyncio.create_task(_maybe_notify_restock(it["product_id"], it["variant_id"]))


async def cancel_stale_unpaid_orders():
    cutoff = (datetime.now(timezone.utc) - timedelta(hours=UNPAID_ORDER_TTL_HOURS)).isoformat()
    stale = await db.orders.find(
        {
            "payment_status": {"$in": ["awaiting_etransfer", "awaiting_crypto"]},
            "created_at": {"$lt": cutoff},
        },
        {"_id": 0},
    ).to_list(500)
    for order in stale:
        note = {
            "id": str(uuid.uuid4()),
            "text": f"Auto-cancelled: payment not received within {int(UNPAID_ORDER_TTL_HOURS)}h",
            "author": "system",
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        res = await db.orders.update_one(
            {"id": order["id"], "payment_status": order["payment_status"]},
            {"$set": {"payment_status": "cancelled", "fulfillment_status": "cancelled"},
             "$push": {"notes": note}},
        )
        if res.modified_count:
            await _restock_order_items(order)
            # Rendre l'usage du coupon s'il avait été décompté (garde de sécurité :
            # avec le nouveau flux, le coupon n'est normalement compté qu'au
            # paiement confirmé, donc coupon_counted ne devrait jamais être True
            # ici — sauf commandes créées avant ce correctif).
            c = order.get("coupon")
            if c and c.get("code") and order.get("coupon_counted"):
                await db.coupons.update_one(
                    {"code": c["code"], "used_count": {"$gt": 0}},
                    {"$inc": {"used_count": -1}},
                )
                await db.orders.update_one({"id": order["id"]}, {"$set": {"coupon_counted": False}})
            logging.info("Auto-cancelled unpaid order %s", order.get("order_number", order["id"]))
    return len(stale)


async def _unpaid_orders_watchdog():
    while True:
        try:
            await cancel_stale_unpaid_orders()
        except Exception as e:
            logging.error("Unpaid order watchdog error: %s", e)
        await asyncio.sleep(3600)


async def _acquire_worker_lock(name: str, ttl_seconds: int = 120) -> bool:
    """Verrou coopératif Mongo : un seul worker exécute les tâches de fond.
    Sans ça, N workers uvicorn lancent N boucles concurrentes sur les mêmes
    commandes (auto-cancel, backfill)."""
    now = datetime.now(timezone.utc)
    try:
        await db.locks.update_one(
            {"_id": name, "expires_at": {"$lt": now.isoformat()}},
            {"$set": {"expires_at": (now + timedelta(seconds=ttl_seconds)).isoformat(),
                      "owner": str(uuid.uuid4())}},
            upsert=True,
        )
        return True
    except Exception:
        return False  # duplicate key = un autre worker détient déjà le verrou


async def _seed_categories_from_products() -> None:
    """Dérive les catégories réelles à partir des slugs déjà portés par les produits.
    Idempotent ($setOnInsert) : une catégorie éditée ensuite par l'admin n'est
    jamais réécrite au redéploiement. Aucun produit n'est touché."""
    try:
        slugs = [x for x in await db.products.distinct("category") if x and _SLUG_RE.match(str(x))]
        # Libellés par défaut alignés sur les clés i18n existantes.
        labels = {
            "healing": ("Healing & Recovery", "Guérison et récupération"),
            "weight-loss": ("Weight Management", "Gestion du poids"),
            "gh-secretagogues": ("GH Secretagogues", "Sécrétagogues de GH"),
            "cognitive": ("Cognitive", "Cognitif"),
            "longevity": ("Longevity", "Longévité"),
        }
        for i, slug in enumerate(sorted(slugs)):
            en, fr = labels.get(slug, (slug.replace("-", " ").title(), slug.replace("-", " ").title()))
            await db.categories.update_one(
                {"slug": slug},
                {"$setOnInsert": {
                    "id": str(uuid.uuid4()),
                    "slug": slug,
                    "name_en": en,
                    "name_fr": fr,
                    "published": True,
                    "display_order": i,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }},
                upsert=True,
            )
        if slugs:
            logging.info("categories seed: %d slug(s) vérifié(s)", len(slugs))
    except Exception as e:  # pragma: no cover
        logging.error("categories seed failed: %s", e)


async def _seed_default_menus() -> None:
    """Reproduit à l'identique la navigation actuellement codée en dur, pour que
    rien ne bouge visuellement au premier déploiement. $setOnInsert uniquement."""
    defaults = [
        {
            "slug": "main-navigation", "name_en": "Main navigation", "name_fr": "Navigation principale",
            "location": "header", "display_order": 0,
            "items": [
                {"label_en": "Catalog", "label_fr": "Catalogue", "url": "/catalog", "display_order": 0},
                {"label_en": "Lab", "label_fr": "Labo", "url": "/lab", "display_order": 1},
                {"label_en": "About", "label_fr": "À propos", "url": "/about", "display_order": 2},
            ],
        },
        {
            "slug": "footer-shop", "name_en": "Shop", "name_fr": "Boutique",
            "location": "footer", "display_order": 1,
            "items": [
                {"label_en": "Catalog", "label_fr": "Catalogue", "url": "/catalog", "display_order": 0},
                {"label_en": "Healing & Recovery", "label_fr": "Guérison et récupération", "url": "/catalog?cat=healing", "display_order": 1},
                {"label_en": "Weight Management", "label_fr": "Gestion du poids", "url": "/catalog?cat=weight-loss", "display_order": 2},
                {"label_en": "Cognitive", "label_fr": "Cognitif", "url": "/catalog?cat=cognitive", "display_order": 3},
            ],
        },
        {
            "slug": "footer-legal", "name_en": "Legal", "name_fr": "Légal",
            "location": "footer", "display_order": 2,
            "items": [
                {"label_en": "Terms", "label_fr": "Conditions", "url": "/compliance", "display_order": 0},
                {"label_en": "Privacy", "label_fr": "Confidentialité", "url": "/privacy", "display_order": 1},
                {"label_en": "Shipping", "label_fr": "Expédition", "url": "/compliance#shipping", "display_order": 2},
                {"label_en": "FAQ", "label_fr": "FAQ", "url": "/faq", "display_order": 3},
            ],
        },
    ]
    try:
        for m in defaults:
            items = []
            for it in m["items"]:
                items.append({
                    "id": str(uuid.uuid4()), "published": True, "open_new_tab": False, **it,
                })
            await db.menus.update_one(
                {"slug": m["slug"]},
                {"$setOnInsert": {
                    "id": str(uuid.uuid4()),
                    "slug": m["slug"], "name_en": m["name_en"], "name_fr": m["name_fr"],
                    "location": m["location"], "published": True,
                    "display_order": m["display_order"], "items": items,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                }},
                upsert=True,
            )
    except Exception as e:  # pragma: no cover
        logging.error("menus seed failed: %s", e)


async def _seed_launch_coupon() -> None:
    """Provisionne le coupon de lancement 15 %. $setOnInsert : si tu l'édites
    ensuite dans l'admin, le redéploiement ne l'écrase pas."""
    try:
        await db.coupons.update_one(
            {"code": LAUNCH_COUPON_CODE},
            {"$setOnInsert": {
                "id": str(uuid.uuid4()),
                "code": LAUNCH_COUPON_CODE,
                "discount_type": "percent",
                "value": 15.0,
                "min_subtotal": 0.0,
                "usage_limit": None,
                "used_count": 0,
                "active": True,
                "expires_at": None,
                "deleted_at": None,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }},
            upsert=True,
        )
    except Exception as e:  # pragma: no cover
        logging.error("launch coupon seed failed: %s", e)


@app.on_event("startup")
async def startup_event():
    await seed_admin_and_products()
    await _seed_categories_from_products()
    await _seed_default_menus()
    await _seed_launch_coupon()
    if await _acquire_worker_lock("background_tasks"):
        asyncio.create_task(_unpaid_orders_watchdog())
        asyncio.create_task(_backfill_dispatch_batch())
        # Dispatch manuel : watchdog d'auto-étiquetage désactivé.
        # asyncio.create_task(_auto_label_paid_orders_watchdog())
        asyncio.create_task(_auto_sync_delivered_orders_watchdog())
        asyncio.create_task(_trash_auto_purge_watchdog())
        asyncio.create_task(_rollover_watchdog())
        asyncio.create_task(_magic_tokens_cleanup())
        asyncio.create_task(_abandoned_cart_watchdog())
        asyncio.create_task(affiliate_maintenance_watchdog())


async def _backfill_dispatch_batch():
    """Renseigne dispatch_batch pour les commandes payées qui n'en ont pas (non destructif)."""
    try:
        cursor = db.orders.find(
            {"payment_status": "paid", "paid_at": {"$ne": None},
             "dispatch_batch": {"$in": [None, ""]}},
            {"_id": 0, "id": 1, "paid_at": 1},
        )
        n = 0
        async for o in cursor:
            batch = compute_dispatch_batch(o["paid_at"])
            await db.orders.update_one({"id": o["id"]}, {"$set": {"dispatch_batch": batch}})
            n += 1
        if n:
            logging.info("dispatch_batch backfill: %d commande(s) mise(s) à jour", n)
    except Exception as e:  # pragma: no cover
        logging.error("dispatch_batch backfill failed: %s", e)


@app.on_event("shutdown")
async def shutdown_event():
    client.close()


# ---------------------------------------------------------------------------
# App wiring
# ---------------------------------------------------------------------------

# ===== FIRONOVA_AFFILIATE_BLOCK_START =====
# ===========================================================================
# CONSTANTES DU PROGRAMME
# ===========================================================================

AFFILIATE_INVITE_TTL_HOURS = 168          # 7 jours
AFFILIATE_COOKIE_DAYS = 30                # fenêtre d'attribution du clic
AFFILIATE_CLICK_TTL_DAYS = 45             # rétention des clics (purge auto)
AFFILIATE_COOKIE_NAME = "fn_ref"
AFFILIATE_INVITE_MAX = 5                  # rate-limit renvois / fenêtre
AFFILIATE_INVITE_WINDOW = 3600            # 1 h

# Paliers cumulés (seuil bas inclus, seuil haut exclu sauf Diamond).
# (rate, floor, ceil)  — ceil None = illimité
AFFILIATE_TIERS = [
    ("standard", 0.10, 0.0, 2000.0),
    ("bronze", 0.12, 2001.0, 5000.0),
    ("silver", 0.14, 5001.0, 10000.0),
    ("gold", 0.16, 10001.0, 20000.0),
    ("platinum", 0.18, 20001.0, 35000.0),
    ("diamond", 0.20, 35001.0, None),
]

AFFILIATE_TIER_LABELS = {
    "standard": {"fr": "Standard", "en": "Standard"},
    "bronze": {"fr": "Bronze", "en": "Bronze"},
    "silver": {"fr": "Argent", "en": "Silver"},
    "gold": {"fr": "Or", "en": "Gold"},
    "platinum": {"fr": "Platine", "en": "Platinum"},
    "diamond": {"fr": "Diamant", "en": "Diamond"},
}


def _affiliate_tier_for_revenue(cumulative_revenue: float) -> str:
    """Palier théorique pour un CA cumulé donné (sans plancher trimestriel)."""
    rev = float(cumulative_revenue or 0.0)
    tier = "standard"
    for name, _rate, floor, _ceil in AFFILIATE_TIERS:
        if rev >= floor:
            tier = name
    return tier


def _affiliate_rate_for_tier(tier: str) -> float:
    for name, rate, _floor, _ceil in AFFILIATE_TIERS:
        if name == tier:
            return rate
    return 0.10


def _affiliate_tier_index(tier: str) -> int:
    for i, (name, _r, _f, _c) in enumerate(AFFILIATE_TIERS):
        if name == tier:
            return i
    return 0


def _affiliate_tier_bounds(tier: str):
    for name, _r, floor, ceil in AFFILIATE_TIERS:
        if name == tier:
            return floor, ceil
    return 0.0, 2000.0


def _affiliate_next_tier(tier: str):
    idx = _affiliate_tier_index(tier)
    if idx + 1 < len(AFFILIATE_TIERS):
        n = AFFILIATE_TIERS[idx + 1]
        return {"tier": n[0], "rate": n[1], "floor": n[2]}
    return None


# ===========================================================================
# HACHAGE : token d'invitation + IP salée
# ===========================================================================

def _affiliate_hash_token(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _affiliate_ip_salt() -> bytes:
    # Dérivé de JWT_SECRET (déjà obligatoire) — pas de nouvelle variable d'env
    # requise. Permet de comparer "même IP ?" sans jamais stocker l'IP en clair.
    secret = os.environ.get("JWT_SECRET", "fironova-fallback-salt")
    return hashlib.sha256(("aff-ip::" + secret).encode("utf-8")).digest()


def _affiliate_hash_ip(ip: Optional[str]) -> Optional[str]:
    if not ip:
        return None
    return hmac.new(_affiliate_ip_salt(), ip.encode("utf-8"), hashlib.sha256).hexdigest()


def _affiliate_gen_code() -> str:
    # Code de parrainage lisible : FN + 6 caractères base32 sans ambiguïté.
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    return "FN" + "".join(secrets.choice(alphabet) for _ in range(6))


def _affiliate_quarter_start(now: Optional[datetime] = None) -> datetime:
    now = now or datetime.now(timezone.utc)
    q_month = 3 * ((now.month - 1) // 3) + 1
    return now.replace(month=q_month, day=1, hour=0, minute=0,
                       second=0, microsecond=0)


def _affiliate_next_quarter_start(now: Optional[datetime] = None) -> datetime:
    qs = _affiliate_quarter_start(now)
    # +3 mois
    month = qs.month + 3
    year = qs.year + (1 if month > 12 else 0)
    month = month - 12 if month > 12 else month
    return qs.replace(year=year, month=month)


# ===========================================================================
# MODÈLES Pydantic
# ===========================================================================

class AffiliateInviteIn(BaseModel):
    email: EmailStr
    name: str = Field(min_length=1, max_length=160)
    commission_note: Optional[str] = ""        # note interne admin
    payout_currency: Optional[str] = "btc"     # devise crypto de payout par défaut
    lang: str = "fr"


class AffiliateJoinIn(BaseModel):
    token: str = Field(min_length=10)
    # L'email n'est PAS fourni par le client : il est lu depuis l'invitation.
    payout_address: Optional[str] = ""         # adresse crypto de réception
    payout_currency: Optional[str] = None


class AffiliatePayoutSettingsIn(BaseModel):
    payout_address: str = Field(min_length=4, max_length=200)
    payout_currency: str = Field(min_length=2, max_length=12)


class AffiliateAdminUpdateIn(BaseModel):
    model_config = ConfigDict(extra="ignore")
    status: Optional[Literal["invited", "active", "suspended"]] = None
    compliance_status: Optional[Literal["compliant", "review", "suspended"]] = None
    manual_tier: Optional[str] = None          # override manuel du palier
    commission_note: Optional[str] = None


class AffiliatePayoutMarkIn(BaseModel):
    reference: str = Field(min_length=1, max_length=200)   # tx hash / réf
    note: Optional[str] = ""


# ===========================================================================
# CALCUL DES MÉTRIQUES D'UN AFFILIÉ
# ===========================================================================

async def _affiliate_compute_metrics(affiliate_id: str) -> dict:
    """Agrège les référrals validés (approved|paid) en CA cumulé + trimestriel,
    calcule le palier avec plancher trimestriel (baisse d'un niveau max)."""
    q_start = _affiliate_quarter_start()

    cumulative = 0.0
    quarter = 0.0
    pending_commission = 0.0
    approved_commission = 0.0
    paid_commission = 0.0
    validated_orders = 0

    cursor = db.affiliate_referrals.find(
        {"affiliate_id": affiliate_id}, {"_id": 0}
    )
    async for r in cursor:
        status = r.get("status")
        base = float(r.get("base_amount", 0.0))       # produits HT
        comm = float(r.get("commission_amount", 0.0))
        if status in ("approved", "paid"):
            cumulative += base
            validated_orders += 1
            created = r.get("approved_at") or r.get("created_at")
            if created:
                try:
                    dt = datetime.fromisoformat(str(created).replace("Z", "+00:00"))
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    if dt >= q_start:
                        quarter += base
                except Exception:
                    pass
        if status == "pending":
            pending_commission += comm
        elif status == "approved":
            approved_commission += comm
        elif status == "paid":
            paid_commission += comm

    # Palier théorique selon CA cumulé
    theoretical = _affiliate_tier_for_revenue(cumulative)

    # Plancher trimestriel : si le CA du trimestre est SOUS le seuil du palier
    # théorique, on descend d'UN niveau max (jamais plus).
    floor, _ceil = _affiliate_tier_bounds(theoretical)
    effective = theoretical
    if quarter < floor and _affiliate_tier_index(theoretical) > 0:
        prev = AFFILIATE_TIERS[_affiliate_tier_index(theoretical) - 1]
        effective = prev[0]

    rate = _affiliate_rate_for_tier(effective)
    nxt = _affiliate_next_tier(effective)
    remaining = None
    progress = None
    if nxt:
        remaining = max(0.0, nxt["floor"] - cumulative)
        span = nxt["floor"] - _affiliate_tier_bounds(effective)[0]
        if span > 0:
            progress = min(1.0, (cumulative - _affiliate_tier_bounds(effective)[0]) / span)

    return {
        "cumulative_revenue": round(cumulative, 2),
        "quarter_revenue": round(quarter, 2),
        "validated_orders": validated_orders,
        "tier": effective,
        "tier_theoretical": theoretical,
        "commission_rate": rate,
        "next_tier": nxt,
        "remaining_to_next": round(remaining, 2) if remaining is not None else None,
        "progress_to_next": round(progress, 4) if progress is not None else None,
        "pending_commission": round(pending_commission, 2),
        "approved_commission": round(approved_commission, 2),
        "paid_commission": round(paid_commission, 2),
        "next_review": _affiliate_next_quarter_start().isoformat(),
    }


def _affiliate_public(aff: dict, metrics: Optional[dict] = None, lang: str = "fr") -> dict:
    """Représentation exposée à l'affilié (jamais de champs internes sensibles)."""
    out = {
        "id": aff.get("id"),
        "code": aff.get("code"),
        "name": aff.get("name"),
        "email": aff.get("email"),
        "status": aff.get("status"),
        "compliance_status": aff.get("compliance_status", "compliant"),
        "payout_currency": aff.get("payout_currency", "btc"),
        "payout_address": aff.get("payout_address", ""),
        "activated_at": aff.get("activated_at"),
        "created_at": aff.get("created_at"),
    }
    if metrics:
        out.update(metrics)
        out["tier_label"] = AFFILIATE_TIER_LABELS.get(
            metrics["tier"], {}).get("fr" if lang.startswith("fr") else "en", metrics["tier"])
    return out


# ===========================================================================
# EMAILS (NOVA identity, cohérent avec _send_magic_email)
# ===========================================================================

def _affiliate_invite_html(name: str, link: str, lang: str) -> tuple:
    fr = lang.startswith("fr")
    if fr:
        subject = "Invitation — Programme d'affiliation Fironova"
        heading = "Vous êtes invité(e)"
        intro = (f"Bonjour {name}, vous avez été invité(e) à rejoindre le "
                 "programme d'affiliation privé de Fironova. Activez votre "
                 "compte pour accéder à votre tableau de bord.")
        cta = "Activer mon compte affilié"
        expiry = f"Ce lien expire dans {AFFILIATE_INVITE_TTL_HOURS // 24} jours et ne sert qu'une fois."
        ignore = "Si vous n'attendiez pas cette invitation, ignorez cet email."
    else:
        subject = "Invitation — Fironova Affiliate Program"
        heading = "You're invited"
        intro = (f"Hi {name}, you've been invited to join Fironova's private "
                 "affiliate program. Activate your account to access your dashboard.")
        cta = "Activate my affiliate account"
        expiry = f"This link expires in {AFFILIATE_INVITE_TTL_HOURS // 24} days and works only once."
        ignore = "If you weren't expecting this invitation, you can ignore this email."
    html = f"""\
<div style="font-family:Inter,-apple-system,Segoe UI,sans-serif;max-width:520px;margin:0 auto;background:#F7FAFC;padding:40px 24px;">
  <div style="background:#0B2E4F;border-radius:20px 20px 0 0;padding:28px 32px;">
    <span style="font-family:'Space Grotesk',sans-serif;color:#F7FAFC;font-size:20px;font-weight:700;letter-spacing:-0.02em;">FIRONOVA</span>
    <span style="color:#00B8D4;font-size:20px;font-weight:700;"> ·</span>
  </div>
  <div style="background:#ffffff;border-radius:0 0 20px 20px;padding:36px 32px;border:1px solid #E2E8F0;border-top:none;">
    <h1 style="font-family:'Space Grotesk',sans-serif;color:#0B2E4F;font-size:24px;font-weight:700;margin:0 0 12px;">{heading}</h1>
    <p style="color:#334155;font-size:15px;line-height:1.6;margin:0 0 28px;">{intro}</p>
    <a href="{link}" style="display:inline-block;background:#00B8D4;color:#0B2E4F;font-weight:700;text-decoration:none;padding:14px 32px;border-radius:999px;font-size:15px;">{cta} &rarr;</a>
    <p style="color:#64748B;font-size:12px;line-height:1.6;margin:28px 0 0;font-family:'JetBrains Mono',monospace;">{expiry}</p>
    <p style="color:#94A3B8;font-size:12px;line-height:1.6;margin:8px 0 0;">{ignore}</p>
    <hr style="border:none;border-top:1px solid #E2E8F0;margin:24px 0 12px;">
    <p style="color:#94A3B8;font-size:11px;line-height:1.5;margin:0;">Produits destin&eacute;s &agrave; la recherche uniquement (RUO). R&eacute;serv&eacute; aux 18 ans et plus.<br>For Research Use Only. 18+ only.</p>
  </div>
</div>"""
    return subject, html


async def _affiliate_send_invite(email: str, name: str, link: str, lang: str) -> None:
    subject, html = _affiliate_invite_html(name, link, lang)
    from_addr = (globals().get("MAGIC_SENDER_EMAIL") or
                 globals().get("SENDER_EMAIL") or "orders@fironova.com")
    await _send_email(email, subject, html, from_email=from_addr)  # noqa: F821


# ===========================================================================
# ATTRIBUTION — appelée depuis checkout() et _mark_order_paid() / refund
# ===========================================================================

async def affiliate_capture_click(request: Request, response: Response, code: str) -> None:
    """Pose le cookie d'attribution (httpOnly) + journalise le clic.
    À appeler depuis un endpoint public GET /affiliate/ref/{code} ou au 1er hit
    du site avec ?ref=CODE (voir wiring frontend)."""
    code = (code or "").strip().upper()
    if not code:
        return
    affiliate = await db.affiliates.find_one(
        {"code": code, "status": "active"}, {"_id": 0, "id": 1, "code": 1}
    )
    if not affiliate:
        return
    now = datetime.now(timezone.utc)
    response.set_cookie(
        AFFILIATE_COOKIE_NAME, code,
        max_age=AFFILIATE_COOKIE_DAYS * 86400,
        httponly=True, samesite="lax", secure=True, path="/",
    )
    await db.affiliate_clicks.insert_one({
        "id": str(uuid.uuid4()),
        "affiliate_id": affiliate["id"],
        "code": code,
        "ip_hash": _affiliate_hash_ip(_client_ip(request)),  # noqa: F821
        "user_agent": (request.headers.get("user-agent", "") or "")[:300],
        "created_at": now.isoformat(),
        "expires_at": (now + timedelta(days=AFFILIATE_CLICK_TTL_DAYS)).isoformat(),
    })


async def affiliate_attach_to_order(order_doc: dict, request: Request) -> None:
    """Lit le cookie fn_ref et attache l'affilié à la commande (champ additif).
    Anti auto-parrainage : refuse si l'email de commande == email affilié.
    À appeler DANS checkout() juste avant db.orders.insert_one(order_doc)."""
    code = request.cookies.get(AFFILIATE_COOKIE_NAME)
    if not code:
        return
    code = code.strip().upper()
    affiliate = await db.affiliates.find_one(
        {"code": code, "status": "active"}, {"_id": 0}
    )
    if not affiliate:
        return
    order_email = (order_doc.get("email") or "").lower().strip()
    # Auto-parrainage direct (même email) : bloqué d'emblée.
    if order_email and order_email == (affiliate.get("email") or "").lower().strip():
        return
    order_doc["affiliate_id"] = affiliate["id"]
    order_doc["affiliate_code"] = affiliate["code"]
    order_doc["affiliate_ip_hash"] = _affiliate_hash_ip(_client_ip(request))  # noqa: F821


async def _affiliate_is_self_order(affiliate: dict, order: dict) -> bool:
    """self-order = email OU adresse de livraison OU IP hachée en commun avec
    l'affilié ou avec une commande antérieure déjà marquée self-order."""
    aff_email = (affiliate.get("email") or "").lower().strip()
    order_email = (order.get("email") or "").lower().strip()
    if aff_email and order_email and aff_email == order_email:
        return True

    # IP du clic/commande == IP connue de l'affilié (invite/activation)
    order_ip_hash = order.get("affiliate_ip_hash")
    if order_ip_hash and order_ip_hash == affiliate.get("ip_hash"):
        return True

    # Adresse de livraison identique à une adresse connue de l'affilié
    addr = order.get("shipping_address") or {}
    norm = _affiliate_norm_address(addr)
    if norm and norm in (affiliate.get("known_addresses") or []):
        return True
    return False


def _affiliate_norm_address(addr: dict) -> str:
    if not addr:
        return ""
    parts = [
        (addr.get("address1") or "").lower().strip(),
        (addr.get("postal_code") or "").lower().replace(" ", ""),
    ]
    return "|".join(p for p in parts if p)


async def affiliate_on_order_paid(order: dict) -> None:
    """Crée la commission 'pending' au paiement confirmé.
    À appeler DANS _mark_order_paid(), après la transition réussie.
    Idempotent : index unique sur order_id empêche le double comptage."""
    affiliate_id = order.get("affiliate_id")
    if not affiliate_id:
        return
    affiliate = await db.affiliates.find_one({"id": affiliate_id}, {"_id": 0})
    if not affiliate or affiliate.get("status") != "active":
        return

    # Base = sous-total produits HT (hors port, hors taxes), net de remise.
    subtotal = float(order.get("subtotal", 0.0))
    discount = float(order.get("discount", 0.0))
    base = max(0.0, round(subtotal - discount, 2))
    if base <= 0:
        return

    # Exclusion self-order
    if await _affiliate_is_self_order(affiliate, order):
        excluded_reason = "self_order"
        status = "excluded"
        commission = 0.0
    else:
        excluded_reason = None
        status = "pending"
        # Taux au palier EFFECTIF courant de l'affilié
        metrics = await _affiliate_compute_metrics(affiliate_id)
        commission = round(base * metrics["commission_rate"], 2)

    now = datetime.now(timezone.utc).isoformat()
    doc = {
        "id": str(uuid.uuid4()),
        "affiliate_id": affiliate_id,
        "affiliate_code": affiliate.get("code"),
        "order_id": order.get("id"),
        "order_number": order.get("order_number"),
        "order_email": order.get("email"),
        "base_amount": base,
        "commission_amount": commission,
        "status": status,                       # pending|approved|paid<reversed|excluded
        "excluded_reason": excluded_reason,
        "created_at": now,
        "approved_at": None,
        "paid_at": None,
        "payout_id": None,
    }
    try:
        await db.affiliate_referrals.insert_one(doc)
    except Exception as e:
        # index unique (order_id) → déjà comptée, on ignore silencieusement
        logging.info("[affiliate] referral already exists for order %s (%s)",
                     order.get("order_number"), e)


async def affiliate_on_order_reversed(order_id: str, full: bool = True) -> None:
    """Passe la commission liée à 'reversed' lors d'un remboursement total /
    chargeback. À appeler depuis admin_refund_order() quand new_refunded>=total,
    et depuis le webhook chargeback si présent."""
    if not full:
        return
    now = datetime.now(timezone.utc).isoformat()
    await db.affiliate_referrals.update_many(
        {"order_id": order_id, "status": {"$in": ["pending", "approved"]}},
        {"$set": {"status": "reversed", "reversed_at": now}},
    )


# ===========================================================================
# TÂCHE : approbation automatique après fenêtre de rétractation
# ===========================================================================

AFFILIATE_APPROVAL_HOLD_DAYS = 14  # délai avant qu'une commission 'pending'
#                                    devienne 'approved' (fenêtre refund)


async def _affiliate_approve_matured():
    """Passe pending→approved les commissions dont l'ordre est payé depuis
    plus de AFFILIATE_APPROVAL_HOLD_DAYS jours et non remboursé."""
    cutoff = (datetime.now(timezone.utc) -
              timedelta(days=AFFILIATE_APPROVAL_HOLD_DAYS)).isoformat()
    now = datetime.now(timezone.utc).isoformat()
    cursor = db.affiliate_referrals.find(
        {"status": "pending", "created_at": {"$lte": cutoff}}, {"_id": 0}
    )
    async for r in cursor:
        order = await db.orders.find_one(
            {"id": r["order_id"]}, {"_id": 0, "payment_status": 1}
        )
        if order and order.get("payment_status") == "paid":
            await db.affiliate_referrals.update_one(
                {"id": r["id"], "status": "pending"},
                {"$set": {"status": "approved", "approved_at": now}},
            )


async def _affiliate_clicks_cleanup():
    """Purge des clics expirés (rétention limitée — proportionnalité Loi 25)."""
    now = datetime.now(timezone.utc).isoformat()
    try:
        await db.affiliate_clicks.delete_many({"expires_at": {"$lt": now}})
    except Exception as e:  # pragma: no cover
        logging.error("[affiliate] clicks cleanup failed: %s", e)


async def affiliate_maintenance_watchdog():
    """Boucle de maintenance (à lancer au startup si worker lock acquis)."""
    while True:
        try:
            await _affiliate_approve_matured()
            await _affiliate_clicks_cleanup()
        except Exception as e:  # pragma: no cover
            logging.error("[affiliate] maintenance error: %s", e)
        await asyncio.sleep(3600)  # toutes les heures


async def affiliate_ensure_indexes():
    """Index — à appeler dans seed_admin_and_products() ou au startup."""
    await db.affiliates.create_index("id", unique=True)
    await db.affiliates.create_index("code", unique=True, sparse=True)
    await db.affiliates.create_index("email", unique=True)
    await db.affiliates.create_index("user_id", sparse=True)
    await db.affiliate_referrals.create_index("order_id", unique=True)
    await db.affiliate_referrals.create_index("affiliate_id")
    await db.affiliate_referrals.create_index("status")
    await db.affiliate_clicks.create_index("affiliate_id")
    await db.affiliate_clicks.create_index("expires_at")
    await db.affiliate_payouts.create_index("id", unique=True)
    await db.affiliate_payouts.create_index("affiliate_id")


# ===========================================================================
# DÉPENDANCE : affilié courant (compte user avec is_affiliate + affiliate lié)
# ===========================================================================

async def get_current_affiliate(request: Request) -> dict:
    user = await get_current_user(request)  # noqa: F821
    aff = await db.affiliates.find_one(
        {"user_id": user["id"], "status": {"$in": ["active", "suspended"]}},
        {"_id": 0},
    )
    if not aff:
        raise HTTPException(403, "Not an affiliate")
    if aff.get("status") == "suspended":
        raise HTTPException(403, "Affiliate account suspended")
    return aff


# ===========================================================================
# ENDPOINTS — AFFILIÉ (dashboard)
# ===========================================================================

@api.post("/affiliate/join")  # noqa: F821
async def affiliate_join(payload: AffiliateJoinIn, request: Request):
    """Active un compte affilié à partir d'un token d'invitation.
    L'utilisateur DOIT être connecté (auth existante), et son email doit
    correspondre à l'email de l'invitation. Token consommé atomiquement."""
    user = await get_current_user(request)  # noqa: F821
    token_hash = _affiliate_hash_token(payload.token.strip())
    now = datetime.now(timezone.utc)

    invite = await db.affiliates.find_one(
        {"invite_token_hash": token_hash, "status": "invited"}, {"_id": 0}
    )
    if not invite:
        raise HTTPException(400, "Invalid or already-used invitation")
    # Expiration
    exp = invite.get("invite_expires_at")
    if exp:
        try:
            exp_dt = datetime.fromisoformat(exp.replace("Z", "+00:00"))
            if exp_dt.tzinfo is None:
                exp_dt = exp_dt.replace(tzinfo=timezone.utc)
            if now > exp_dt:
                raise HTTPException(400, "Invitation expired")
        except HTTPException:
            raise
        except Exception:
            pass
    # Verrou email : l'email connecté doit matcher l'email invité
    if (user.get("email") or "").lower().strip() != (invite.get("email") or "").lower().strip():
        raise HTTPException(403, "This invitation is bound to a different email address")

    code = _affiliate_gen_code()
    # collision improbable, mais on garantit l'unicité
    for _ in range(5):
        if not await db.affiliates.find_one({"code": code}, {"_id": 1}):
            break
        code = _affiliate_gen_code()

    known_addresses = []
    # (aucune adresse connue à l'activation ; se remplit via les commandes)
    update = {
        "$set": {
            "status": "active",
            "user_id": user["id"],
            "code": code,
            "activated_at": now.isoformat(),
            "ip_hash": _affiliate_hash_ip(_client_ip(request)),  # noqa: F821
            "known_addresses": known_addresses,
            "payout_address": (payload.payout_address or "").strip(),
            "payout_currency": (payload.payout_currency or invite.get("payout_currency") or "btc"),
            # invalide le token (consommation atomique)
            "invite_token_hash": None,
            "invite_expires_at": None,
        }
    }
    res = await db.affiliates.update_one(
        {"id": invite["id"], "status": "invited"}, update
    )
    if not res.modified_count:
        raise HTTPException(409, "Invitation already consumed")

    aff = await db.affiliates.find_one({"id": invite["id"]}, {"_id": 0})
    metrics = await _affiliate_compute_metrics(aff["id"])
    return _affiliate_public(aff, metrics)


@api.get("/affiliate/me")  # noqa: F821
async def affiliate_me(request: Request, lang: str = "fr"):
    aff = await get_current_affiliate(request)
    metrics = await _affiliate_compute_metrics(aff["id"])
    return _affiliate_public(aff, metrics, lang=lang)


@api.get("/affiliate/referrals")  # noqa: F821
async def affiliate_referrals(request: Request, limit: int = 200):
    aff = await get_current_affiliate(request)
    rows = await db.affiliate_referrals.find(
        {"affiliate_id": aff["id"], "status": {"$ne": "excluded"}},
        {"_id": 0, "order_email": 0, "affiliate_ip_hash": 0},
    ).sort("created_at", -1).to_list(min(limit, 500))
    return rows


@api.get("/affiliate/payouts")  # noqa: F821
async def affiliate_payouts(request: Request):
    aff = await get_current_affiliate(request)
    rows = await db.affiliate_payouts.find(
        {"affiliate_id": aff["id"]}, {"_id": 0}
    ).sort("created_at", -1).to_list(200)
    return rows


@api.put("/affiliate/payout-settings")  # noqa: F821
async def affiliate_payout_settings(payload: AffiliatePayoutSettingsIn, request: Request):
    aff = await get_current_affiliate(request)
    await db.affiliates.update_one(
        {"id": aff["id"]},
        {"$set": {"payout_address": payload.payout_address.strip(),
                  "payout_currency": payload.payout_currency.strip().lower()}},
    )
    fresh = await db.affiliates.find_one({"id": aff["id"]}, {"_id": 0})
    return _affiliate_public(fresh)


@api.get("/affiliate/performance")  # noqa: F821
async def affiliate_performance(request: Request):
    """Séries mensuelles (12 derniers mois) de CA validé pour les graphiques."""
    aff = await get_current_affiliate(request)
    buckets: dict = {}
    cursor = db.affiliate_referrals.find(
        {"affiliate_id": aff["id"], "status": {"$in": ["approved", "paid"]}},
        {"_id": 0, "base_amount": 1, "approved_at": 1, "created_at": 1},
    )
    async for r in cursor:
        ts = r.get("approved_at") or r.get("created_at")
        if not ts:
            continue
        try:
            dt = datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
        except Exception:
            continue
        key = f"{dt.year}-{dt.month:02d}"
        buckets[key] = round(buckets.get(key, 0.0) + float(r.get("base_amount", 0.0)), 2)
    series = [{"month": k, "revenue": v} for k, v in sorted(buckets.items())]
    return {"series": series}


# ===========================================================================
# ENDPOINTS — ATTRIBUTION PUBLIQUE (pose du cookie)
# ===========================================================================

@api.get("/affiliate/ref/{code}")  # noqa: F821
async def affiliate_ref(code: str, request: Request, response: Response):
    """Endpoint de tracking : pose le cookie et renvoie ok. Le frontend appelle
    ceci au 1er chargement quand ?ref=CODE est présent dans l'URL."""
    _rate_limit("affiliate_ref", _client_ip(request), 60, 60,  # noqa: F821
                "Trop de requêtes.")
    await affiliate_capture_click(request, response, code)
    return {"ok": True}


# ===========================================================================
# ENDPOINTS — ADMIN
# ===========================================================================

@api.post("/admin/affiliates/invite")  # noqa: F821
async def admin_affiliate_invite(payload: AffiliateInviteIn,
                                 admin: dict = Depends(get_admin_user)):  # noqa: F821
    """Crée (ou ré-invite) un affilié verrouillé à un email. Envoie l'email."""
    email = payload.email.lower().strip()
    raw = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    expires = (now + timedelta(hours=AFFILIATE_INVITE_TTL_HOURS)).isoformat()

    existing = await db.affiliates.find_one({"email": email}, {"_id": 0})
    if existing and existing.get("status") == "active":
        raise HTTPException(409, "This email is already an active affiliate")

    if existing:
        # ré-invitation : régénère le token, l'ancien meurt
        await db.affiliates.update_one(
            {"id": existing["id"]},
            {"$set": {
                "invite_token_hash": _affiliate_hash_token(raw),
                "invite_expires_at": expires,
                "name": payload.name.strip(),
                "status": "invited",
                "payout_currency": payload.payout_currency or "btc",
                "invite_last_sent_at": now.isoformat(),
            },
             "$inc": {"invite_sent_count": 1}},
        )
        aff_id = existing["id"]
    else:
        aff_id = str(uuid.uuid4())
        await db.affiliates.insert_one({
            "id": aff_id,
            "email": email,
            "name": payload.name.strip(),
            "code": None,
            "user_id": None,
            "status": "invited",
            "compliance_status": "compliant",
            "manual_tier": None,
            "commission_note": payload.commission_note or "",
            "payout_currency": payload.payout_currency or "btc",
            "payout_address": "",
            "ip_hash": None,
            "known_addresses": [],
            "invite_token_hash": _affiliate_hash_token(raw),
            "invite_expires_at": expires,
            "invite_sent_count": 1,
            "invite_last_sent_at": now.isoformat(),
            "created_at": now.isoformat(),
            "activated_at": None,
        })

    base = (globals().get("PUBLIC_BASE_URL") or "").rstrip("/")
    if not base:
        base = str(request_base_url_safe())  # fallback
    link = f"{base}/affiliate/join?token={raw}"
    await _affiliate_send_invite(email, payload.name.strip(), link, payload.lang or "fr")
    return {"ok": True, "affiliate_id": aff_id, "invite_link": link}


def request_base_url_safe() -> str:
    return (globals().get("PUBLIC_BASE_URL") or "").rstrip("/")


@api.post("/admin/affiliates/{affiliate_id}/resend-invite")  # noqa: F821
async def admin_affiliate_resend(affiliate_id: str,
                                 admin: dict = Depends(get_admin_user)):  # noqa: F821
    aff = await db.affiliates.find_one({"id": affiliate_id}, {"_id": 0})
    if not aff:
        raise HTTPException(404, "Affiliate not found")
    if aff.get("status") == "active":
        raise HTTPException(400, "Affiliate already active — no invite to resend")
    _rate_limit("affiliate_invite", affiliate_id, AFFILIATE_INVITE_MAX,  # noqa: F821
                AFFILIATE_INVITE_WINDOW, "Trop de renvois. Réessayez plus tard.")
    raw = secrets.token_urlsafe(32)
    now = datetime.now(timezone.utc)
    expires = (now + timedelta(hours=AFFILIATE_INVITE_TTL_HOURS)).isoformat()
    await db.affiliates.update_one(
        {"id": affiliate_id},
        {"$set": {"invite_token_hash": _affiliate_hash_token(raw),
                  "invite_expires_at": expires,
                  "status": "invited",
                  "invite_last_sent_at": now.isoformat()},
         "$inc": {"invite_sent_count": 1}},
    )
    base = (globals().get("PUBLIC_BASE_URL") or "").rstrip("/")
    link = f"{base}/affiliate/join?token={raw}"
    await _affiliate_send_invite(aff["email"], aff.get("name", ""), link,
                                 "fr")
    return {"ok": True, "invite_link": link, "sent_to": aff["email"]}


@api.get("/admin/affiliates")  # noqa: F821
async def admin_affiliates_list(admin: dict = Depends(get_admin_user)):  # noqa: F821
    rows = await db.affiliates.find(
        {}, {"_id": 0, "invite_token_hash": 0}
    ).sort("created_at", -1).to_list(1000)
    out = []
    for aff in rows:
        metrics = await _affiliate_compute_metrics(aff["id"]) if aff.get("status") == "active" else None
        item = dict(aff)
        if metrics:
            item.update({
                "cumulative_revenue": metrics["cumulative_revenue"],
                "quarter_revenue": metrics["quarter_revenue"],
                "tier": metrics["tier"],
                "commission_rate": metrics["commission_rate"],
                "pending_commission": metrics["pending_commission"],
                "approved_commission": metrics["approved_commission"],
                "paid_commission": metrics["paid_commission"],
            })
        out.append(item)
    return out


@api.get("/admin/affiliates/{affiliate_id}")  # noqa: F821
async def admin_affiliate_detail(affiliate_id: str,
                                 admin: dict = Depends(get_admin_user)):  # noqa: F821
    aff = await db.affiliates.find_one(
        {"id": affiliate_id}, {"_id": 0, "invite_token_hash": 0}
    )
    if not aff:
        raise HTTPException(404, "Affiliate not found")
    metrics = await _affiliate_compute_metrics(affiliate_id) if aff.get("status") == "active" else None
    referrals = await db.affiliate_referrals.find(
        {"affiliate_id": affiliate_id}, {"_id": 0}
    ).sort("created_at", -1).to_list(500)
    payouts = await db.affiliate_payouts.find(
        {"affiliate_id": affiliate_id}, {"_id": 0}
    ).sort("created_at", -1).to_list(200)
    return {"affiliate": aff, "metrics": metrics,
            "referrals": referrals, "payouts": payouts}


@api.put("/admin/affiliates/{affiliate_id}")  # noqa: F821
async def admin_affiliate_update(affiliate_id: str, payload: AffiliateAdminUpdateIn,
                                 admin: dict = Depends(get_admin_user)):  # noqa: F821
    aff = await db.affiliates.find_one({"id": affiliate_id}, {"_id": 0})
    if not aff:
        raise HTTPException(404, "Affiliate not found")
    update = {k: v for k, v in payload.model_dump(exclude_none=True).items()}
    if update:
        await db.affiliates.update_one({"id": affiliate_id}, {"$set": update})
    fresh = await db.affiliates.find_one(
        {"id": affiliate_id}, {"_id": 0, "invite_token_hash": 0}
    )
    return fresh


@api.post("/admin/affiliates/payouts/run")  # noqa: F821
async def admin_affiliate_run_payouts(admin: dict = Depends(get_admin_user),  # noqa: F821
                                      period: Optional[str] = None):
    """Génère les payouts mensuels : agrège les commissions 'approved' par
    affilié en un relevé de payout (status 'ready'), marque les référrals
    comme rattachés. Le paiement crypto réel se fait ensuite hors-système,
    puis l'admin confirme via /mark-paid avec la référence de transaction."""
    now = datetime.now(timezone.utc)
    period = period or now.strftime("%Y-%m")
    created = []

    # Regroupe par affilié les commissions approuvées non encore payées
    pipeline = [
        {"$match": {"status": "approved", "payout_id": None}},
        {"$group": {"_id": "$affiliate_id",
                    "total": {"$sum": "$commission_amount"},
                    "ids": {"$push": "$id"}}},
    ]
    async for grp in db.affiliate_referrals.aggregate(pipeline):
        affiliate_id = grp["_id"]
        total = round(float(grp["total"]), 2)
        if total <= 0:
            continue
        aff = await db.affiliates.find_one({"id": affiliate_id}, {"_id": 0})
        if not aff or aff.get("status") != "active":
            continue
        payout_id = str(uuid.uuid4())
        await db.affiliate_payouts.insert_one({
            "id": payout_id,
            "affiliate_id": affiliate_id,
            "affiliate_code": aff.get("code"),
            "period": period,
            "amount": total,
            "currency": aff.get("payout_currency", "btc"),
            "payout_address": aff.get("payout_address", ""),
            "referral_ids": grp["ids"],
            "referral_count": len(grp["ids"]),
            "status": "ready",           # ready → paid
            "reference": None,
            "note": "",
            "created_at": now.isoformat(),
            "paid_at": None,
        })
        await db.affiliate_referrals.update_many(
            {"id": {"$in": grp["ids"]}},
            {"$set": {"payout_id": payout_id}},
        )
        created.append({"affiliate_id": affiliate_id, "amount": total,
                        "payout_id": payout_id})
    return {"ok": True, "period": period, "payouts_created": len(created),
            "detail": created}


@api.post("/admin/affiliates/payouts/{payout_id}/mark-paid")  # noqa: F821
async def admin_affiliate_mark_paid(payout_id: str, payload: AffiliatePayoutMarkIn,
                                    admin: dict = Depends(get_admin_user)):  # noqa: F821
    """Confirme le paiement crypto : enregistre la référence de transaction
    (traçabilité), passe le payout + ses référrals à 'paid'."""
    payout = await db.affiliate_payouts.find_one({"id": payout_id}, {"_id": 0})
    if not payout:
        raise HTTPException(404, "Payout not found")
    if payout.get("status") == "paid":
        raise HTTPException(400, "Payout already marked paid")
    now = datetime.now(timezone.utc).isoformat()
    await db.affiliate_payouts.update_one(
        {"id": payout_id},
        {"$set": {"status": "paid", "reference": payload.reference.strip(),
                  "note": payload.note or "", "paid_at": now,
                  "paid_by": admin.get("email")}},
    )
    await db.affiliate_referrals.update_many(
        {"payout_id": payout_id},
        {"$set": {"status": "paid", "paid_at": now}},
    )
    fresh = await db.affiliate_payouts.find_one({"id": payout_id}, {"_id": 0})
    return fresh


@api.get("/admin/affiliates/payouts/all")  # noqa: F821
async def admin_affiliate_payouts_all(admin: dict = Depends(get_admin_user),  # noqa: F821
                                      status: Optional[str] = None):
    filt = {}
    if status:
        filt["status"] = status
    rows = await db.affiliate_payouts.find(filt, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return rows

# ===== FIRONOVA_AFFILIATE_BLOCK_END =====



# ===== FIRONOVA_SEO_BACKEND_START =====
@api.get("/seo/health")
async def seo_health():
    return {"ok": True, "source": "fironova"}

@api.get("/seo/sitemap")
async def seo_sitemap():
    return {"sitemap": ["/", "/catalog", "/about", "/faq", "/privacy", "/compliance"]}

@api.get("/seo/product/{slug}")
async def seo_product(slug: str):
    product = await db.products.find_one({"slug": slug}, {"_id": 0, "slug": 1, "name_en": 1, "name_fr": 1, "description_en": 1, "description_fr": 1})
    if not product:
        raise HTTPException(404, "Product not found")
    return {
        "slug": product.get("slug"),
        "title": product.get("name_en") or product.get("name_fr") or slug,
        "description": product.get("description_en") or product.get("description_fr") or "",
    }
# ===== FIRONOVA_SEO_BACKEND_END =====



# ===== FIRONOVA_RELATED_PRODUCTS_START =====
@api.get("/products/{slug}/related")
async def get_related_products(slug: str, limit: int = 4):
    """Produits reliés : même catégorie d'abord, complétés par des vedettes.
    Déterministe, sans ML. Sert le cross-sell « souvent recherché avec »."""
    base = await db.products.find_one({"slug": slug}, {"_id": 0, "category": 1, "id": 1})
    if not base:
        raise HTTPException(404, "Product not found")
    limit = max(1, min(limit, 8))
    seen = {base.get("id")}
    out = []
    # 1) même catégorie, en stock en priorité
    same = await db.products.find(
        {"active": True, "category": base.get("category"), "slug": {"$ne": slug}},
        {"_id": 0},
    ).sort("featured", -1).to_list(50)
    for p in same:
        if p.get("id") in seen:
            continue
        seen.add(p.get("id")); out.append(p)
        if len(out) >= limit:
            return out
    # 2) compléter avec des vedettes d'autres catégories
    feat = await db.products.find(
        {"active": True, "featured": True, "slug": {"$ne": slug}},
        {"_id": 0},
    ).to_list(50)
    for p in feat:
        if p.get("id") in seen:
            continue
        seen.add(p.get("id")); out.append(p)
        if len(out) >= limit:
            break
    return out
# ===== FIRONOVA_RELATED_PRODUCTS_END =====



# ===== FIRONOVA_CUSTOMERS_ENRICHED_START =====
@api.get("/admin/customers/{user_id}")
async def admin_customer_detail(user_id: str, _admin: dict = Depends(require_area("customers", "view"))):
    """Fiche client complète avec historique de commandes."""
    u = await db.users.find_one(
        {"id": user_id}, {"_id": 0, "password_hash": 0, "token_version": 0}
    )
    if not u:
        raise HTTPException(404, "Customer not found")
    orders = await db.orders.find(
        {"email": (u.get("email") or "").lower()}, {"_id": 0}
    ).sort("created_at", -1).to_list(200)
    paid = [o for o in orders if o.get("payment_status") == "paid"]
    total_spent = round(sum(o.get("total", 0) for o in paid), 2)
    aov = round(total_spent / len(paid), 2) if paid else 0.0
    return {
        "customer": u,
        "orders": orders,
        "summary": {
            "total_spent": total_spent,
            "paid_orders": len(paid),
            "all_orders": len(orders),
            "aov": aov,
        },
    }
# ===== FIRONOVA_CUSTOMERS_ENRICHED_END =====



# ===== FIRONOVA_ANALYTICS_ENHANCED_START =====
TAX_THRESHOLD_CAD = 30000.0          # seuil d'inscription TPS/TVQ (petit fournisseur)
TAX_ALERT_RATIO = 0.80               # alerte "approche" à 80 % du seuil
_UNPAID = ["pending", "awaiting_etransfer", "awaiting_crypto"]


def _pct_change(cur: float, prev: float):
    """Variation en % ; None si base précédente nulle (évite division par zéro)."""
    if prev == 0:
        return None
    return round((cur - prev) / prev * 100, 1)


@api.get("/admin/analytics/enhanced")  # noqa: F821
async def admin_analytics_enhanced(period: int = 30,
                                   _admin: dict = Depends(require_area("dashboard", "view"))):  # noqa: F821
    """Métriques de pilotage avec comparaison période courante vs précédente."""
    if period not in (7, 30, 90):
        period = 30
    now = datetime.now(timezone.utc)
    cur_start = now - timedelta(days=period)
    prev_start = now - timedelta(days=period * 2)
    cur_start_s = cur_start.isoformat()
    prev_start_s = prev_start.isoformat()

    # ---- Période courante : commandes payées ----
    async def _period_stats(start_s: str, end_s: str) -> dict:
        cur = db.orders.aggregate([  # noqa: F821
            {"$match": {"payment_status": "paid",
                        "created_at": {"$gte": start_s, "$lt": end_s}}},
            {"$group": {"_id": None,
                        "revenue": {"$sum": "$total"},
                        "orders": {"$sum": 1}}},
        ])
        doc = await cur.to_list(1)
        rev = round(doc[0]["revenue"], 2) if doc else 0.0
        n = doc[0]["orders"] if doc else 0
        return {"revenue": rev, "orders": n, "aov": round(rev / n, 2) if n else 0.0}

    current = await _period_stats(cur_start_s, now.isoformat())
    previous = await _period_stats(prev_start_s, cur_start_s)

    # ---- Conversion : payées / créées (toutes, sur la période courante) ----
    created = await db.orders.count_documents(  # noqa: F821
        {"created_at": {"$gte": cur_start_s}})
    paid = await db.orders.count_documents(  # noqa: F821
        {"created_at": {"$gte": cur_start_s}, "payment_status": "paid"})
    abandoned = await db.orders.count_documents(  # noqa: F821
        {"created_at": {"$gte": cur_start_s}, "payment_status": {"$in": _UNPAID}})
    conversion = round(paid / created * 100, 1) if created else None

    # ---- Nouveaux vs récurrents (clients ayant payé sur la période) ----
    cur = db.orders.aggregate([  # noqa: F821
        {"$match": {"payment_status": "paid", "created_at": {"$gte": cur_start_s},
                    "email": {"$nin": [None, ""]}}},
        {"$group": {"_id": "$email"}},
    ])
    period_emails = [d["_id"] async for d in cur]
    new_customers = 0
    returning_customers = 0
    for em in period_emails:
        prior = await db.orders.count_documents(  # noqa: F821
            {"email": em, "payment_status": "paid", "created_at": {"$lt": cur_start_s}})
        if prior > 0:
            returning_customers += 1
        else:
            new_customers += 1

    # ---- Alerte seuil de taxe : CA payé sur 12 mois glissants ----
    twelve_start = (now - timedelta(days=365)).isoformat()
    ytd_cur = db.orders.aggregate([  # noqa: F821
        {"$match": {"payment_status": "paid", "created_at": {"$gte": twelve_start}}},
        {"$group": {"_id": None, "total": {"$sum": "$total"}}},
    ])
    ytd_doc = await ytd_cur.to_list(1)
    rolling_12mo = round(ytd_doc[0]["total"], 2) if ytd_doc else 0.0
    ratio = rolling_12mo / TAX_THRESHOLD_CAD if TAX_THRESHOLD_CAD else 0
    if rolling_12mo >= TAX_THRESHOLD_CAD:
        tax_level = "exceeded"
    elif ratio >= TAX_ALERT_RATIO:
        tax_level = "approaching"
    else:
        tax_level = "ok"

    return {
        "period_days": period,
        "current": current,
        "previous": previous,
        "changes": {
            "revenue": _pct_change(current["revenue"], previous["revenue"]),
            "orders": _pct_change(current["orders"], previous["orders"]),
            "aov": _pct_change(current["aov"], previous["aov"]),
        },
        "conversion": {
            "orders_created": created,
            "orders_paid": paid,
            "orders_abandoned": abandoned,
            "conversion_rate": conversion,
        },
        "customers": {
            "new": new_customers,
            "returning": returning_customers,
            "total_active": len(period_emails),
        },
        "tax_threshold": {
            "rolling_12mo_revenue": rolling_12mo,
            "threshold": TAX_THRESHOLD_CAD,
            "ratio": round(ratio, 3),
            "level": tax_level,            # ok | approaching | exceeded
            "remaining": round(max(0.0, TAX_THRESHOLD_CAD - rolling_12mo), 2),
        },
    }

# ===== FIRONOVA_ANALYTICS_ENHANCED_END =====



# ===== FIRONOVA_EMAILS_NOVA_START =====
def _email_shell(order=None, lang="en"):
    lang = (lang or "en").lower()
    if not order:
        return {"subject": "Order update", "body": "Thank you for your order."}

    if lang == "fr":
        return {
            "subject": "Confirmation de commande",
            "body": "Bonjour, votre commande est confirmée. Merci pour votre confiance.",
            "follow_up": "Vous recevrez un email de suivi dès l'expédition.",
        }
    return {
        "subject": "Order confirmation",
        "body": "Hello, your order is confirmed. Thank you for your trust.",
        "follow_up": "You will receive a shipping update as soon as your order is on the way.",
    }
# ===== FIRONOVA_EMAILS_NOVA_END =====



# ===== FIRONOVA_EMAIL_AUTOMATION_START =====
import os
import asyncio
import logging
from datetime import datetime, timezone, timedelta

ABANDON_MIN_HOURS = float(os.environ.get("ABANDON_MIN_HOURS", "4"))
ABANDON_MAX_HOURS = float(os.environ.get("ABANDON_MAX_HOURS", "72"))
ABANDON_COUPON_CODE = os.environ.get("ABANDON_COUPON_CODE", "").strip()
ABANDON_SWEEP_MINUTES = float(os.environ.get("ABANDON_SWEEP_MINUTES", "30"))
_AUTOMATION_BASE = os.environ.get("PUBLIC_BASE_URL", "https://fironova.com").rstrip("/")

# Statuts considérés « non payés » = panier/checkout abandonné
_UNPAID_STATUSES = ["pending", "awaiting_etransfer", "awaiting_crypto"]


def _nova_email_shell(heading_fr: str, heading_en: str, body_html: str,
                      cta_url: str = "", cta_label_fr: str = "", cta_label_en: str = "") -> str:
    """Gabarit email identité NOVA (Nordfjord Blue + Nova Cyan), bilingue."""
    cta = ""
    if cta_url and cta_label_fr:
        cta = f"""
      <div style="margin:28px 0 8px">
        <a href="{cta_url}" style="display:inline-block;background:#00B8D4;color:#0B2E4F;
           font-weight:700;text-decoration:none;padding:14px 32px;border-radius:999px;
           font-size:15px">{cta_label_fr} &nbsp;/&nbsp; {cta_label_en}</a>
      </div>"""
    return f"""<!DOCTYPE html>
<html><body style="margin:0;padding:0;background:#F7FAFC;font-family:'Helvetica Neue',Arial,sans-serif;color:#0B2E4F">
  <table style="width:100%;max-width:600px;margin:0 auto;background:#fff;border:1px solid #E2E8F0;border-radius:12px;overflow:hidden">
    <tr><td style="background:#0B2E4F;padding:24px 32px">
      <div style="font-family:'Space Grotesk',Arial,sans-serif;font-size:20px;font-weight:800;color:#fff;letter-spacing:-0.5px">
        FIRONOVA<span style="color:#00B8D4"> ·</span>
      </div>
    </td></tr>
    <tr><td style="padding:32px">
      <div style="font-size:22px;font-weight:800;color:#0B2E4F;letter-spacing:-0.4px;margin-bottom:4px">{heading_fr}</div>
      <div style="font-size:15px;font-style:italic;color:#3E5C76;margin-bottom:20px">{heading_en}</div>
      <div style="font-size:14px;line-height:1.7;color:#1A2A38">{body_html}</div>
      {cta}
    </td></tr>
    <tr><td style="background:#F7FAFC;padding:16px 32px;font-family:monospace;font-size:10px;letter-spacing:1px;color:#94A3B8;border-top:1px solid #E2E8F0">
      PRODUITS DESTINÉS À LA RECHERCHE UNIQUEMENT (RUO) · 18+ · Ne pas consommer.<br>
      FOR RESEARCH USE ONLY (RUO) · 18+ · Not for human consumption.
    </td></tr>
  </table>
</body></html>"""


def _abandoned_items_html(order: dict) -> str:
    rows = ""
    for it in order.get("items", [])[:6]:
        name = it.get("name_en") or it.get("name_fr") or it.get("slug", "")
        qty = it.get("qty", 1)
        rows += (f'<tr><td style="padding:6px 0;color:#1A2A38">{name}</td>'
                 f'<td style="padding:6px 0;text-align:right;color:#3E5C76">× {qty}</td></tr>')
    return f'<table style="width:100%;border-collapse:collapse;margin:8px 0 4px">{rows}</table>'


async def send_abandoned_cart_reminder(order: dict) -> None:
    """Envoie UN rappel de panier abandonné (bilingue, NOVA)."""
    email = order.get("email")
    if not email:
        return
    items_html = _abandoned_items_html(order)
    coupon_html = ""
    if ABANDON_COUPON_CODE:
        coupon_html = (
            f'<div style="margin:16px 0;padding:14px 18px;background:#E6FBFF;border:1px dashed #00B8D4;border-radius:8px">'
            f'<div style="font-size:13px;color:#3E5C76">Utilisez le code / Use code</div>'
            f'<div style="font-size:20px;font-weight:800;color:#0B2E4F;letter-spacing:1px">{ABANDON_COUPON_CODE}</div>'
            f'</div>'
        )
    body = (
        "<p>Votre sélection vous attend toujours. Vos articles sont réservés ci-dessous — "
        "reprenez là où vous vous êtes arrêté·e.</p>"
        "<p style='color:#3E5C76;font-style:italic'>Your selection is still waiting. Your items are saved below — "
        "pick up right where you left off.</p>"
        f"{items_html}{coupon_html}"
    )
    cta_url = f"{_AUTOMATION_BASE}/checkout"
    html = _nova_email_shell(
        "Votre panier vous attend", "Your cart is waiting",
        body, cta_url, "Finaliser ma commande", "Complete my order",
    )
    await _send_email(email, "Votre panier Fironova vous attend / Your Fironova cart is waiting", html)  # noqa: F821


async def welcome_new_user(email: str, name: str = "", lang: str = "fr") -> None:
    """Email de bienvenue à l'inscription (bilingue, NOVA)."""
    if not email:
        return
    greeting_fr = f"Bienvenue{(' ' + name) if name else ''}"
    body = (
        "<p>Merci d'avoir créé votre compte Fironova. Vous avez maintenant accès à notre catalogue "
        "de peptides de qualité recherche, avec documentation de certificat d'analyse.</p>"
        "<p style='color:#3E5C76;font-style:italic'>Thank you for creating your Fironova account. You now have access "
        "to our catalogue of research-grade peptides, with certificate-of-analysis documentation.</p>"
        "<p style='margin-top:14px;font-size:12px;color:#94A3B8'>Rappel : nos produits sont strictement destinés à la "
        "recherche en laboratoire (RUO). / Reminder: our products are strictly for laboratory research use (RUO).</p>"
    )
    html = _nova_email_shell(
        greeting_fr, "Welcome to Fironova",
        body, f"{_AUTOMATION_BASE}/catalog", "Explorer le catalogue", "Browse the catalogue",
    )
    await _send_email(email, "Bienvenue chez Fironova / Welcome to Fironova", html)  # noqa: F821


async def _abandoned_cart_watchdog() -> None:
    """Balaye périodiquement les commandes non payées et relance une seule fois."""
    await asyncio.sleep(60)  # laisse le démarrage se stabiliser
    while True:
        try:
            now = datetime.now(timezone.utc)
            cutoff_recent = (now - timedelta(hours=ABANDON_MIN_HOURS)).isoformat()
            cutoff_old = (now - timedelta(hours=ABANDON_MAX_HOURS)).isoformat()
            query = {
                "payment_status": {"$in": _UNPAID_STATUSES},
                "email": {"$nin": [None, ""]},
                "created_at": {"$lte": cutoff_recent, "$gte": cutoff_old},
                "abandoned_reminder_sent": {"$ne": True},
            }
            cursor = db.orders.find(query, {"_id": 0})  # noqa: F821
            async for order in cursor:
                # Marque AVANT l'envoi (idempotence : jamais deux rappels)
                res = await db.orders.update_one(  # noqa: F821
                    {"id": order["id"], "abandoned_reminder_sent": {"$ne": True}},
                    {"$set": {"abandoned_reminder_sent": True,
                              "abandoned_reminder_at": now.isoformat()}},
                )
                if res.modified_count == 1:
                    try:
                        await send_abandoned_cart_reminder(order)
                        logging.info("[abandoned-cart] rappel envoyé pour %s", order.get("order_number"))
                    except Exception as e:
                        logging.error("[abandoned-cart] échec envoi %s: %s", order.get("id"), e)
        except Exception as e:
            logging.error("[abandoned-cart] watchdog error: %s", e)
        await asyncio.sleep(ABANDON_SWEEP_MINUTES * 60)

# ===== FIRONOVA_EMAIL_AUTOMATION_END =====



# ===== FIRONOVA_SEO_BLOCK_START =====
SEO_ORIGIN = os.environ.get("PUBLIC_BASE_URL", "https://fironova.com").rstrip("/")  # noqa: F821

# Pages statiques indexables (doit rester cohérent avec robots.txt)
SEO_STATIC_PAGES = [
    ("/", "weekly", "1.0"),
    ("/catalog", "weekly", "0.9"),
    ("/about", "monthly", "0.6"),
    ("/compliance", "monthly", "0.7"),
    ("/faq", "monthly", "0.7"),
    ("/privacy", "yearly", "0.4"),
]


def _seo_xml_escape(s: str) -> str:
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


@api.get("/sitemap.xml")  # noqa: F821
async def dynamic_sitemap():
    """Sitemap généré à la volée : pages statiques + toutes les fiches produits
    actives. Un produit ajouté apparaît automatiquement — plus de sitemap figé."""
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    parts = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']

    for path, freq, prio in SEO_STATIC_PAGES:
        parts.append(
            f"  <url><loc>{SEO_ORIGIN}{path}</loc>"
            f"<changefreq>{freq}</changefreq><priority>{prio}</priority></url>"
        )

    # Produits actifs
    cursor = db.products.find(  # noqa: F821
        {"active": True},
        {"_id": 0, "slug": 1, "updated_at": 1, "created_at": 1},
    )
    async for p in cursor:
        slug = p.get("slug")
        if not slug:
            continue
        lastmod = (p.get("updated_at") or p.get("created_at") or "")[:10]
        lastmod_tag = f"<lastmod>{lastmod}</lastmod>" if lastmod else ""
        parts.append(
            f"  <url><loc>{SEO_ORIGIN}/product/{_seo_xml_escape(slug)}</loc>"
            f"{lastmod_tag}<changefreq>weekly</changefreq><priority>0.8</priority></url>"
        )

    parts.append("</urlset>")
    return Response(content="\n".join(parts), media_type="application/xml")


@api.get("/seo/product/{slug}")  # noqa: F821
async def product_seo(slug: str):
    """Métadonnées SEO d'un produit : title/description/og + JSON-LD Product
    prêt à injecter. Le front appelle ça et remplit le <head> de la fiche."""
    p = await db.products.find_one({"slug": slug, "active": True}, {"_id": 0})  # noqa: F821
    if not p:
        raise HTTPException(404, "Product not found")  # noqa: F821

    variants = p.get("variants", []) or []
    prices = [float(v.get("price", 0)) for v in variants if v.get("price")]
    low_price = min(prices) if prices else float(p.get("price_cad", 0) or 0)
    in_stock = any(int(v.get("stock", 0) or 0) > 0 for v in variants) or int(p.get("stock", 0) or 0) > 0
    img = p.get("og_image_url") or p.get("image_url") or ""
    if img and img.startswith("/"):
        img = SEO_ORIGIN + img

    def _meta(lang: str) -> dict:
        name = p.get(f"name_{lang}") or p.get("name_en") or slug
        title = p.get(f"meta_title_{lang}") or f"{name} — Fironova"
        desc = p.get(f"meta_description_{lang}") or ""
        if not desc:
            raw = p.get(f"description_{lang}") or p.get("description_en") or ""
            desc = (raw[:157] + "…") if len(raw) > 158 else raw
        return {"title": title, "description": desc, "name": name}

    # JSON-LD Product (schema.org) — anglais comme langue canonique du balisage
    en = _meta("en")
    jsonld = {
        "@context": "https://schema.org",
        "@type": "Product",
        "name": en["name"],
        "description": en["description"],
        "sku": p.get("slug"),
        "brand": {"@type": "Brand", "name": "Fironova"},
        "category": p.get("category", ""),
    }
    if img:
        jsonld["image"] = img
    if p.get("molecular_formula"):
        jsonld["additionalProperty"] = [{
            "@type": "PropertyValue", "name": "Molecular formula",
            "value": p.get("molecular_formula"),
        }]
    if low_price > 0:
        jsonld["offers"] = {
            "@type": "Offer",
            "priceCurrency": "CAD",
            "price": round(low_price, 2),
            "availability": ("https://schema.org/InStock" if in_stock
                             else "https://schema.org/OutOfStock"),
            "url": f"{SEO_ORIGIN}/product/{slug}",
        }

    return {
        "slug": slug,
        "canonical": f"{SEO_ORIGIN}/product/{slug}",
        "image": img,
        "en": en,
        "fr": _meta("fr"),
        "jsonld": jsonld,
    }

# ===== FIRONOVA_SEO_BLOCK_END =====



# ===== FIRONOVA_SEO_ADMIN_BLOCK_START =====
# Valeurs par défaut si aucun réglage n'a encore été enregistré.
SEO_DEFAULTS = {
    "site_title_en": "Fironova — Research Peptides (For Research Use Only)",
    "site_title_fr": "Fironova — Peptides de recherche (RUO)",
    "site_description_en": "Fironova supplies research-grade peptides for laboratory use, with certificate-of-analysis documentation. For Research Use Only. Not for human consumption.",
    "site_description_fr": "Fironova fournit des peptides de qualité recherche pour usage en laboratoire, avec documentation de certificat d'analyse. Réservé à la recherche (RUO). Ne pas consommer.",
    "default_og_image": "",
    "keywords_en": "research peptides, laboratory, certificate of analysis, RUO",
    "keywords_fr": "peptides de recherche, laboratoire, certificat d'analyse, RUO",
}


class SeoSettingsIn(BaseModel):
    site_title_en: str = ""
    site_title_fr: str = ""
    site_description_en: str = ""
    site_description_fr: str = ""
    default_og_image: str = ""
    keywords_en: str = ""
    keywords_fr: str = ""


class ProductSeoIn(BaseModel):
    meta_title_en: str = ""
    meta_title_fr: str = ""
    meta_description_en: str = ""
    meta_description_fr: str = ""
    og_image_url: str = ""


async def _seo_get_settings() -> dict:
    doc = await db.seo_settings.find_one({"id": "global"}, {"_id": 0})  # noqa: F821
    if not doc:
        return dict(SEO_DEFAULTS)
    merged = dict(SEO_DEFAULTS)
    for k in SEO_DEFAULTS:
        if doc.get(k):
            merged[k] = doc[k]
    return merged


@api.get("/admin/seo/settings")  # noqa: F821
async def admin_seo_get_settings(admin: dict = Depends(get_admin_user)):  # noqa: F821
    return await _seo_get_settings()


@api.put("/admin/seo/settings")  # noqa: F821
async def admin_seo_set_settings(payload: SeoSettingsIn,
                                 admin: dict = Depends(get_admin_user)):  # noqa: F821
    data = {k: v for k, v in payload.model_dump().items()}
    data.update({
        "id": "global",
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "updated_by": admin.get("email"),
    })
    await db.seo_settings.update_one({"id": "global"}, {"$set": data}, upsert=True)  # noqa: F821
    return await _seo_get_settings()


@api.get("/admin/seo/health")  # noqa: F821
async def admin_seo_health(admin: dict = Depends(get_admin_user)):  # noqa: F821
    """État de santé SEO : combien de produits actifs, combien sans meta."""
    total = await db.products.count_documents({"active": True})  # noqa: F821
    missing_title = 0
    missing_desc = 0
    missing_image = 0
    async for p in db.products.find(  # noqa: F821
        {"active": True},
        {"_id": 0, "meta_title_en": 1, "meta_title_fr": 1,
         "meta_description_en": 1, "meta_description_fr": 1,
         "og_image_url": 1, "image_url": 1},
    ):
        if not (p.get("meta_title_en") or p.get("meta_title_fr")):
            missing_title += 1
        if not (p.get("meta_description_en") or p.get("meta_description_fr")):
            missing_desc += 1
        if not (p.get("og_image_url") or p.get("image_url")):
            missing_image += 1

    settings = await _seo_get_settings()
    global_ok = bool(settings.get("site_title_en") and settings.get("site_description_en"))

    return {
        "products_active": total,
        "products_missing_meta_title": missing_title,
        "products_missing_meta_description": missing_desc,
        "products_missing_image": missing_image,
        "products_fully_optimized": max(0, total - max(missing_title, missing_desc)),
        "global_seo_configured": global_ok,
        "default_og_image_set": bool(settings.get("default_og_image")),
        "sitemap_url": "/api/sitemap.xml",
    }


@api.get("/admin/seo/products")  # noqa: F821
async def admin_seo_products(admin: dict = Depends(get_admin_user)):  # noqa: F821
    """SEO de tous les produits, une ligne par produit (pour édition centralisée)."""
    rows = []
    async for p in db.products.find(  # noqa: F821
        {}, {"_id": 0, "slug": 1, "name_en": 1, "name_fr": 1, "active": 1,
             "meta_title_en": 1, "meta_title_fr": 1,
             "meta_description_en": 1, "meta_description_fr": 1,
             "og_image_url": 1, "image_url": 1},
    ):
        has_title = bool(p.get("meta_title_en") or p.get("meta_title_fr"))
        has_desc = bool(p.get("meta_description_en") or p.get("meta_description_fr"))
        rows.append({
            "slug": p.get("slug"),
            "name_en": p.get("name_en"),
            "name_fr": p.get("name_fr"),
            "active": p.get("active", False),
            "meta_title_en": p.get("meta_title_en", ""),
            "meta_title_fr": p.get("meta_title_fr", ""),
            "meta_description_en": p.get("meta_description_en", ""),
            "meta_description_fr": p.get("meta_description_fr", ""),
            "og_image_url": p.get("og_image_url", ""),
            "image_url": p.get("image_url", ""),
            "optimized": has_title and has_desc,
        })
    rows.sort(key=lambda r: (r["optimized"], not r["active"]))  # non-optimisés d'abord
    return {"products": rows}


@api.put("/admin/seo/products/{slug}")  # noqa: F821
async def admin_seo_update_product(slug: str, payload: ProductSeoIn,
                                   admin: dict = Depends(get_admin_user)):  # noqa: F821
    """Édite uniquement les champs SEO d'un produit (sans toucher au reste)."""
    p = await db.products.find_one({"slug": slug}, {"_id": 0, "id": 1})  # noqa: F821
    if not p:
        raise HTTPException(404, "Product not found")  # noqa: F821
    await db.products.update_one(  # noqa: F821
        {"slug": slug},
        {"$set": {
            "meta_title_en": payload.meta_title_en,
            "meta_title_fr": payload.meta_title_fr,
            "meta_description_en": payload.meta_description_en,
            "meta_description_fr": payload.meta_description_fr,
            "og_image_url": payload.og_image_url,
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }},
    )
    return {"ok": True, "slug": slug}

# ===== FIRONOVA_SEO_ADMIN_BLOCK_END =====

app.include_router(api)

# CORS crédentialé : le navigateur refuse Access-Control-Allow-Origin: * dès
# que des cookies sont envoyés. On échoue vite en cas de mauvaise config.
_cors_origins = [o.strip() for o in os.environ.get("CORS_ORIGINS", "http://localhost:3000").split(",") if o.strip()]
if "*" in _cors_origins:
    raise RuntimeError(
        "CORS_ORIGINS doit lister des origines explicites (ex. https://app.fironova.com) — "
        "'*' est interdit avec une auth par cookie (credentialed)."
    )

app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True,  # Auth cookie-only : le cookie httpOnly access_token doit traverser
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
